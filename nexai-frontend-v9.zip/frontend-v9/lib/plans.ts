export type UserPlan = 'essai' | 'trial' | 'starter' | 'createur' | 'agence' | 'pro_max' | 'admin';

export interface PlanInfo {
  id: UserPlan;
  label: string;
  price: string;
  credits: number;
  domainsIncluded: number;
  hasAgency: boolean;
  hasIA: boolean;
  hasAnalytics: boolean;
  description: string;
}

export const PLANS: PlanInfo[] = [
  {
    id: 'essai',
    label: 'Essai gratuit',
    price: '0 FCFA',
    credits: 12,
    domainsIncluded: 0,
    hasAgency: false,
    hasIA: true,
    hasAnalytics: false,
    description: '7 jours pour découvrir NexAI',
  },
  {
    id: 'starter',
    label: 'Starter',
    price: '5 000 FCFA',
    credits: 30,
    domainsIncluded: 0,
    hasAgency: false,
    hasIA: false,
    hasAnalytics: false,
    description: 'Accès complet à l’Académie',
  },
  {
    id: 'createur',
    label: 'Créateur',
    price: '10 000 FCFA',
    credits: 70,
    domainsIncluded: 1,
    hasAgency: false,
    hasIA: true,
    hasAnalytics: false,
    description: 'Créez et lancez vos sites avec l’IA',
  },
  {
    id: 'agence',
    label: 'Agence',
    price: '25 000 FCFA',
    credits: 270,
    domainsIncluded: 3,
    hasAgency: true,
    hasIA: true,
    hasAnalytics: true,
    description: 'Multi-clients + Analytics & SEO',
  },
  {
    id: 'pro_max',
    label: 'Pro Max',
    price: '35 000 FCFA',
    credits: 400,
    domainsIncluded: 5,
    hasAgency: true,
    hasIA: true,
    hasAnalytics: true,
    description: 'Puissance maximale pour les pros',
  },
];

function norm(plan?: string) {
  if (plan === 'trial') return 'essai';
  return plan;
}

export function planHasAgencyAccess(plan?: UserPlan | string): boolean {
  const p = norm(plan);
  return p === 'agence' || p === 'pro_max' || p === 'admin';
}

export function planHasIA(plan?: UserPlan | string): boolean {
  const p = norm(plan);
  return p !== 'starter';
}

/**
 * Starter = abonnement 100% Académie (PDF/vidéos de formation, livres).
 * Marché ciblé : se former, pas créer de site. Ces comptes n'ont donc pas
 * accès aux modules IA/sites/vidéo/domaines/analytics/agence — on ne leur
 * montre même pas de version verrouillée de ces écrans (contrairement à
 * Créateur/Agence qui voient un teaser Vidéo IA) : l'interface Starter reste
 * calme et dédiée à la formation, avec un unique point de passerelle vers
 * Créateur / Agence-Pro Max (voir UpsellPassage).
 */
export function isFormationOnlyPlan(plan?: UserPlan | string): boolean {
  const p = norm(plan);
  return p === 'starter';
}

export function planHasAnalytics(plan?: UserPlan | string): boolean {
  const p = norm(plan);
  return p === 'agence' || p === 'pro_max' || p === 'admin';
}

/**
 * Accès à la génération vidéo IA (Vidéo IA) : Créateur, Agence et Pro Max
 * (aligné sur assertVideoAdPlanAllowed côté backend — voir credits.service.ts).
 * Starter et l'essai gratuit (trial) peuvent toujours ouvrir l'interface
 * (F/B9 — "voir sans pouvoir générer"), mais planHasVideoAccess() gère le
 * blocage réel de la génération (bouton désactivé + upsell), pas l'accès à
 * la page elle-même.
 */
export function planHasVideoAccess(plan?: UserPlan | string): boolean {
  const p = norm(plan);
  return p === 'createur' || p === 'agence' || p === 'pro_max' || p === 'admin';
}

/**
 * Accès à la GÉNÉRATION de logo (mode "logo" du chat, ou préférence "créer un
 * logo" dans le mode "site") : Créateur, Agence et Pro Max uniquement.
 * L'essai gratuit (trial) voit toujours l'option dans le chat — jamais
 * cachée — mais planHasLogoAccess() gère le blocage réel au moment de
 * générer (message d'upsell), exactement comme planHasVideoAccess().
 * Starter n'a de toute façon pas accès aux modes site/logo (voir
 * isFormationOnlyPlan), donc la question ne se pose pas pour lui.
 */
export function planHasLogoAccess(plan?: UserPlan | string): boolean {
  const p = norm(plan);
  return p === 'createur' || p === 'agence' || p === 'pro_max' || p === 'admin';
}

export function isAdmin(plan?: UserPlan | string, role?: string): boolean {
  return plan === 'admin' || role === 'admin';
}

export const CREDIT_COSTS = {
  GENERATE: 10,
  LAUNCH: 15,
  REGENERATE: 15,
  AI_MODIFY: 5,
  LOGO: 5,
  DOMAIN_EXTRA: 25,
};
