/**
 * Catalogue business officiel — Mode « Trouver mon business » (F6 / B2).
 *
 * Source de vérité pour les idées et modules Académie proposés par le Coach
 * business. La logique conversationnelle (profilage, filtrage, orientation)
 * est pilotée par l'IA côté backend (B2 — prompt du mode `business`), qui
 * doit s'appuyer sur exactement ce catalogue. Ce fichier sert ici :
 *  - de source de vérité partageable avec le backend (copier/coller direct
 *    dans le prompt du mode business) ;
 *  - à afficher, côté frontend, un aperçu lisible (teaser du hub, panneau
 *    « Voir le catalogue » dans le chat) — jamais à piloter la conversation
 *    elle-même, qui reste 100% IA.
 *
 * Règles d'usage (rappel — appliquées côté prompt IA, pas ici) :
 *  - Afficher 3 idées max à la fois (filtrées selon temps + préférence).
 *  - Après le choix : 1 à 2 modules max nommés, avec une phrase d'envie —
 *    jamais le contenu du cours.
 *  - Idée impliquant revente → mention Boutique.
 *  - Idée impliquant pubs / faceless → mention outil vidéo (accessible à
 *    tous, crédits).
 *  - CTA final : « On crée ton site autour de cette idée ? » → bascule mode
 *    site.
 *  - Interdit : promesses de gains chiffrés, idées hors liste, détail des
 *    cours ou des fichiers Boutique.
 */

export interface BusinessIdea {
  id: string;
  title: string;
  pitch: string;
  /** Noms exacts des modules Académie à orienter, dans l'ordre suggéré. */
  modules: string[];
  ressources: string[];
}

export const BUSINESS_IDEAS: BusinessIdea[] = [
  {
    id: 'revente_digitale',
    title: 'Revente de produits digitaux',
    pitch:
      'Tu choisis des packs avec droit de revente dans la Boutique NexAI, tu les vends sur ton propre site. Pas de stock, marge élevée.',
    modules: [
      'module1_Positionnement_Offre_Services_IA',
      'module2_Packages_Pricing_IA',
      'module3_Acquisition_Clients_IA',
      'module5_Acquisition_Conversion_Ventes',
      'module4_Boutiques_En_Ligne',
      'module5_Productisation_Scaling_IA',
    ],
    ressources: ['Boutique (droit de revente)', 'Site de vente', 'Académie'],
  },
  {
    id: 'video_ia_entreprises',
    title: 'Service de vidéos IA pour entreprises / commerces',
    pitch:
      'Tu prends les commandes sur ton site (pubs, reels, présentations). Tu produis avec l’outil de génération vidéo IA NexAI, tu livres. Idéal si tu ne veux pas t’afficher.',
    modules: [
      'module1_Positionnement_Offre_Services_IA',
      'module2_Packages_Pricing_IA',
      '04_Publicites_video_NexAI',
      '01_Montage_video_professionnel_NexAI',
      'NexAI_Module_03_Films_Series_Formats_courts',
      'NexAI_Module_05_Images_Videos_Voix',
      'module4_Processus_Livraison_Outils',
      'module3_Acquisition_Clients_IA',
    ],
    ressources: ['Outil vidéo (crédits)', 'Site vitrine + prise de commandes', 'Académie'],
  },
  {
    id: 'mini_agence_locale',
    title: 'Mini-agence « site + contenu » pour commerces locaux',
    pitch:
      'Tu vends aux commerces de ta zone un site pro + contenus / pubs. Tu génères les sites avec NexAI, tu factures le client.',
    modules: [
      'module1_Positionnement_Offre_Services_IA',
      'module1_Strategie_Digitale',
      'module3_SEO_Referencement',
      '02_Creation_contenus_courts_NexAI',
      'module2_Publicite_En_Ligne',
      'module3_Acquisition_Clients_IA',
      'module3_Identite_Visuelle',
    ],
    ressources: ['Générateur de sites (multi-clients)', 'Académie', 'optionnel outil vidéo'],
  },
  {
    id: 'contenu_faceless',
    title: 'Contenu faceless + monétisation',
    pitch:
      'Tu crées des vidéos / contenus sans montrer ton visage (outil vidéo NexAI), tu publies, tu monétises via un site (capture d’audience, produits digitaux ou affiliation).',
    modules: [
      '01_Strategie_Social_Media_NexAI',
      '02_Creation_contenus_courts_NexAI',
      '05_Personal_Branding_audience_NexAI',
      'NexAI_Module_01_Generation_contenu_IA',
      'NexAI_Module_02_Scenarios_Storytelling',
      'NexAI_Module_04_Creation_publicitaire',
      'module5_Acquisition_Conversion_Ventes',
    ],
    ressources: [
      'Outil vidéo',
      'Site de capture / vente',
      'Académie',
      'Boutique (si produits digitaux)',
    ],
  },
  {
    id: 'pack_presence_digitale',
    title: 'Pack « présence digitale » (site + 5–10 vidéos)',
    pitch:
      'Tu vends une offre clé en main : un site + un lot de vidéos publicitaires. Tu produis tout dans NexAI, tu livres un pack.',
    modules: [
      'module1_Positionnement_Offre_Services_IA',
      'module2_Packages_Pricing_IA',
      '04_Publicites_video_NexAI',
      'module4_Supports_Publicitaires',
      'module5_Acquisition_Conversion_Ventes',
      'module4_Processus_Livraison_Outils',
    ],
    ressources: ['Sites', 'Outil vidéo', 'Académie'],
  },
];

export interface BusinessDomain {
  id: string;
  title: string;
  modules: string[];
}

/** Domaines métier complémentaires — proposés en plus selon le profil. */
export const BUSINESS_DOMAINS: BusinessDomain[] = [
  {
    id: 'coaching_accompagnement',
    title: 'Coaching / accompagnement en ligne',
    modules: [
      '05_Personal_Branding_audience_NexAI',
      'NexAI_Module_01_Prise_de_parole_en_public',
      'NexAI_Module_02_Communication_professionnelle',
      'module1_Positionnement_Offre_Services_IA',
      'module3_Acquisition_Clients_IA',
    ],
  },
  {
    id: 'services_locaux',
    title: 'Services locaux (beauté, sport, services à la personne…)',
    modules: [
      'module1_Strategie_Digitale',
      'module3_Acquisition_Clients_IA',
      '04_Community_Management_NexAI',
      '03_Creation_contenu_organique_NexAI',
      '05_Facturation_gestion_entreprise_NexAI',
    ],
  },
  {
    id: 'ecommerce_petite_marque',
    title: 'E-commerce / petite marque',
    modules: [
      'module4_Boutiques_En_Ligne',
      'module3_SEO_Referencement',
      'module2_Publicite_En_Ligne',
      'module3_Identite_Visuelle',
      'module5_Acquisition_Conversion_Ventes',
    ],
  },
];

/** Socle de modules pour les débutants, avant les modules spécifiques à l'idée choisie. */
export const STARTER_MODULES = [
  'module1_Positionnement_Offre_Services_IA',
  'module2_Packages_Pricing_IA',
  'module3_Acquisition_Clients_IA',
];
