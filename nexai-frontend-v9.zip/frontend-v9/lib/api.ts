const API_BASE = (process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1').replace(/\/$/, '');

/** Origine du backend (sans le préfixe /api/v1), utile pour les URLs de
 * streaming renvoyées en chemin relatif (ex: /api/v1/academy/:id/stream). */
export const API_ORIGIN = API_BASE.replace(/\/api\/v1$/, '');

/** Construit une URL absolue vers le backend à partir d'un chemin renvoyé par l'API. */
export function toBackendUrl(path: string): string {
  if (!path) return path;
  if (/^https?:\/\//i.test(path)) return path;
  return `${API_ORIGIN}${path.startsWith('/') ? '' : '/'}${path}`;
}

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
  });

  if (!res.ok) {
    let message = `Erreur ${res.status}`;
    try {
      const body = await res.json();
      message = body.message || body.error || message;
    } catch {
      /* ignore */
    }
    throw new ApiError(message, res.status);
  }

  if (res.status === 204) return undefined as T;
  return res.json();
}

/** Normalise _id → id si le backend renvoie Mongo */
function withId<T extends Record<string, unknown>>(obj: T): T & { id: string } {
  const id = (obj.id || obj._id || '') as string;
  return { ...obj, id: String(id) };
}

export type UserPlan = 'essai' | 'trial' | 'starter' | 'createur' | 'agence' | 'pro_max' | 'admin';

export interface AuthUser {
  id: string;
  email: string;
  name?: string;
  plan: UserPlan;
  creditsBalance: number;
  role?: 'user' | 'admin' | 'finance' | 'support';
  createdAt?: string;
}

function normalizeUser(u: any): AuthUser {
  const raw = withId(u);
  let plan = (raw.plan || 'trial') as UserPlan;
  if (plan === 'trial') plan = 'essai';
  return {
    id: String(raw.id),
    email: String(raw.email || ''),
    name: raw.name as string | undefined,
    plan,
    creditsBalance: Number(raw.creditsBalance ?? 0),
    role: raw.role as AuthUser['role'],
    createdAt: raw.createdAt as string | undefined,
  };
}

// ── Auth ──────────────────────────────────────────────────────────────
export const authApi = {
  register: (email: string, password: string, name?: string) =>
    request<{ message: string }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ email, password, name }),
    }),
  verify: async (email: string, code: string) => {
    const r = await request<{ user: any }>('/auth/verify-email', {
      method: 'POST',
      body: JSON.stringify({ email, code }),
    });
    return { user: normalizeUser(r.user) };
  },
  login: async (email: string, password: string) => {
    const r = await request<{ user: any }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    return { user: normalizeUser(r.user) };
  },
  loginWithGoogle: async (idToken: string) => {
    const r = await request<{ user: any }>('/auth/google', {
      method: 'POST',
      body: JSON.stringify({ idToken }),
    });
    return { user: normalizeUser(r.user) };
  },
  /** NOTE: adapte le chemin si ta route backend de renvoi de code a un autre nom. */
  resendCode: (email: string) =>
    request<{ message: string }>('/auth/resend-code', {
      method: 'POST',
      body: JSON.stringify({ email }),
    }),
  logout: () => request('/auth/logout', { method: 'POST' }),
  forgotPassword: (email: string) =>
    request('/auth/forgot-password', { method: 'POST', body: JSON.stringify({ email }) }),
  resetPassword: (email: string, code: string, newPassword: string) =>
    request('/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify({ email, code, newPassword }),
    }),
};

export type PaymentModeUi = 'lien_personnel' | 'nexai';

export type CompteReversement = {
  type?: 'mobile_money' | 'crypto';
  operateur?: string;
  numero?: string;
  cryptoAddress?: string;
};

export type PaymentProviderUi = 'chariow' | 'maketou' | 'stripe' | 'autre';

export const usersApi = {
  me: async () => {
    const r = await request<any>('/users/me');
    // backend may return user directly or { user }
    const u = r.user || r;
    return {
      ...normalizeUser(u),
      defaultPaymentMode: (u.defaultPaymentMode || 'nexai') as PaymentModeUi,
      personalPaymentLink: (u.personalPaymentLink || '') as string,
      personalPaymentProvider: (u.personalPaymentProvider || '') as PaymentProviderUi | '',
      compteReversement: (u.compteReversement || null) as CompteReversement | null,
    };
  },
  /** Solde + historique des transactions de crédits (GET /users/me/credits) */
  credits: () =>
    request<{
      creditsBalance: number;
      unlimited?: boolean;
      transactions: {
        _id?: string;
        id?: string;
        type: string;
        amount: number;
        balanceAfter: number;
        note?: string;
        createdAt: string;
      }[];
    }>('/users/me/credits'),
  updatePayments: (body: {
    defaultPaymentMode: PaymentModeUi;
    personalPaymentLink?: string;
    personalPaymentProvider?: PaymentProviderUi;
    compteReversement?: CompteReversement;
  }) =>
    request<{
      ok: boolean;
      defaultPaymentMode: PaymentModeUi;
      personalPaymentLink: string;
      personalPaymentProvider: string;
      compteReversement: CompteReversement | null;
    }>('/users/me/payments', {
      method: 'PATCH',
      body: JSON.stringify(body),
    }),
};

// ── Chat IA (assistant NexAI) ────────────────────────────────────────
export type ChatMessageMode = 'choices' | 'input';
/**
 * Mode du hub assistant (F1) : chaque mode ouvre le même chat mais avec un
 * guidage IA différent côté backend (voir spec backend B1 — ANTI_RULES +
 * guidage par mode + instructions admin).
 */
export type ChatMode = 'site' | 'logo' | 'edit' | 'business';
export interface ChatAttachment {
  url: string;
  type: 'image' | 'file';
  name?: string;
}
export interface ChatMessage {
  role: 'assistant' | 'user';
  content: string;
  mode?: ChatMessageMode;
  options?: string[];
  /** Suggestion de bascule vers un autre mode du hub (CTA de cross-vente) */
  suggestMode?: ChatMode;
  attachments?: ChatAttachment[];
  createdAt?: string;
}
export interface ChatSession {
  id: string;
  status: 'collecting' | 'reviewing' | 'confirmed' | 'abandoned';
  mode?: ChatMode;
  niche?: string;
  messages: ChatMessage[];
  reviewSummary?: string;
  siteId?: string;
}

function normalizeSession(s: any): ChatSession {
  return { ...withId(s), messages: s.messages || [] };
}

export const chatApi = {
  /**
   * Démarre une NOUVELLE session de chat dans un mode donné (F1). `siteId`
   * permet de scoper une session « edit » (F5) sur un site précis dès
   * l'ouverture. Pour changer de mode EN GARDANT le contexte d'une
   * conversation déjà en cours (CTA suggestMode), utiliser switchMode()
   * plutôt que start().
   */
  start: async (params?: { clientId?: string; mode?: ChatMode; siteId?: string }) => {
    const r = await request<{ session: any }>('/chat/start', {
      method: 'POST',
      body: JSON.stringify(params || {}),
    });
    return { session: normalizeSession(r.session) };
  },
  message: async (sessionId: string, reply: string, attachments?: ChatAttachment[]) => {
    const r = await request<{ session: any }>(`/chat/${sessionId}/message`, {
      method: 'POST',
      body: JSON.stringify({ reply, attachments }),
    });
    return { session: normalizeSession(r.session) };
  },
  confirm: async (sessionId: string, confirmed: boolean) => {
    const r = await request<{
      session: any;
      site: any;
      pendingLogoAction?: 'upload' | 'library' | 'plan_required' | null;
    }>(`/chat/${sessionId}/confirm`, {
      method: 'POST',
      body: JSON.stringify({ confirmed }),
    });
    return {
      session: normalizeSession(r.session),
      site: r.site ? normalizeSite(r.site) : null,
      pendingLogoAction: r.pendingLogoAction ?? null,
    };
  },
  /**
   * Bascule la session en cours vers un autre mode du hub (site/logo/edit/business)
   * en GARDANT l'historique de conversation — utilisé pour les CTA de cross-vente
   * (suggestMode) affichés en fin de flux. Contrairement à `start()`, ceci ne
   * perd jamais le contexte déjà donné par le client.
   */
  switchMode: async (sessionId: string, mode: ChatMode) => {
    const r = await request<{ session: any }>(`/chat/${sessionId}/switch-mode`, {
      method: 'POST',
      body: JSON.stringify({ mode }),
    });
    return { session: normalizeSession(r.session) };
  },
  get: async (sessionId: string) => {
    const r = await request<{ session: any }>(`/chat/${sessionId}`);
    return { session: normalizeSession(r.session) };
  },
  /**
   * Upload d'une pièce jointe (image ou fichier — jamais de vocal). Appel
   * direct via fetch (pas via `request`) : un upload multipart ne doit
   * JAMAIS avoir de header Content-Type fixé à la main (le navigateur pose
   * lui-même le boundary multipart).
   */
  upload: async (sessionId: string, file: File): Promise<ChatAttachment> => {
    const formData = new FormData();
    formData.append('file', file);
    const res = await fetch(`${API_BASE}/chat/${sessionId}/upload`, {
      method: 'POST',
      credentials: 'include',
      body: formData,
    });
    if (!res.ok) {
      let message = `Erreur ${res.status}`;
      try {
        const body = await res.json();
        message = body.message || body.error || message;
      } catch {
        /* ignore */
      }
      throw new ApiError(message, res.status);
    }
    return res.json();
  },
};

// ── Sites ─────────────────────────────────────────────────────────────
export type SiteStatus =
  | 'brief_incomplete'
  | 'generating'
  | 'ready'
  | 'launched'
  | 'failed'
  | 'pending_support'
  | 'offline';

export interface Site {
  id: string;
  niche: string;
  status: SiteStatus;
  domainType?: 'sous_domaine' | 'godaddy' | 'byod';
  domainName?: string;
  clientId?: string;
  name?: string;
  createdAt?: string;
  updatedAt?: string;
  brief?: Record<string, unknown>;
  proposals?: any[];
}

function normalizeSite(s: any): Site {
  const raw = withId(s);
  return {
    id: String(raw.id),
    niche: String(raw.niche || ''),
    status: (raw.status || 'brief_incomplete') as SiteStatus,
    domainType: raw.domainType as Site['domainType'],
    domainName: raw.domainName as string | undefined,
    clientId: raw.clientId ? String(raw.clientId) : undefined,
    name: raw.name as string | undefined,
    createdAt: raw.createdAt as string | undefined,
    updatedAt: raw.updatedAt as string | undefined,
    brief: raw.brief as Record<string, unknown> | undefined,
    proposals: raw.proposals as any[] | undefined,
  };
}

export const sitesApi = {
  list: async () => {
    const r = await request<{ sites: any[] }>('/sites');
    return { sites: (r.sites || []).map(normalizeSite) };
  },
  get: async (id: string) => {
    const r = await request<{ site: any }>(`/sites/${id}`);
    return { site: normalizeSite(r.site) };
  },
  create: async (niche: string, brief?: Record<string, unknown>, clientId?: string) => {
    const r = await request<{ site: any }>('/sites', {
      method: 'POST',
      body: JSON.stringify({ niche, brief: brief || {}, clientId }),
    });
    return { site: normalizeSite(r.site) };
  },
  updateBrief: async (id: string, brief: Record<string, unknown>) => {
    const r = await request<{ site: any }>(`/sites/${id}/brief`, {
      method: 'PATCH',
      body: JSON.stringify({ brief }),
    });
    return { site: normalizeSite(r.site) };
  },
  generate: (id: string) =>
    request<{ jobId?: string; message?: string }>(`/sites/${id}/generate`, { method: 'POST' }),
  choose: async (id: string, proposalIndex: number) => {
    const r = await request<{ site: any }>(`/sites/${id}/choose`, {
      method: 'POST',
      body: JSON.stringify({ proposalIndex }),
    });
    return { site: normalizeSite(r.site) };
  },
  /**
   * Met un site en ligne. Le backend exige `domainType` et `paymentMode` —
   * ne jamais appeler sans domainConfig (voir /sites/[id]/parametres).
   */
  lancer: async (
    id: string,
    domainConfig: {
      domainType: 'sous_domaine' | 'godaddy' | 'byod';
      domainName?: string;
      subdomainSlug?: string;
      paymentMode: 'lien_personnel' | 'chariow';
      paymentLink?: string;
      paymentProvider?: 'chariow' | 'maketou' | 'stripe' | 'autre';
    }
  ) => {
    const r = await request<{ site: any }>(`/sites/${id}/lancer`, {
      method: 'POST',
      body: JSON.stringify(domainConfig),
    });
    return { site: normalizeSite(r.site) };
  },
  offline: async (id: string) => {
    const r = await request<{ site: any }>(`/sites/${id}/offline`, { method: 'POST' });
    return { site: normalizeSite(r.site) };
  },
  aiModify: (id: string, instruction: string) =>
    request<{ jobId?: string }>(`/sites/${id}/ai-modify`, {
      method: 'POST',
      body: JSON.stringify({ instruction }),
    }),
};

// ── Domaines ──────────────────────────────────────────────────────────
export const domainsApi = {
  quota: () =>
    request<{
      plan: string;
      included: number;
      used: number;
      remaining: number;
      canUseIncluded: boolean;
      creditCostIfExtra: number;
      creditsBalance: number;
      options?: Record<string, unknown>;
    }>('/domains/quota'),
  check: (domain: string) =>
    request<{ domain: string; available: boolean; priceCredits?: number }>('/domains/check', {
      method: 'POST',
      body: JSON.stringify({ domain }),
    }),
  variants: (base: string) =>
    request<{ variants: { domain: string; available: boolean; priceCredits: number }[] }>(
      '/domains/variants',
      { method: 'POST', body: JSON.stringify({ base }) }
    ),
};

// ── Academy ───────────────────────────────────────────────────────────
export interface AcademyListItem {
  id: string;
  title: string;
  type: 'pdf' | 'video';
  access: 'gratuit' | 'payant';
  category: string;
  formationId?: string;
  formationTitle?: string;
  locked: boolean;
  description?: string;
}

export interface AcademyContentMeta {
  id: string;
  title: string;
  type: 'pdf' | 'video';
  hosting?: 'cloudinary' | 'embed_externe';
  /** Chemin backend (à préfixer avec toBackendUrl) vers le flux protégé. */
  streamUrl?: string;
  /** URL/texte d'intégration externe (ex. lien YouTube/Vimeo) quand hosting = embed_externe. */
  embedHint?: string;
}

export const academyApi = {
  list: async () => {
    const r = await request<{ contents: any[]; plan: string; fullAccess: boolean }>('/academy');
    return {
      ...r,
      contents: (r.contents || []).map((c) => ({
        ...withId(c),
        id: String(c.id || c._id),
      })) as AcademyListItem[],
    };
  },
  /** Métadonnées fraîches + token de vue courte durée pour /stream ou /video-stream. */
  getFreshMeta: async (id: string) => {
    const r = await request<any>(`/academy/${id}`);
    return { ...r, id: String(r.id || r._id || id) } as AcademyContentMeta;
  },
};

// ── Boutique ──────────────────────────────────────────────────────────
export interface BoutiqueProduct {
  id: string;
  title: string;
  description: string;
  priceCredits: number;
  type: string;
  imageUrl?: string;
  locked?: boolean;
}

export const boutiqueApi = {
  list: async () => {
    const r = await request<{ products: any[] }>('/boutique');
    return {
      products: (r.products || []).map((p) => ({
        ...p,
        id: String(p.id || p._id),
      })) as BoutiqueProduct[],
    };
  },
  /** Backend actuel : POST /boutique/:id/debloquer */
  purchase: (id: string) =>
    request(`/boutique/${id}/debloquer`, { method: 'POST' }),

  /** Packs publiés — l'entrée de la Boutique (cartes cliquables). */
  packs: () =>
    request<{
      packs: {
        id: string;
        titre: string;
        sousTitre: string | null;
        description: string | null;
        creditsCost: number;
        gratuit: boolean;
        imageUrl: string | null;
        nbProduits: number;
        accessible: boolean;
        raisonBlocage: string | null;
      }[];
    }>('/boutique/packs'),

  /** PDF contenus dans un pack. */
  produitsDuPack: (packId: string) =>
    request<{
      pack: { id: string; titre: string; sousTitre: string | null; creditsCost: number };
      produits: {
        id: string;
        title: string;
        description: string | null;
        imageUrl: string | null;
        creditsCost: number;
        isFreeForSubscriber: boolean;
        unlocked: boolean;
      }[];
    }>(`/boutique/packs/${packId}/produits`),
};

// ── Credits ───────────────────────────────────────────────────────────
export const creditsApi = {
  packs: () =>
    request<{ packs: { id: string; credits: number; label: string }[]; balance: number }>(
      '/credits/packs'
    ),
  /** Génère un lien de paiement Chariow pour un pack (ou une quantité libre). */
  acheter: (body: { packId?: string; quantity?: number; currency?: 'XOF' | 'USD' }) =>
    request<{
      ok: boolean;
      pending: boolean;
      message: string;
      transactionId: string;
      quantity: number;
      unitPrice: number;
      totalAmount: number;
      currency: string;
      paymentLink?: string;
    }>('/credits/acheter', { method: 'POST', body: JSON.stringify(body) }),
};

// ── Logos ─────────────────────────────────────────────────────────────
export const logosApi = {
  generate: (body: {
    brandName: string;
    niche: string;
    styleHints?: string;
    colors?: string;
    siteId?: string;
  }) =>
    request<{ proposals: { versionId: string; url: string; prompt?: string }[]; creditsSpent: number; logosRemaining: number }>(
      '/logos/generate',
      { method: 'POST', body: JSON.stringify(body) }
    ),
  embellissement: (body: {
    brandName: string;
    niche: string;
    logoDescription: string;
    mode: 'background' | 'decorative';
    siteId?: string;
  }) =>
    request<{ mode: string; imageUrl: string; creditsSpent: number }>('/logos/embellissement', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  /** Bibliothèque de logos déjà créés/importés sur le compte — pour proposer "logo déjà créé ici ?" dans le chat. */
  list: () =>
    request<{ logos: { id: string; url: string; brandName: string; niche?: string; source: 'generated' | 'uploaded'; chosen: boolean; createdAt: string }[] }>(
      '/logos'
    ),
  choisir: (logoId: string, siteId: string) =>
    request<{ site: any; logo: any }>(`/logos/${logoId}/choisir`, {
      method: 'POST',
      body: JSON.stringify({ siteId }),
    }),
  importer: (body: { url: string; brandName: string; niche?: string; siteId?: string }) =>
    request<{ logo: any }>('/logos/importer', { method: 'POST', body: JSON.stringify(body) }),
};

// ── Vidéo IA (Créateur, Agence, Pro Max) ──────────────────────────────
// Note : app/video/page.tsx appelle directement /video-ads via fetch() avec
// le shape réel du backend (mode/format/aspectRatio/brief). Pas de wrapper
// ici pour éviter toute divergence de shape entre ce fichier et les routes.

// ── Agency ────────────────────────────────────────────────────────────
export interface AgencyClient {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  sitesCount: number;
  lastAccess?: string;
  active: boolean;
}

export const agencyApi = {
  clients: async () => {
    const r = await request<{ clients: any[] }>('/agency/clients');
    return {
      clients: (r.clients || []).map((c) => ({
        ...c,
        id: String(c.id || c._id),
        sitesCount: c.sitesCount ?? 0,
        active: c.active !== false,
      })) as AgencyClient[],
    };
  },
  createClient: async (data: { name: string; email?: string; phone?: string }) => {
    const r = await request<{ client: any }>('/agency/clients', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    return { client: { ...r.client, id: String(r.client.id || r.client._id) } as AgencyClient };
  },
  getClient: async (id: string) => {
    const r = await request<{ client: any; sites: any[] }>(`/agency/clients/${id}`);
    return {
      client: { ...r.client, id: String(r.client.id || r.client._id) } as AgencyClient,
      sites: (r.sites || []).map(normalizeSite),
    };
  },
  stats: () =>
    request<{
      stats: { clients: number; sites: number; sitesOnline: number; [k: string]: unknown };
    }>('/agency/stats'),
  quickEditSite: async (siteId: string, textFields: Record<string, string>) => {
    const r = await request<{
      site: any;
      patchedIds: string[];
      notFoundIds: string[];
      redeployed: boolean;
    }>(`/agency/sites/${siteId}/quick-edit`, {
      method: 'PATCH',
      body: JSON.stringify({ textFields }),
    });
    return { ...r, site: normalizeSite(r.site) };
  },
};

// ── Support client (chat IA → relais humain) ───────────────────────────
export type SupportTicketStatus = 'open' | 'ai' | 'needs_human' | 'closed';

export interface SupportMessage {
  id: string;
  role: 'user' | 'assistant' | 'admin';
  content: string;
  createdAt: string;
}

export interface SupportTicket {
  id: string;
  status: SupportTicketStatus;
  subject?: string;
  messages: SupportMessage[];
  userEmail?: string;
  createdAt?: string;
  updatedAt?: string;
}

export const supportApi = {
  /** Thread du client connecté (crée un ticket ouvert si besoin) */
  myThread: () =>
    request<{ ticket: SupportTicket }>('/support/thread'),

  /** Envoie un message ; le backend répond via IA ou flag needs_human */
  send: (content: string) =>
    request<{ ticket: SupportTicket; escalated?: boolean }>('/support/messages', {
      method: 'POST',
      body: JSON.stringify({ content }),
    }),
};


// ── Admin ─────────────────────────────────────────────────────────────
export const adminApi = {
  users: async () => {
    const r = await request<{ users: any[] }>('/admin/users');
    return {
      users: (r.users || []).map((u) => normalizeUser(u)),
    };
  },
  updateUser: (id: string, data: { plan?: string; creditsBalance?: number }) =>
    request(`/admin/users/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),
  updateUserPlan: (id: string, plan: string, grantPlanCredits = false) =>
    request(`/admin/users/${id}/plan`, {
      method: 'PATCH',
      body: JSON.stringify({ plan, grantPlanCredits }),
    }),
  payments: () =>
    request<{
      payments: {
        id: string;
        userEmail: string;
        amount: number;
        status: 'pending' | 'paid' | 'failed';
        createdAt: string;
      }[];
    }>('/admin/payments'),
  markPaid: (id: string) =>
    request(`/admin/payments/${id}/mark-paid`, { method: 'POST' }),
  /** Stats vidéo IA — taux d'échec réel, coût perdu, dégradations, relances (voir admin.routes.ts). */
  videoAdsStats: (days = 30) =>
    request<{
      periode: { jours: number; depuis: string };
      totalVideosGenerees: number;
      totalRembourses: number;
      tauxEchec: number;
      creditsPerdus: number;
      coutReelPerduUsd: number;
      livraisonsDegradees: number;
      tauxDegradation: number;
      relancesCorrectivesUtilisees: number;
      tauxUtilisationRelance: number;
      parMode: Record<string, { total: number; rembourses: number; degrades: number }>;
    }>(`/admin/video-ads/stats?days=${days}`),
  avis: () =>
    request<{
      avis: { id: string; name: string; role: string; content: string; rating: number; active: boolean }[];
    }>('/admin/avis'),
  createAvis: (data: { name: string; role: string; content: string; rating: number }) =>
    request('/admin/avis', { method: 'POST', body: JSON.stringify(data) }),
  updateAvis: (id: string, data: any) =>
    request(`/admin/avis/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),
  deleteAvis: (id: string) => request(`/admin/avis/${id}`, { method: 'DELETE' }),
  
  alertes: () =>
    request<{ sites: any[] }>('/admin/sites/alertes'),
  supportFile: () =>
    request<{ sites: any[] }>('/admin/support/file'),

  /** Tickets support clients (file needs_human + open) */
  supportTickets: () =>
    request<{ tickets: SupportTicket[] }>('/admin/support/tickets'),
  supportTicket: (id: string) =>
    request<{ ticket: SupportTicket }>(`/admin/support/tickets/${id}`),
  replySupport: (id: string, content: string) =>
    request<{ ticket: SupportTicket }>(`/admin/support/tickets/${id}/reply`, {
      method: 'POST',
      body: JSON.stringify({ content }),
    }),
  closeSupport: (id: string) =>
    request<{ ticket: SupportTicket }>(`/admin/support/tickets/${id}/close`, {
      method: 'POST',
    }),
  promptIA: (message: string, context?: string) =>
    request<{ reply: string }>('/admin/ia-prompt', {
      method: 'POST',
      body: JSON.stringify({ message, context }),
    }),

  /**
   * Instructions complémentaires injectées à la fin du prompt du chat IA
   * (F9 / B8). Ne modifient jamais les règles anti, verrouillées côté
   * backend (ANTI_RULES — voir chat.service.ts).
   */
  getChatInstructions: () =>
    request<{ instructions: string; updatedAt?: string }>('/admin/chat-instructions'),
  updateChatInstructions: (instructions: string) =>
    request<{ instructions: string; updatedAt?: string }>('/admin/chat-instructions', {
      method: 'PATCH',
      body: JSON.stringify({ instructions }),
    }),
};


// ── Avis publics (landing) ────────────────────────────────────────────
export const avisApi = {
  list: () =>
    request<{
      avis: { id: string; name: string; role: string; content: string; rating: number }[];
    }>('/avis'),
};

// ══════════════════════════════════════════════════════════════════════
// Modules ajoutés en v6 — Méthode de retrait, abonnements, parrainage,
// reçus, historique de versions, test vidéo essai, textes figés,
// sécurité et maintenance.
// ══════════════════════════════════════════════════════════════════════

export interface SoldeRetrait {
  encaisseFcfa: number;
  reverseFcfa: number;
  enAttenteFcfa: number;
}

/** Méthode de retrait — page dédiée (section 12). */
export const retraitApi = {
  /** État complet : mode actif, coordonnées, et statistiques du Compte NexAI. */
  get: () =>
    request<{
      modeActif: 'nexai' | 'lien_personnel';
      compteNexai: {
        label: string;
        description: string;
        disponible: boolean;
        coordonnees: Record<string, unknown> | null;
        statistiques: SoldeRetrait;
        historique: {
          id: string;
          type: string;
          amountFcfa: number;
          date: string;
          reference: string | null;
        }[];
      };
      lienPersonnel: {
        label: string;
        description: string;
        disponible: boolean;
        lien: string | null;
        prestataire: string | null;
      };
    }>('/retrait'),

  /** Enregistre le mode choisi. Le lien personnel est réellement vérifié côté backend. */
  update: (payload: {
    mode: 'nexai' | 'lien_personnel';
    personalPaymentLink?: string;
    personalPaymentProvider?: 'chariow' | 'maketou' | 'stripe' | 'autre';
    compteReversement?: {
      type: 'mobile_money' | 'crypto';
      operateur?: string;
      numero?: string;
      cryptoType?: 'usdt_bep20' | 'btc';
      cryptoAddress?: string;
    };
  }) => request('/retrait', { method: 'PATCH', body: JSON.stringify(payload) }),
};

/** Abonnements, parrainage et reçus (sections 7, 16, 17). */
export const plansApi = {
  list: () =>
    request<{
      planActuel: string;
      creditsBalance: number | null;
      creditsIllimites: boolean;
      plans: {
        id: string;
        nom: string;
        prixFcfa: number;
        prixUsd: number;
        inclus: string[];
        nonInclus: string[];
        creditsParMois: number;
        domainesInclus: number;
        logosInclus: number;
        actuel: boolean;
        populaire?: boolean;
      }[];
    }>('/plans'),

  /**
   * Génère le lien de paiement. Le plan n'est JAMAIS appliqué ici :
   * c'est le webhook Chariow qui l'active après paiement confirmé.
   */
  acheter: (plan: 'starter' | 'createur' | 'agence' | 'pro_max') =>
    request<{ paymentLink: string; plan: string; montantFcfa: number; note: string }>(
      '/plans/acheter',
      { method: 'POST', body: JSON.stringify({ plan }) }
    ),

  parrainage: () =>
    request<{
      code: string;
      totalFilleuls: number;
      filleulsConvertis: number;
      creditsGagnes: number;
      recompenseParFilleul: number;
      regle: string;
    }>('/plans/parrainage'),

  recus: () =>
    request<{
      recus: {
        id: string;
        date: string;
        libelle: string;
        montantFcfa: number | null;
        numero: string;
        telechargeable: boolean;
      }[];
    }>('/plans/recus'),

  /** Lien de téléchargement direct du PDF (le navigateur ouvre le fichier). */
  recuUrl: (transactionId: string) => `${API_BASE}/plans/recus/${transactionId}`,
};

/** Historique et retour en arrière d'un site (section 10). */
export const versionsApi = {
  list: (siteId: string) =>
    request<{
      versions: {
        id: string;
        numero: number;
        type: string;
        libelle: string;
        resume: string | null;
        date: string;
        estVersionActuelle: boolean;
      }[];
      maxConservees: number;
    }>(`/sites/${siteId}/versions`),

  restaurer: (versionId: string) =>
    request<{ restauree: number; necessiteRepublication: boolean }>(
      `/sites/versions/${versionId}/restaurer`,
      { method: 'POST' }
    ),
};

/** « Tester Vidéo IA » — essai gratuit uniquement (section 7). */
export const videoTestApi = {
  status: () =>
    request<{
      visible: boolean;
      disponible: boolean;
      dejaUtilise: boolean;
      coutCredits: number;
      dureeSecondes: number;
      videoAdId: string | null;
      telechargementAutorise: boolean;
      messageTelechargement: string;
      messageIncitation: string;
      raisonIndisponible: string | null;
    }>('/video-ads/test/status'),

  lancer: (brief: { brandName?: string; activite?: string }) =>
    request<{
      videoAdId: string;
      jobId: string;
      dureeSecondes: number;
      creditsDebites: number;
      messageIncitation: string;
      telechargementAutorise: false;
    }>('/video-ads/test', { method: 'POST', body: JSON.stringify(brief) }),

  /** Lecture en streaming — jamais d'URL de fichier directe. */
  streamUrl: (videoAdId: string) => `${API_BASE}/video-ads/${videoAdId}/stream`,
};

/**
 * Textes client figés, servis par le backend (source unique).
 * Le frontend ne duplique jamais ces libellés en dur : une correction de
 * formulation s'applique ainsi partout sans redéploiement.
 */
export const textesApi = {
  get: () =>
    request<{
      apercu: { casNormal: string; casCasse: string; boutonAmeliorer: string; boutonMettreEnLigne: string };
      verrous: Record<string, string>;
      videoTest: { incitation: string; telechargementVerrouille: string };
      bandeaux: { bienvenueEssai: string };
      retrait: { compteNexai: string; lienPersonnel: string };
      hub: { intro: string; trouverBusiness: string; creerLogo: string; creerSite: string };
    }>('/textes'),
};

/** Avis déposés par les clients — alimente le bouton « Avis ». */
export const avisClientApi = {
  mien: () =>
    request<{ avis: { id: string; content: string; rating: number; role: string } | null }>(
      '/avis/mien'
    ),
  publier: (payload: { content: string; rating: number; role?: string }) =>
    request<{ avis: unknown; modifie: boolean }>('/avis', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
};

/** Administration — sécurité du compte, incidents, avis générés. */
export const adminBoutiquePacksApi = {
  list: () =>
    request<{
      packs: {
        id: string; titre: string; sousTitre: string; description: string;
        creditsCost: number; ordre: number; status: string; nbProduits: number;
      }[];
    }>('/admin/boutique/packs'),
  creer: (body: { titre: string; sousTitre?: string; description?: string; creditsCost?: number; ordre?: number }) =>
    request('/admin/boutique/packs', { method: 'POST', body: JSON.stringify(body) }),
  modifier: (id: string, body: Record<string, unknown>) =>
    request(`/admin/boutique/packs/${id}`, { method: 'PATCH', body: JSON.stringify(body) }),
  supprimer: (id: string) =>
    request(`/admin/boutique/packs/${id}`, { method: 'DELETE' }),
  /** Import ZIP ou fichiers PDF multiples — les deux passent par ce même appel. */
  importer: async (packId: string, fichiers: File[], creditsCost = 0) => {
    const fd = new FormData();
    fichiers.forEach((f) => fd.append('fichiers', f));
    fd.append('creditsCost', String(creditsCost));
    const res = await fetch(`${API_BASE}/admin/boutique/packs/${packId}/import`, {
      method: 'POST',
      credentials: 'include',
      body: fd,
    });
    if (!res.ok) {
      let msg = `Erreur ${res.status}`;
      try { const b = await res.json(); msg = b.error?.message || b.message || msg; } catch {}
      throw new ApiError(msg, res.status);
    }
    return res.json() as Promise<{ crees: number; echecs: string[]; note: string }>;
  },
};

export const adminSecuriteApi = {
  statut: () =>
    request<{ emailActuel: string; codeRequisAuProchainChangement: boolean; explication: string }>(
      '/admin/securite'
    ),
  demanderChangementEmail: (nouvelEmail: string) =>
    request<{ applique: boolean; codeEnvoye: boolean; message: string }>('/admin/securite/email', {
      method: 'POST',
      body: JSON.stringify({ nouvelEmail }),
    }),
  confirmerEmail: (code: string) =>
    request<{ emailActuel: string }>('/admin/securite/email/confirmer', {
      method: 'POST',
      body: JSON.stringify({ code }),
    }),

  incidents: (statut?: string) =>
    request<{
      incidents: {
        id: string;
        statut: string;
        gravite: string;
        composant: string;
        erreur: string;
        contexte: string | null;
        occurrences: number;
        causeProbable: string | null;
        pisteCorrection: string | null;
        fichiersSuspects: string[];
        derniereOccurrence: string;
        compteRenduAgent: string | null;
      }[];
    }>(`/admin/incidents${statut ? `?statut=${statut}` : ''}`),

  approuverIncident: (id: string) =>
    request(`/admin/incidents/${id}/approuver`, { method: 'POST' }),
  refuserIncident: (id: string) => request(`/admin/incidents/${id}/refuser`, { method: 'POST' }),
  resoudreIncident: (id: string) => request(`/admin/incidents/${id}/resolu`, { method: 'POST' }),

  genererAvis: (nombre: number) =>
    request<{ crees: number; avis: { name: string; role: string; content: string; rating: number }[] }>(
      '/admin/avis/generer',
      { method: 'POST', body: JSON.stringify({ nombre }) }
    ),
  avisStats: () =>
    request<{
      avisClients: number;
      avisGeneres: number;
      avisClientsNegatifs: number;
      noteMoyenneClients: number | null;
      note: string;
    }>('/admin/avis/stats'),

  qualityReport: (jours = 30) =>
    request<Record<string, unknown>>(`/admin/quality-report?jours=${jours}`),
  equipeIa: () => request<{ roles: unknown }>('/admin/equipe-ia'),
  setModele: (role: string, model: string) =>
    request(`/admin/equipe-ia/${role}`, { method: 'PATCH', body: JSON.stringify({ model }) }),
  logs: (params?: { categorie?: string; niveau?: string }) => {
    const q = new URLSearchParams(params as Record<string, string>).toString();
    return request<{ logs: unknown[]; emailDestination: string | null }>(
      `/admin/logs${q ? `?${q}` : ''}`
    );
  },
  reversements: () => request<{ clients: unknown[] }>('/admin/reversements'),
  marquerReverse: (userId: string, payload: { amountFcfa: number; reference?: string }) =>
    request(`/admin/reversements/${userId}/marquer-reverse`, {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
};
