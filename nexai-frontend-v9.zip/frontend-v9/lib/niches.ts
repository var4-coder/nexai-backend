/** Libellés simples et compréhensibles pour le client */
export const NICHES = [
  {
    id: 'hotellerie_evenementiel',
    label: 'Hôtel, chambre d’hôtes, mariage, événements',
    short: 'Hôtellerie & Événements',
  },
  {
    id: 'sante_bienetre',
    label: 'Santé, bien-être, yoga, coaching',
    short: 'Santé & Bien-être',
  },
  {
    id: 'immobilier_architecture',
    label: 'Immobilier, architecture, décoration',
    short: 'Immobilier & Architecture',
  },
  {
    id: 'services_locaux',
    label: 'Artisan, coiffeur, garage, services de proximité',
    short: 'Services de proximité',
  },
  {
    id: 'business_vitrine',
    label: 'Cabinet, conseil, avocat, expert-comptable',
    short: 'Cabinet & Conseil',
  },
  {
    id: 'ecommerce_mode',
    label: 'Boutique en ligne (mode, beauté, lifestyle)',
    short: 'Boutique en ligne',
  },
  {
    id: 'portfolio_creatif',
    label: 'Photographe, designer, artiste, créatif',
    short: 'Créatif & Portfolio',
  },
  {
    id: 'tech_startup_saas',
    label: 'Application, logiciel, startup tech',
    short: 'Tech & Logiciel',
  },
  {
    id: 'restaurant_gastronomie',
    label: 'Restaurant, café, bar, traiteur',
    short: 'Restaurant & Gastronomie',
  },
  {
    id: 'education_formation',
    label: 'Formation, école, coaching business, e-learning',
    short: 'Formation & Éducation',
  },
] as const;

export type NicheId = (typeof NICHES)[number]['id'];

export function getNicheLabel(id: string): string {
  return NICHES.find((n) => n.id === id)?.short ?? id;
}
