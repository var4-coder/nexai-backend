import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

const API_BASE = (process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1').replace(
  /\/$/,
  ''
);

// Pages accessibles sans être connecté
const publicPaths = [
  '/',
  '/login',
  '/register',
  '/login/mot-de-passe-oublie',
  '/register/verifier',
  '/landing-nexai.html',
];

function isPublicPath(pathname: string) {
  return publicPaths.some((p) => pathname === p || pathname.startsWith(`${p}/`));
}

/**
 * Page d'accueil = landing variant B (corrections Premium + hero).
 * Rewrite / → /landing-nexai.html (fichier dans public/).
 *
 * Garde d'authentification : on interroge le backend (/users/me) en
 * transmettant les cookies de la requête entrante. Si la session est
 * invalide/absente sur une page privée, on redirige vers /login.
 * En cas d'échec réseau vers le backend, on laisse passer (fail-open)
 * pour ne pas bloquer l'appli si l'API est momentanément indisponible :
 * DashboardShell fait alors le contrôle côté client en filet de sécurité.
 */
export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  if (
    pathname.startsWith('/_next') ||
    pathname.startsWith('/api') ||
    (pathname.includes('.') && pathname !== '/')
  ) {
    return NextResponse.next();
  }

  if (pathname === '/') {
    return NextResponse.rewrite(new URL('/landing-nexai.html', request.url));
  }

  if (isPublicPath(pathname)) {
    return NextResponse.next();
  }

  const cookieHeader = request.headers.get('cookie');

  try {
    const res = await fetch(`${API_BASE}/users/me`, {
      headers: cookieHeader ? { cookie: cookieHeader } : {},
    });

    if (!res.ok) {
      const loginUrl = new URL('/login', request.url);
      loginUrl.searchParams.set('next', pathname);
      return NextResponse.redirect(loginUrl);
    }
  } catch {
    return NextResponse.next();
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
};
