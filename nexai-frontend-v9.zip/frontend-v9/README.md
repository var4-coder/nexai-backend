# NexAI Frontend v2 — complet

## Page d'accueil
- **/** = **Landing variant B** (`public/landing-nexai.html`)
- Badge **Premium** sur Pro Max
- Hero `object-position: 55% 28%` (têtes non coupées)
- Middleware réécrit `/` → `/landing-nexai.html`

## Corrections incluses
- Hub IA & Création : Créer un site / Créer un logo + lien Vidéo IA (Pro Max)
- Page `/video` : interface Vidéo IA séparée (9:16 / 16:9, URL site optionnelle)
- Sidebar : Abonnement, Crédits, **Paiements**, Vidéo IA, Domaines, etc.
- Paramètres → onglet **Paiements** (lien Chariow perso OU recevoir via NexAI : Mobile Money / crypto, reversement 3 j)
- Domaines : 3 options (sous-domaine / acheter / déjà un domaine)
- Guide mis à jour (paiements)

## Lancer
```bash
npm install
# configurer .env.local (URL API backend)
npm run dev
```

## Pages
`/` landing B · `/login` · `/register` · `/dashboard` · `/sites` · `/assistant` · `/video` · `/domaines` · `/academy` · `/boutique` · `/analytics` · `/seo` · `/agence` · `/agence/clients/[id]` · `/guide` · `/parametres` · `/aide` · `/admin`

## Corrections de compatibilité backend (dernière passe)
Cette version corrige plusieurs incohérences entre le frontend et les routes
réelles du backend (`src/routes/*.ts`), vérifiées route par route :

- **Mise en ligne d'un site** : le formulaire de `/sites/[id]/parametres`
  envoie désormais exactement les champs attendus par `POST /sites/:id/lancer`
  (`domainType`, `subdomainSlug`, `paymentMode`). Les boutons "Mettre en
  ligne" des autres pages renvoient vers ce formulaire au lieu d'appeler
  l'API sans domaine ni mode de paiement (ce qui échouait systématiquement).
- **`lib/api.ts`** complété : génération de logo (`logosApi`), vidéos IA
  (`videoAdsApi`), achat de packs de crédits (`creditsApi.acheter`), stats /
  édition rapide agence (`agencyApi.stats`, `agencyApi.quickEditSite`),
  métadonnées Academy correctement typées avec `toBackendUrl()` pour
  résoudre les URLs de streaming protégées par token.
- **Domaines** : appelle la vraie route `/domains/variants` au lieu de
  générer des résultats aléatoires côté client.
- **Boutique** : achat réellement fonctionnel (`boutiqueApi.purchase`),
  ouverture du lien de téléchargement renvoyé par le backend.
- **Academy** : le lecteur PDF/vidéo utilise les champs réels renvoyés par
  `GET /academy/:id` (`streamUrl`, `embedHint`) au lieu de champs qui
  n'existent pas côté backend.
- **Espace Agence** : la fiche client (`/agence/clients/[id]`), référencée
  depuis la liste mais absente du projet, a été créée.
- **Assistant IA** : le `siteId` est transmis à la génération de logo quand
  elle a lieu dans le flux de création de site, pour que le logo soit bien
  rattaché au site côté backend.
- **Paramètres** : les packs de crédits ouvrent un vrai lien de paiement
  Chariow ; le rafraîchissement du profil après sauvegarde des réglages de
  paiement fonctionne (bug de nommage corrigé).
- Suppression des données de démonstration affichées silencieusement en cas
  d'erreur API (Boutique, Agence, Admin, Assistance, Academy) — remplacées
  par de vrais messages d'erreur avec bouton "Réessayer", pour ne jamais
  montrer de fausses informations à l'utilisateur.
- Admin : édition réelle du plan et des crédits d'un utilisateur (l'API le
  permettait déjà, l'interface ne l'exposait pas) ; les réponses et
  clôtures de tickets support affichent une vraie erreur en cas d'échec au
  lieu de simuler un succès local.
- `eslint` + `eslint-config-next` ajoutés aux dépendances pour que
  `npm run lint` fonctionne (la commande existait mais le paquet manquait).
