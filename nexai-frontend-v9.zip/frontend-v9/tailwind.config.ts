import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#0A0B0F',
        bg: '#0A0B0F',
        panel: '#12141A',
        card: '#16181F',
        cardHover: '#1C1E27',
        muted: '#8B92A5',
        line: '#23262F',
        lineLt: '#2A2D38',
        blue: '#1D4ED8',
        blueDark: '#15308A',
        blueSoft: 'rgba(29,78,216,0.14)',
        mint: '#35D68C',
        mintSoft: 'rgba(53,214,140,0.12)',
        red: '#FF5C5C',
        redSoft: 'rgba(255,92,92,0.12)',
        amber: '#F5A623',
        amberSoft: 'rgba(245,166,35,0.12)',
      },
      fontFamily: {
        sans: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'],
        display: ['"Bricolage Grotesque"', '"Plus Jakarta Sans"', 'sans-serif'],
      },
      boxShadow: {
        card: '0 1px 0 0 rgba(255,255,255,0.03), 0 4px 24px rgba(0,0,0,0.25)',
        soft: '0 8px 32px rgba(0,0,0,0.35)',
        /* Elevation scale — depth only, no new colors. Used to give the UI
           a sense of physical layering (resting vs raised vs floating). */
        'elev-1': '0 1px 2px rgba(0,0,0,0.2), 0 1px 0 0 rgba(255,255,255,0.03) inset',
        'elev-2': '0 1px 2px rgba(0,0,0,0.25), 0 12px 32px -12px rgba(0,0,0,0.55), 0 1px 0 0 rgba(255,255,255,0.04) inset',
        'elev-3': '0 2px 4px rgba(0,0,0,0.3), 0 24px 56px -16px rgba(0,0,0,0.65), 0 1px 0 0 rgba(255,255,255,0.05) inset',
        'elev-4': '0 4px 8px rgba(0,0,0,0.35), 0 40px 80px -20px rgba(0,0,0,0.7), 0 1px 0 0 rgba(255,255,255,0.06) inset',
      },
      borderRadius: {
        xl: '12px',
        '2xl': '16px',
      },
      transitionTimingFunction: {
        'out-back': 'cubic-bezier(0.34, 1.56, 0.64, 1)',
        'smooth': 'cubic-bezier(0.4, 0, 0.2, 1)',
      },
      keyframes: {
        pageIn: {
          '0%': { opacity: '0', transform: 'translateY(8px) scale(0.996)' },
          '100%': { opacity: '1', transform: 'translateY(0) scale(1)' },
        },
        staggerIn: {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        floatGlow: {
          '0%, 100%': { transform: 'translate(0, 0)' },
          '50%': { transform: 'translate(2%, 1.5%)' },
        },
      },
      animation: {
        'page-in': 'pageIn 0.5s cubic-bezier(0.4, 0, 0.2, 1) both',
        'stagger-in': 'staggerIn 0.45s cubic-bezier(0.4, 0, 0.2, 1) both',
        'float-glow': 'floatGlow 18s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};

export default config;
