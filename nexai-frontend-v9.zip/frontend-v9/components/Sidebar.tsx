'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { planHasAgencyAccess, planHasIA, planHasAnalytics, planHasVideoAccess, isFormationOnlyPlan, isAdmin } from '@/lib/plans';

const ICON = {
  // Méthode de retrait — reversement des gains du client (section 12)
  payout: (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="6" width="20" height="13" rx="2" />
      <path d="M2 10h20M6 15h4" />
    </svg>
  ),
  dashboard: (
    <svg className="w-5 h-5 nav-icon-lift" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
    </svg>
  ),
  sites: (
    <svg className="w-5 h-5 nav-icon-lift" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
    </svg>
  ),
  ia: (
    <svg className="w-5 h-5 nav-icon-lift" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
    </svg>
  ),
  domains: (
    <svg className="w-5 h-5 nav-icon-lift" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
    </svg>
  ),
  academy: (
    <svg className="w-5 h-5 nav-icon-lift" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
    </svg>
  ),
  video: (
    <svg className="w-5 h-5 nav-icon-lift" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
    </svg>
  ),
  boutique: (
    <svg className="w-5 h-5 nav-icon-lift" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
    </svg>
  ),
  analytics: (
    <svg className="w-5 h-5 nav-icon-lift" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
    </svg>
  ),
  seo: (
    <svg className="w-5 h-5 nav-icon-lift" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
    </svg>
  ),
  agency: (
    <svg className="w-5 h-5 nav-icon-lift" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
    </svg>
  ),
  settings: (
    <svg className="w-5 h-5 nav-icon-lift" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
  ),
  admin: (
    <svg className="w-5 h-5 nav-icon-lift" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
    </svg>
  ),
  help: (
    <svg className="w-5 h-5 nav-icon-lift" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  ),
  credits: (
    <svg className="w-5 h-5 nav-icon-lift" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  ),
  subscription: (
    <svg className="w-5 h-5 nav-icon-lift" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
    </svg>
  ),
  guide: (
    <svg className="w-5 h-5 nav-icon-lift" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
    </svg>
  ),
};

export default function Sidebar() {
  const pathname = usePathname();
  const { user, logout } = useAuth();
  const plan = user?.plan;

  const isActive = (href: string) =>
    pathname === href || (href !== '/dashboard' && pathname?.startsWith(href));

  const NavItem = ({
    href,
    label,
    icon,
    locked,
    teaserLabel,
  }: {
    href: string;
    label: string;
    icon: React.ReactNode;
    /** Complètement bloqué : non cliquable (fonctionnalité totalement indisponible). */
    locked?: boolean;
    /**
     * "Voir sans pouvoir goûter" : la page reste accessible en un clic (pour
     * donner envie), mais un badge indique l'abonnement requis pour l'utiliser
     * réellement. Utilisé par ex. pour Vidéo IA sur Starter / Créateur.
     */
    teaserLabel?: string;
  }) => {
    if (locked) {
      return (
        <div
          className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-muted/50 cursor-not-allowed"
          title="Réservé à un abonnement supérieur"
        >
          {icon}
          <span>{label}</span>
          <span className="ml-auto text-xs">🔒</span>
        </div>
      );
    }
    return (
      <Link
        href={href}
        className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${
          isActive(href)
            ? 'bg-blueSoft text-blue font-medium'
            : 'text-muted hover:text-white hover:bg-white/5'
        }`}
      >
        {icon}
        <span>{label}</span>
        {teaserLabel && (
          <span
            className="ml-auto text-[10px] px-1.5 py-0.5 rounded bg-blue/15 text-blue font-semibold shrink-0"
            title={`Fonctionnalité réservée à l’abonnement ${teaserLabel} — vous pouvez découvrir l’interface, la génération reste bloquée jusqu’à l’upgrade.`}
          >
            {teaserLabel}
          </span>
        )}
      </Link>
    );
  };

  const initials = user?.name
    ? user.name.slice(0, 2).toUpperCase()
    : user?.email?.slice(0, 2).toUpperCase() || 'JD';

  return (
    <aside className="w-60 shrink-0 border-r border-line min-h-screen flex flex-col bg-bg">
      <div className="px-5 py-6">
        <Link href="/dashboard" className="flex items-center gap-2.5">
          <img src="/brand/nexai-logo.svg" alt="NexAI" className="h-6 w-auto" />
        </Link>
      </div>

      <nav className="flex-1 px-3 space-y-0.5 overflow-y-auto">
        {/* Navigation — ordre FIGÉ de l'Architecture v6, section 19.
            Tous les plans voient la même liste : ce qui n'est pas inclus
            reste visible avec une icône verrouillée, jamais masqué.
            Seule exception : « Agence », structurellement absent hors
            plan Agence/Pro Max. */}
        <NavItem href="/dashboard" label="Tableau de bord" icon={ICON.dashboard} />
        <NavItem href="/creer-un-site" label="Créer un site" icon={ICON.ia} />
        <NavItem href="/sites" label="Mes sites" icon={ICON.sites} />
        <NavItem href="/video" label="Vidéo IA" icon={ICON.video} />
        <NavItem href="/academy" label="Académie" icon={ICON.academy} />
        <NavItem href="/boutique" label="Boutique" icon={ICON.boutique} />
        <NavItem href="/aide" label="Assistance NexAI" icon={ICON.help} />
        <NavItem href="/analytics" label="Analytics & SEO" icon={ICON.analytics} />
        <NavItem href="/domaines" label="Domaines" icon={ICON.domains} />
        <NavItem href="/guide" label="Guide" icon={ICON.guide} />
        {(plan === 'agence' || plan === 'pro_max' || user?.role === 'admin') && (
          <NavItem href="/agence" label="Agence" icon={ICON.agency} />
        )}
        <NavItem href="/credits" label="Crédits" icon={ICON.credits} />
        <NavItem href="/abonnement" label="Abonnement" icon={ICON.subscription} />
        <NavItem href="/retrait" label="Méthode de retrait" icon={ICON.payout} />
        <NavItem href="/parametres" label="Paramètres" icon={ICON.settings} />
        {user?.role === 'admin' && (
          <NavItem href="/admin" label="Administration" icon={ICON.admin} />
        )}
      </nav>

      {/* User footer */}
      <div className="p-4 border-t border-line">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-blueSoft text-blue flex items-center justify-center text-xs font-semibold">
            {initials}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-medium truncate">
              {user?.name || user?.email?.split('@')[0] || 'Utilisateur'}
            </div>
            <div className="text-xs text-muted truncate">{user?.email}</div>
          </div>
        </div>
        <div className="mt-3 flex items-center justify-between text-xs gap-2">
          <Link
            href="/parametres?tab=credits"
            className="text-blue font-medium hover:underline"
            title="Voir et recharger mes crédits"
          >
            {user?.creditsBalance ?? 0} crédits
          </Link>
          <button onClick={logout} className="text-muted hover:text-white transition-colors">
            Déconnexion
          </button>
        </div>
      </div>
    </aside>
  );
}
