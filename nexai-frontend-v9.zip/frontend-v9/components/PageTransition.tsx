'use client';

import { usePathname } from 'next/navigation';

/**
 * Enveloppe purement visuelle : rejoue une animation d'entrée à chaque
 * changement de route (via la key=pathname qui force un remount du div).
 * Ne touche à aucune logique, aucun texte, aucun bouton — juste le
 * rendu du conteneur.
 */
export default function PageTransition({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  return (
    <div key={pathname} className="page-transition">
      {children}
    </div>
  );
}
