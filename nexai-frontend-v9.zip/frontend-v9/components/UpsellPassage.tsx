'use client';

import Link from 'next/link';

/**
 * Unique point de passerelle pour les comptes Starter (Académie uniquement).
 * Un seul encart, discret, pas un mur de cadenas : une invitation à passer à
 * la pratique (Créateur), avec une mention plus légère pour Agence/Pro Max.
 *
 * À afficher à UN SEUL endroit dans le parcours (ex. Tableau de bord) pour
 * ne pas devenir intrusif — ne pas dupliquer sur toutes les pages Académie.
 */
export default function UpsellPassage() {
  return (
    <div className="card p-6 border border-blue/25 bg-gradient-to-br from-blue/[0.06] to-transparent">
      <div className="flex items-start gap-4">
        <div className="w-11 h-11 rounded-xl bg-blue/15 text-blue flex items-center justify-center text-xl shrink-0">
          🚀
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-base mb-1">
            Envie de passer à la pratique ?
          </h3>
          <p className="text-sm text-muted leading-relaxed">
            Lancez votre site avec l’IA NexAI — l’assistant vous propose même des{' '}
            <strong className="text-white">idées de business qui marchent déjà sur le marché</strong>{' '}
            si vous ne savez pas encore par où commencer.
          </p>

          <Link
            href="/parametres?tab=abonnement"
            className="btn-primary rounded-lg px-5 py-2.5 text-sm font-semibold inline-block mt-4"
          >
            Passer à l’abonnement Créateur
          </Link>

          <p className="text-xs text-muted mt-4 pt-4 border-t border-line/60">
            Envie d’aller plus loin ? Avec{' '}
            <Link href="/parametres?tab=abonnement" className="text-blue hover:underline">
              Agence ou Pro Max
            </Link>
            , l’IA génère aussi vos vidéos de pub et votre contenu automatiquement.
          </p>
        </div>
      </div>
    </div>
  );
}
