'use client';

import { useEffect, useRef, useState, useCallback } from 'react';

/**
 * Viewer PDF sécurisé pour l'Académie NexAI.
 *
 * Principe : le PDF n'est JAMAIS donné au navigateur en tant que fichier
 * (pas de <embed>, pas de <iframe src=pdf>, pas de lien direct). On récupère
 * les octets nous-mêmes via fetch() (cookies d'auth inclus), on les passe à
 * pdf.js, et on dessine chaque page sur un <canvas>. Le résultat visible à
 * l'écran n'est qu'une image bitmap : pas de lecteur PDF natif, donc pas de
 * bouton "Enregistrer" / "Imprimer" fourni par le navigateur, pas de texte
 * sélectionnable/copiable, pas d'URL de fichier à copier ou ouvrir ailleurs.
 *
 * Protections cumulées (aucune n'est individuellement infranchissable face à
 * un utilisateur très déterminé avec les outils développeur — mais ensemble
 * elles éliminent tout contournement "grand public" en un clic) :
 *  - Rendu bitmap uniquement (canvas), pas de couche texte pdf.js.
 *  - Menu contextuel désactivé sur toute la zone (pas de "Enregistrer l'image sous…").
 *  - Glisser-déposer désactivé (pas de drag d'image vers le bureau).
 *  - Sélection de texte désactivée (CSS user-select: none).
 *  - Raccourcis clavier bloqués : Ctrl/Cmd+S (enregistrer), Ctrl/Cmd+P (imprimer),
 *    Ctrl/Cmd+Shift+S, touche Impr. écran (best-effort).
 *  - Filigrane superposé (nom/email + date), non lié au DOM du canvas donc
 *    inséparable d'une capture d'écran, en plus du filigrane déjà imprimé
 *    dans les pixels du PDF côté backend (services/pdf-watermark.service.ts).
 *  - Le fichier lui-même n'est jamais exposé : le backend ne sert que via un
 *    token de vue à courte durée (2 min) qui revérifie l'accès à chaque appel
 *    (voir academy-viewer.service.ts) — ce composant ne fait que consommer ce
 *    flux, il ne connaît jamais l'URL Cloudinary réelle.
 */

interface SecurePdfViewerProps {
  /** URL backend du flux protégé (déjà signée avec le token de vue). */
  url: string;
  /** Texte de filigrane (ex. "prenom@email.com — NexAI Académie"). */
  watermarkText?: string;
}

const MIN_SCALE = 0.6;
const MAX_SCALE = 2.2;
const SCALE_STEP = 0.15;
const DEFAULT_SCALE = 1.15;

export default function SecurePdfViewer({ url, watermarkText }: SecurePdfViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const renderTokenRef = useRef(0);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [numPages, setNumPages] = useState(0);
  const [scale, setScale] = useState(DEFAULT_SCALE);
  const [watermarkDataUri, setWatermarkDataUri] = useState('');

  // Filigrane en pattern SVG répété (tuilé en arrière-plan) — couvre toute la
  // hauteur du document quel que soit le nombre de pages, sans dépendre du DOM.
  useEffect(() => {
    if (!watermarkText) {
      setWatermarkDataUri('');
      return;
    }
    const stamped = `${watermarkText} · ${new Date().toLocaleDateString('fr-FR')}`;
    const escaped = stamped.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="340" height="200">
      <text x="10" y="110" transform="rotate(-28 170,100)" font-size="13" font-family="sans-serif" fill="rgba(120,120,140,0.16)">${escaped}</text>
    </svg>`;
    setWatermarkDataUri(`data:image/svg+xml,${encodeURIComponent(svg)}`);
  }, [watermarkText]);

  // Chargement + rendu du document sur canvas.
  useEffect(() => {
    let cancelled = false;
    const myToken = ++renderTokenRef.current;
    setLoading(true);
    setError('');
    setNumPages(0);

    async function load() {
      try {
        const pdfjsLib = await import('pdfjs-dist');
        // Worker chargé en asset séparé (recommandé pdf.js + webpack5/Next.js) —
        // le rendu se fait hors du thread principal, jamais via une URL de
        // fichier accessible depuis un onglet Réseau exploitable directement.
        pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
          'pdfjs-dist/build/pdf.worker.min.mjs',
          import.meta.url
        ).toString();

        const res = await fetch(url, { credentials: 'include', cache: 'no-store' });
        if (!res.ok) {
          throw new Error(
            res.status === 401
              ? 'Session expirée, rechargez la page.'
              : "Impossible de charger le document."
          );
        }
        const buf = await res.arrayBuffer();
        if (cancelled || myToken !== renderTokenRef.current) return;

        const pdf = await pdfjsLib.getDocument({ data: buf }).promise;
        if (cancelled || myToken !== renderTokenRef.current) return;

        setNumPages(pdf.numPages);

        const container = containerRef.current;
        if (!container) return;
        container.innerHTML = '';

        for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
          if (cancelled || myToken !== renderTokenRef.current) return;
          const page = await pdf.getPage(pageNum);
          const viewport = page.getViewport({ scale });

          const canvas = document.createElement('canvas');
          const dpr = Math.min(window.devicePixelRatio || 1, 2);
          canvas.width = viewport.width * dpr;
          canvas.height = viewport.height * dpr;
          canvas.style.width = '100%';
          canvas.style.height = 'auto';
          canvas.className = 'rounded-md shadow-lg mb-3 block mx-auto select-none';
          canvas.oncontextmenu = (e) => e.preventDefault();
          canvas.ondragstart = (e) => e.preventDefault();

          const ctx = canvas.getContext('2d');
          if (!ctx) continue;
          ctx.scale(dpr, dpr);

          await page.render({ canvasContext: ctx, viewport }).promise;
          if (cancelled || myToken !== renderTokenRef.current) return;
          container.appendChild(canvas);
        }

        if (!cancelled && myToken === renderTokenRef.current) setLoading(false);
      } catch (err) {
        if (!cancelled) {
          setError((err as Error)?.message || 'Erreur de chargement du document.');
          setLoading(false);
        }
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [url, scale]);

  // Raccourcis clavier bloqués tant que le viewer est monté (enregistrer,
  // imprimer, capture, "voir la source"). Best-effort : un utilisateur avec
  // les outils développeur pourra toujours contourner — voir note en tête.
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      const k = e.key.toLowerCase();
      const mod = e.ctrlKey || e.metaKey;
      const blocked =
        (mod && (k === 's' || k === 'p' || k === 'u')) ||
        (mod && e.shiftKey && k === 's') ||
        k === 'printscreen';
      if (blocked) {
        e.preventDefault();
        e.stopPropagation();
      }
    }
    window.addEventListener('keydown', onKeyDown, true);
    return () => window.removeEventListener('keydown', onKeyDown, true);
  }, []);

  const zoomIn = useCallback(() => setScale((s) => Math.min(MAX_SCALE, +(s + SCALE_STEP).toFixed(2))), []);
  const zoomOut = useCallback(() => setScale((s) => Math.max(MIN_SCALE, +(s - SCALE_STEP).toFixed(2))), []);

  return (
    <div className="card p-2 overflow-hidden">
      <div className="flex items-center justify-between px-2 py-1.5 border-b border-white/5 mb-2">
        <span className="text-xs text-muted">
          {loading ? 'Chargement…' : numPages ? `${numPages} page${numPages > 1 ? 's' : ''}` : ''}
        </span>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={zoomOut}
            disabled={loading || !!error}
            className="w-7 h-7 rounded-md bg-white/5 hover:bg-white/10 disabled:opacity-40 text-sm"
            aria-label="Zoom arrière"
          >
            −
          </button>
          <span className="text-xs text-muted w-10 text-center">{Math.round(scale * 100)}%</span>
          <button
            type="button"
            onClick={zoomIn}
            disabled={loading || !!error}
            className="w-7 h-7 rounded-md bg-white/5 hover:bg-white/10 disabled:opacity-40 text-sm"
            aria-label="Zoom avant"
          >
            +
          </button>
        </div>
      </div>

      <div
        className="relative select-none"
        style={{ userSelect: 'none', WebkitUserSelect: 'none' }}
        onContextMenu={(e) => e.preventDefault()}
        onDragStart={(e) => e.preventDefault()}
      >
        {loading && (
          <div className="flex flex-col items-center justify-center py-20 gap-3">
            <div className="w-8 h-8 border-2 border-blue border-t-transparent rounded-full animate-spin" />
            <p className="text-xs text-muted">Chargement sécurisé du document…</p>
          </div>
        )}

        {error && (
          <div className="py-16 text-center px-6">
            <p className="text-red text-sm">{error}</p>
          </div>
        )}

        <div
          ref={containerRef}
          className="pdf-canvas-container overflow-y-auto"
          style={{ maxHeight: '80vh', display: loading || error ? 'none' : 'block' }}
        />

        {!loading && !error && watermarkDataUri && (
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0"
            style={{
              backgroundImage: `url("${watermarkDataUri}")`,
              backgroundRepeat: 'repeat',
              mixBlendMode: 'normal',
            }}
          />
        )}
      </div>

      <p className="text-xs text-muted text-center mt-2 py-1">
        Contenu réservé à la consultation — téléchargement et impression désactivés. Document filigrané à
        votre nom.
      </p>
    </div>
  );
}
