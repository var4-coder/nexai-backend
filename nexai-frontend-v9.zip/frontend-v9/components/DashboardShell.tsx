'use client';

import { useAuth } from '@/lib/auth-context';
import Sidebar from './Sidebar';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

export default function DashboardShell({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) {
      router.replace('/login');
    }
  }, [user, loading, router]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-bg">
        <div className="w-8 h-8 border-2 border-blue border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <main className="flex-1 overflow-x-hidden relative">
        {/* Ombre portée très subtile qui sépare le contenu de la sidebar,
            pour renforcer la sensation de calque plutôt qu'un simple trait. */}
        <div
          className="pointer-events-none absolute inset-y-0 left-0 w-6 -translate-x-full"
          style={{ background: 'linear-gradient(90deg, transparent, rgba(0,0,0,0.12))' }}
        />
        {children}
      </main>
    </div>
  );
}
