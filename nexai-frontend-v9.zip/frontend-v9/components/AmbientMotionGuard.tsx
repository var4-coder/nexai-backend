'use client';

import { useEffect } from 'react';

/**
 * Optimisation pure performance : coupe l'animation de fond (glow ambiant)
 * quand l'onglet n'est pas actif, pour ne pas faire tourner le GPU pour
 * rien quand personne ne regarde. Ne rend rien à l'écran, ne touche à
 * aucun texte/bouton/logique existante — juste un attribut sur <html>
 * que globals.css utilise pour mettre l'animation en pause.
 */
export default function AmbientMotionGuard() {
  useEffect(() => {
    const applyState = () => {
      document.documentElement.classList.toggle('tab-hidden', document.hidden);
    };
    applyState();
    document.addEventListener('visibilitychange', applyState);
    return () => document.removeEventListener('visibilitychange', applyState);
  }, []);

  return null;
}
