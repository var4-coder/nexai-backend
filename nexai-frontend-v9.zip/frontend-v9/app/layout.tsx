import type { Metadata } from 'next';
import { AuthProvider } from '@/lib/auth-context';
import PageTransition from '@/components/PageTransition';
import AmbientMotionGuard from '@/components/AmbientMotionGuard';
import './globals.css';

export const metadata: Metadata = {
  title: 'NexAI — Créez votre site pro avec l’IA',
  description:
    'NexAI crée le site professionnel de votre activité en quelques minutes, vous forme au digital avec l’Académie et vous permet de vendre des produits digitaux.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Bricolage+Grotesque:wght@500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen bg-bg text-white antialiased">
        <AmbientMotionGuard />
        <AuthProvider>
          <PageTransition>{children}</PageTransition>
        </AuthProvider>
      </body>
    </html>
  );
}
