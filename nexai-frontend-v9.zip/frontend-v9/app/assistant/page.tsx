'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import Link from 'next/link';
import DashboardShell from '@/components/DashboardShell';
import { useAuth } from '@/lib/auth-context';
import { planHasIA, planHasVideoAccess } from '@/lib/plans';
import { getNicheLabel } from '@/lib/niches';
import { BUSINESS_IDEAS, BUSINESS_DOMAINS } from '@/lib/business-catalog';
import {
  sitesApi,
  logosApi,
  chatApi,
  Site,
  ChatSession,
  ChatMode,
  ChatAttachment,
} from '@/lib/api';

type Mode = 'hub' | ChatMode;

type LogoLibraryItem = {
  id: string;
  url: string;
  brandName: string;
  niche?: string;
  source: 'generated' | 'uploaded';
  chosen: boolean;
  createdAt: string;
};

const MODE_META: Record<ChatMode, { title: string; subtitle: string; icon: string }> = {
  site: { title: 'Créer un site', subtitle: 'Assistant NexAI Web — sites professionnels', icon: '🌐' },
  logo: { title: 'Créer un logo', subtitle: 'Prompts rédigés par l’IA → Recraft', icon: '✦' },
  edit: { title: 'Modifier mes sites', subtitle: 'Textes, régénération, mise en ligne…', icon: '🛠️' },
  business: { title: 'Trouver mon business', subtitle: 'Coach business NexAI', icon: '🧭' },
};

export default function AssistantPage() {
  const { user } = useAuth();
  const hasIA = planHasIA(user?.plan);
  // Vidéo IA : génération réservée à Créateur + Agence + Pro Max, mais l'interface reste
  // ouverte à tous (Starter/Créateur peuvent entrer et découvrir — le blocage
  // porte sur le lancement de la génération, pas sur l'accès à la page).
  const hasVideoAccess = planHasVideoAccess(user?.plan);

  const [mode, setMode] = useState<Mode>('hub');
  const [editPicker, setEditPicker] = useState(false);

  const [sites, setSites] = useState<Site[]>([]);
  const [sitesLoading, setSitesLoading] = useState(true);

  const [logos, setLogos] = useState<LogoLibraryItem[]>([]);
  const [logosLoaded, setLogosLoaded] = useState(false);

  const [session, setSession] = useState<ChatSession | null>(null);
  const [activeSite, setActiveSite] = useState<Site | null>(null); // site scopé en mode edit
  const [pendingLogoAction, setPendingLogoAction] = useState<
    'upload' | 'library' | 'plan_required' | null
  >(null);
  const [editModifyStatus, setEditModifyStatus] = useState<
    'idle' | 'sending' | 'sent' | 'error'
  >('idle');
  const [starting, setStarting] = useState(false);
  const [sending, setSending] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');

  const [input, setInput] = useState('');
  const [pendingAttachments, setPendingAttachments] = useState<ChatAttachment[]>([]);
  const [showCatalog, setShowCatalog] = useState(false);

  const bottomRef = useRef<HTMLDivElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const editableSites = sites.filter((s) => s.status === 'ready' || s.status === 'launched');

  useEffect(() => {
    sitesApi
      .list()
      .then((r) => setSites(r.sites))
      .catch(() => setSites([]))
      .finally(() => setSitesLoading(false));
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [session?.messages?.length, starting]);

  const loadLogos = useCallback(async () => {
    try {
      const r = await logosApi.list();
      setLogos(r.logos as LogoLibraryItem[]);
    } catch {
      setLogos([]);
    } finally {
      setLogosLoaded(true);
    }
  }, []);

  function resetChat() {
    setSession(null);
    setActiveSite(null);
    setInput('');
    setPendingAttachments([]);
    setError('');
    setShowCatalog(false);
    setPendingLogoAction(null);
    setEditModifyStatus('idle');
  }

  /**
   * Bascule vers un autre mode du hub EN GARDANT le contexte de la
   * conversation en cours (utilisé par les CTA de cross-vente, qu'ils
   * soient statiques en fin de flux ou dynamiques via suggestMode).
   * Contrairement à startMode(), ne réinitialise jamais la session.
   */
  async function switchToMode(newMode: ChatMode) {
    if (!session) return;
    setStarting(true);
    setError('');
    try {
      const { session: s } = await chatApi.switchMode(session.id, newMode);
      setMode(newMode);
      setSession(s);
      setPendingLogoAction(null);
      setEditModifyStatus('idle');
      if (newMode === 'logo' || newMode === 'site') {
        loadLogos();
      }
    } catch (e: any) {
      setError(e.message || 'Impossible de changer de mode pour le moment.');
    } finally {
      setStarting(false);
    }
  }

  async function startMode(newMode: ChatMode, opts?: { siteId?: string; prefill?: string }) {
    resetChat();
    setMode(newMode);
    setEditPicker(false);
    setStarting(true);
    if (newMode === 'logo' || newMode === 'site') {
      loadLogos();
    }
    if (opts?.siteId) {
      const found = sites.find((s) => s.id === opts.siteId) || null;
      setActiveSite(found);
    }
    try {
      const { session: s } = await chatApi.start({ mode: newMode, siteId: opts?.siteId });
      setSession(s);
      if (opts?.prefill) {
        await doSend(s.id, opts.prefill);
      }
    } catch (e: any) {
      setError(
        e.message ||
          "Impossible de démarrer l'assistant pour le moment. Réessayez dans un instant."
      );
      setMode('hub');
    } finally {
      setStarting(false);
    }
  }

  async function doSend(sessionId: string, text: string, attachments?: ChatAttachment[]) {
    setSending(true);
    setError('');
    try {
      const { session: updated } = await chatApi.message(sessionId, text, attachments);
      setSession(updated);
    } catch (e: any) {
      setError(e.message || "Erreur lors de l'envoi du message.");
    } finally {
      setSending(false);
    }
  }

  function handleSend() {
    if (!session) return;
    if (!input.trim() && pendingAttachments.length === 0) return;
    const text = input.trim();
    const atts = pendingAttachments;
    setInput('');
    setPendingAttachments([]);
    doSend(session.id, text, atts.length ? atts : undefined);
  }

  function handleOption(label: string) {
    if (!session) return;
    doSend(session.id, label);
  }

  async function handleConfirm(confirmed: boolean) {
    if (!session) return;
    setConfirming(true);
    setError('');
    try {
      const { session: updated, site, pendingLogoAction: logoAction } = await chatApi.confirm(
        session.id,
        confirmed
      );
      setSession(updated);
      setPendingLogoAction(logoAction);
      if (site) {
        setSites((prev) => {
          const exists = prev.some((s) => s.id === site.id);
          return exists ? prev.map((s) => (s.id === site.id ? site : s)) : [...prev, site];
        });
        setActiveSite(site);
      }
      // Mode "edit" confirmé : la conversation a collecté une demande de
      // modification (résumée dans updated.reviewSummary) — on l'envoie
      // réellement à l'API de modification IA du site, sinon la
      // conversation guidée ne débouche jamais sur une vraie modification.
      if (confirmed && mode === 'edit' && updated.status === 'confirmed' && activeSite) {
        const instruction = updated.reviewSummary?.trim();
        if (instruction) {
          setEditModifyStatus('sending');
          try {
            await sitesApi.aiModify(activeSite.id, instruction);
            setEditModifyStatus('sent');
          } catch (e: any) {
            setEditModifyStatus('error');
            setError(e.message || "Erreur lors de l'envoi de la modification au site.");
          }
        }
      }
    } catch (e: any) {
      setError(e.message || 'Erreur lors de la confirmation.');
    } finally {
      setConfirming(false);
    }
  }

  async function handleFilePick(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file || !session) return;
    setUploading(true);
    setError('');
    try {
      const attachment = await chatApi.upload(session.id, file);
      setPendingAttachments((p) => [...p, attachment]);
    } catch (err: any) {
      setError(err.message || "Erreur lors de l'envoi de la pièce jointe.");
    } finally {
      setUploading(false);
    }
  }

  function removePendingAttachment(idx: number) {
    setPendingAttachments((p) => p.filter((_, i) => i !== idx));
  }

  function applyLibraryLogo(logo: LogoLibraryItem) {
    if (!session) return;
    const label =
      mode === 'logo'
        ? `Je veux utiliser mon logo déjà créé ici : « ${logo.brandName} ».`
        : `Utilise mon logo déjà créé ici pour ce site : « ${logo.brandName} ».`;
    doSend(session.id, label, [{ url: logo.url, type: 'image', name: logo.brandName }]);
  }

  const inputEnabled =
    !!session && !sending && !starting && !confirming && session.status === 'collecting';
  const canConfirm = !!session && session.status === 'reviewing' && !confirming;
  const isConfirmed = !!session && session.status === 'confirmed';

  // ── Starter / pas d'IA ────────────────────────────────────────────
  if (!hasIA) {
    return (
      <DashboardShell>
        <div className="flex items-center justify-center min-h-[80vh] p-8">
          <div className="card max-w-lg p-10 text-center">
            <div className="w-14 h-14 rounded-2xl bg-blueSoft text-blue flex items-center justify-center mx-auto mb-6 text-2xl">
              ✦
            </div>
            <h1 className="text-2xl font-display font-bold mb-3">NexAI IA</h1>
            <p className="text-muted mb-6 leading-relaxed">
              Créez un site web professionnel en quelques minutes grâce à l’intelligence artificielle.
              <br />
              <br />
              Disponible à partir de l’abonnement <strong className="text-white">Créateur</strong>.
            </p>
            <Link
              href="/parametres?tab=abonnement"
              className="btn-primary rounded-lg px-8 py-3 text-sm font-semibold inline-block"
            >
              Voir les abonnements
            </Link>
          </div>
        </div>
      </DashboardShell>
    );
  }

  // ── Hub mode (F1) ─────────────────────────────────────────────────
  if (mode === 'hub') {
    return (
      <DashboardShell>
        <div className="min-h-[calc(100vh-0px)] p-8">
          <div className="max-w-3xl mx-auto">
            <div className="mb-10">
              <h1 className="text-2xl font-display font-bold mb-2">NexAI Web</h1>
              <p className="text-muted">
                Choisissez ce que vous souhaitez faire. Le même assistant s’adapte à votre choix — vous
                pourrez changer de mode à tout moment pendant la conversation.
              </p>
            </div>

            {!editPicker ? (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <button
                    type="button"
                    onClick={() => startMode('site')}
                    className="text-left card p-6 border border-line hover:border-blue transition group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-blue/15 text-blue flex items-center justify-center text-2xl mb-4 group-hover:scale-105 transition">
                      {MODE_META.site.icon}
                    </div>
                    <h2 className="font-semibold text-lg mb-1">Créer un site</h2>
                    <p className="text-sm text-muted leading-relaxed">
                      Brief guidé par l’IA, logo optionnel, propositions de site professionnel.
                    </p>
                  </button>

                  <button
                    type="button"
                    onClick={() => startMode('logo')}
                    className="text-left card p-6 border border-line hover:border-blue transition group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-blue/15 text-blue flex items-center justify-center text-2xl mb-4 group-hover:scale-105 transition">
                      {MODE_META.logo.icon}
                    </div>
                    <h2 className="font-semibold text-lg mb-1">Créer un logo</h2>
                    <p className="text-sm text-muted leading-relaxed">
                      Propositions de logo pro générées par l’IA, à réutiliser sur vos sites.
                    </p>
                  </button>

                  {!sitesLoading && editableSites.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setEditPicker(true)}
                      className="text-left card p-6 border border-line hover:border-blue transition group"
                    >
                      <div className="w-12 h-12 rounded-xl bg-blue/15 text-blue flex items-center justify-center text-2xl mb-4 group-hover:scale-105 transition">
                        {MODE_META.edit.icon}
                      </div>
                      <h2 className="font-semibold text-lg mb-1">Modifier mes sites</h2>
                      <p className="text-sm text-muted leading-relaxed">
                        Choisissez un site en ligne ou prêt, et ajustez-le avec l’IA.
                      </p>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => startMode('business')}
                    className="text-left card p-6 border border-line hover:border-blue transition group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-blue/15 text-blue flex items-center justify-center text-2xl mb-4 group-hover:scale-105 transition">
                      {MODE_META.business.icon}
                    </div>
                    <h2 className="font-semibold text-lg mb-1">Trouver mon business</h2>
                    <p className="text-sm text-muted leading-relaxed">
                      Un Coach IA vous aide à choisir une idée à lancer avec NexAI.
                    </p>
                  </button>
                </div>

                {error && (
                  <div className="text-sm text-red bg-redSoft rounded-lg px-4 py-2.5 mt-4">{error}</div>
                )}

                {/* Lien vers Vidéo IA — interface séparée */}
                <div className="mt-6">
                  <Link
                    href="/video"
                    className="flex items-center gap-4 card p-5 border border-line hover:border-blue transition"
                  >
                    <div className="w-12 h-12 rounded-xl bg-blue/15 text-blue flex items-center justify-center text-2xl">
                      {hasVideoAccess ? '▶' : '🔒'}
                    </div>
                    <div className="flex-1">
                      <h2 className="font-semibold">NexAI Vidéo IA</h2>
                      <p className="text-sm text-muted">
                        {hasVideoAccess
                          ? 'Interface dédiée — pubs 9:16 / 16:9, personnalisation via URL de site.'
                          : 'Découvrez l’interface dès maintenant — génération réservée à Créateur, Agence & Pro Max.'}
                      </p>
                    </div>
                    <span className="text-xs px-2 py-1 rounded bg-blue/20 text-blue font-semibold shrink-0">
                      {hasVideoAccess
                        ? user?.plan === 'pro_max'
                          ? 'Pro Max'
                          : user?.plan === 'agence'
                            ? 'Agence'
                            : 'Créateur'
                        : 'Créateur, Agence & Pro Max'}
                    </span>
                  </Link>
                </div>

                <p className="text-xs text-muted mt-8 text-center">
                  NexAI Web = sites & logos · NexAI Vidéo IA = interface vidéo indépendante
                </p>
              </>
            ) : (
              // ── Sélecteur de site (F5) ─────────────────────────────
              <div>
                <button
                  type="button"
                  onClick={() => setEditPicker(false)}
                  className="text-sm text-muted hover:text-white mb-6"
                >
                  ← Retour
                </button>
                <h2 className="font-semibold text-lg mb-4">Quel site voulez-vous modifier ?</h2>
                <div className="space-y-3">
                  {editableSites.map((site) => (
                    <div
                      key={site.id}
                      className="card p-4 flex items-center justify-between gap-4 flex-wrap"
                    >
                      <div>
                        <div className="font-semibold text-sm">
                          {site.name || getNicheLabel(site.niche)}
                        </div>
                        <div className="text-xs text-muted mt-0.5">
                          {getNicheLabel(site.niche)} ·{' '}
                          {site.status === 'launched' ? 'En ligne' : 'Prêt'}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Link
                          href={`/sites/${site.id}`}
                          className="btn-secondary rounded-lg px-3 py-2 text-xs"
                        >
                          Ouvrir la page du site
                        </Link>
                        <button
                          type="button"
                          onClick={() => startMode('edit', { siteId: site.id })}
                          className="btn-primary rounded-lg px-3 py-2 text-xs font-semibold"
                        >
                          Discuter avec l’IA
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </DashboardShell>
    );
  }

  // ── Chat interface (site / logo / edit / business) — F1-F6 ────────
  const meta = MODE_META[mode as ChatMode];
  const otherModes = (Object.keys(MODE_META) as ChatMode[]).filter((m) => m !== mode);
  const showLogoLibrary =
    (mode === 'logo' || mode === 'site') &&
    session?.status === 'collecting' &&
    logosLoaded &&
    logos.length > 0;

  return (
    <DashboardShell>
      <div className="flex flex-col h-[calc(100vh)]">
        <div className="px-8 py-5 border-b border-line flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => {
                resetChat();
                setMode('hub');
              }}
              className="text-sm text-muted hover:text-white"
            >
              ← Retour
            </button>
            <div>
              <h1 className="text-lg font-semibold">
                {meta.title}
                {activeSite ? ` — ${activeSite.name || getNicheLabel(activeSite.niche)}` : ''}
              </h1>
              <p className="text-xs text-muted">{meta.subtitle}</p>
            </div>
          </div>

          <div className="flex items-center gap-3 text-sm">
            <span className="text-muted hidden sm:inline">{user?.creditsBalance ?? 0} crédits</span>
            <span className="w-2 h-2 rounded-full bg-mint" title="En ligne" />
          </div>
        </div>

        {/* Bascule entre modes (F1 — cross-promo / bascule manuelle) */}
        <div className="px-8 py-2.5 border-b border-line bg-panel/40 flex items-center gap-2 flex-wrap text-xs">
          <span className="text-muted">Basculer vers :</span>
          {otherModes.map((m) => {
            if (m === 'edit' && editableSites.length === 0) return null;
            return (
              <button
                key={m}
                type="button"
                onClick={() => {
                  if (m === 'edit') {
                    setMode('hub');
                    setEditPicker(true);
                    setSession(null);
                    return;
                  }
                  startMode(m);
                }}
                className="px-2.5 py-1 rounded-full border border-line hover:border-blue hover:text-blue transition"
              >
                {MODE_META[m].icon} {MODE_META[m].title}
              </button>
            );
          })}
          {mode === 'business' && (
            <button
              type="button"
              onClick={() => setShowCatalog((v) => !v)}
              className="ml-auto px-2.5 py-1 rounded-full border border-line hover:border-blue hover:text-blue transition"
            >
              {showCatalog ? 'Masquer le catalogue' : 'Voir le catalogue des idées'}
            </button>
          )}
        </div>

        {mode === 'business' && showCatalog && (
          <div className="px-8 py-4 border-b border-line bg-panel/20 text-xs space-y-3 max-h-64 overflow-y-auto">
            <div>
              <div className="font-semibold text-white mb-1.5">5 idées principales</div>
              <div className="grid sm:grid-cols-2 gap-2">
                {BUSINESS_IDEAS.map((idea) => (
                  <div key={idea.id} className="rounded-lg border border-line p-2.5">
                    <div className="font-medium text-white">{idea.title}</div>
                    <div className="text-muted mt-0.5 leading-relaxed">{idea.pitch}</div>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <div className="font-semibold text-white mb-1.5">Domaines complémentaires</div>
              <div className="flex flex-wrap gap-1.5">
                {BUSINESS_DOMAINS.map((d) => (
                  <span key={d.id} className="px-2 py-1 rounded-full bg-panel border border-line">
                    {d.title}
                  </span>
                ))}
              </div>
            </div>
            <p className="text-muted italic">
              Aucune promesse de revenus chiffrés — le Coach vous oriente vers les ressources NexAI
              adaptées (Académie, Boutique, outil vidéo).
            </p>
          </div>
        )}

        <div className="flex-1 overflow-y-auto px-8 py-6 space-y-6">
          {starting && (
            <div className="flex justify-center py-10">
              <div className="w-8 h-8 border-2 border-blue border-t-transparent rounded-full animate-spin" />
            </div>
          )}

          {!starting &&
            session?.messages?.map((msg, i) => (
              <div
                key={i}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] rounded-2xl px-5 py-3 ${
                    msg.role === 'user' ? 'bg-blue text-white' : 'bg-card border border-line'
                  }`}
                >
                  {msg.content && (
                    <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                  )}

                  {msg.attachments && msg.attachments.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {msg.attachments.map((att, ai) =>
                        att.type === 'image' ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img
                            key={ai}
                            src={att.url}
                            alt={att.name || 'Pièce jointe'}
                            className="w-20 h-20 object-cover rounded-lg border border-line/60"
                          />
                        ) : (
                          <a
                            key={ai}
                            href={att.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs px-2.5 py-1.5 rounded-lg bg-panel border border-line hover:border-blue"
                          >
                            📎 {att.name || 'Fichier joint'}
                          </a>
                        )
                      )}
                    </div>
                  )}

                  {msg.options && msg.options.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-3">
                      {msg.options.map((opt, oi) => (
                        <button
                          key={oi}
                          type="button"
                          disabled={sending || confirming}
                          onClick={() => handleOption(opt)}
                          className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-panel border border-line hover:border-blue hover:text-blue transition disabled:opacity-40"
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                  )}

                  {/* CTA dynamique de cross-vente (suggestMode) — proposé par l'IA
                      en cours de conversation, ex: "Voir des idées rentables et
                      légales" (→ business) après un refus compliance, ou "On crée
                      ton site autour de ce logo ?" (→ site) en fin de mode logo.
                      Distinct des boutons statiques de fin de flux ci-dessous :
                      celui-ci peut apparaître à tout moment, pas seulement à la
                      confirmation. switchToMode() garde tout le contexte déjà
                      donné, contrairement à un simple redémarrage. */}
                  {msg.role === 'assistant' &&
                    msg.suggestMode &&
                    msg.suggestMode !== mode &&
                    i === session!.messages.length - 1 && (
                      <div className="mt-3">
                        <button
                          type="button"
                          disabled={starting || sending || confirming}
                          onClick={() => switchToMode(msg.suggestMode as ChatMode)}
                          className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-blue/10 border border-blue/40 text-blue hover:bg-blue/20 transition disabled:opacity-40"
                        >
                          {MODE_META[msg.suggestMode].icon} {MODE_META[msg.suggestMode].title}
                        </button>
                      </div>
                    )}
                </div>
              </div>
            ))}

          {/* Bibliothèque de logos (F3/F4) */}
          {showLogoLibrary && (
            <div className="card p-4 max-w-2xl">
              <div className="text-xs font-semibold text-muted mb-3">Logo déjà créé ici ?</div>
              <div className="flex flex-wrap gap-3">
                {logos.map((logo) => (
                  <button
                    key={logo.id}
                    type="button"
                    onClick={() => applyLibraryLogo(logo)}
                    disabled={sending}
                    className="w-20 text-center group disabled:opacity-40"
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={logo.url}
                      alt={logo.brandName}
                      className="w-20 h-20 object-contain bg-white rounded-lg border border-line group-hover:border-blue transition"
                    />
                    <div className="text-[11px] text-muted mt-1 truncate">{logo.brandName}</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Récap + confirmation (statut 'reviewing') */}
          {canConfirm && (
            <div className="card p-5 max-w-2xl border border-blue/40">
              <div className="text-xs font-semibold text-blue mb-2">Récapitulatif</div>
              {session?.reviewSummary && (
                <p className="text-sm leading-relaxed whitespace-pre-wrap mb-4">
                  {session.reviewSummary}
                </p>
              )}
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => handleConfirm(true)}
                  disabled={confirming}
                  className="btn-primary rounded-lg px-4 py-2 text-sm font-semibold disabled:opacity-50"
                >
                  {confirming ? 'Confirmation…' : 'Confirmer'}
                </button>
                <button
                  type="button"
                  onClick={() => handleConfirm(false)}
                  disabled={confirming}
                  className="btn-secondary rounded-lg px-4 py-2 text-sm disabled:opacity-50"
                >
                  Modifier encore
                </button>
              </div>
            </div>
          )}

          {/* Résultat + cross-promo (statut 'confirmed') */}
          {isConfirmed && (
            <div className="card p-5 max-w-2xl border border-mint/40 space-y-4">
              <div className="text-sm text-mint font-semibold">
                {mode === 'site' && 'Votre brief est confirmé.'}
                {mode === 'logo' && 'Votre logo est enregistré.'}
                {mode === 'business' && 'Votre idée business est prête.'}
                {mode === 'edit' && 'Modification confirmée.'}
              </div>

              {/* Cas logo en attente (créé pendant le mode "site") */}
              {pendingLogoAction === 'plan_required' && (
                <div className="rounded-lg border border-amber-400/40 bg-amber-400/10 p-3 text-sm text-amber-200">
                  Votre site est créé sans logo pour l&apos;instant : la génération de logo par IA
                  nécessite un abonnement Créateur (ou supérieur). Vous pouvez ajouter votre
                  propre logo à tout moment depuis la page du site, ou passer à un abonnement
                  payant pour en générer un.
                </div>
              )}
              {pendingLogoAction === 'upload' && (
                <div className="rounded-lg border border-white/10 bg-white/5 p-3 text-sm text-muted">
                  Votre site est créé — il ne manque plus que votre logo. Ajoutez-le depuis la
                  page du site pour lancer la génération.
                </div>
              )}
              {pendingLogoAction === 'library' && (
                <div className="rounded-lg border border-white/10 bg-white/5 p-3 text-sm text-muted">
                  Votre site est créé — choisissez le logo à utiliser depuis votre bibliothèque
                  sur la page du site pour lancer la génération.
                </div>
              )}

              {/* Statut de la modification réelle envoyée en mode "edit" */}
              {mode === 'edit' && editModifyStatus === 'sending' && (
                <div className="text-sm text-muted">Envoi de la modification au site…</div>
              )}
              {mode === 'edit' && editModifyStatus === 'sent' && (
                <div className="rounded-lg border border-mint/30 bg-mint/10 p-3 text-sm text-mint">
                  Votre demande de modification a été transmise — le site va être mis à jour.
                </div>
              )}
              {mode === 'edit' && editModifyStatus === 'error' && (
                <div className="rounded-lg border border-red-400/30 bg-red-400/10 p-3 text-sm text-red-300">
                  La modification n&apos;a pas pu être envoyée. Réessayez depuis la page du site.
                </div>
              )}

              <div className="flex flex-wrap gap-2">
                {mode === 'site' && session?.siteId && (
                  <Link
                    href={`/sites/${session.siteId}`}
                    className="btn-primary rounded-lg px-4 py-2 text-sm font-semibold"
                  >
                    Voir les aperçus
                  </Link>
                )}
                {mode === 'logo' && (
                  <button
                    type="button"
                    onClick={() => switchToMode('site')}
                    className="btn-primary rounded-lg px-4 py-2 text-sm font-semibold"
                  >
                    On crée ton site ?
                  </button>
                )}
                {mode === 'business' && (
                  <button
                    type="button"
                    onClick={() => switchToMode('site')}
                    className="btn-primary rounded-lg px-4 py-2 text-sm font-semibold"
                  >
                    On crée ton site autour de cette idée ?
                  </button>
                )}
                {mode === 'edit' && activeSite && (
                  <Link
                    href={`/sites/${activeSite.id}`}
                    className="btn-primary rounded-lg px-4 py-2 text-sm font-semibold"
                  >
                    Ouvrir la page du site
                  </Link>
                )}
                <button
                  type="button"
                  onClick={() => startMode(mode as ChatMode, { siteId: activeSite?.id })}
                  className="btn-secondary rounded-lg px-4 py-2 text-sm"
                >
                  Nouvelle conversation
                </button>
              </div>
            </div>
          )}

          {(sending || confirming) && (
            <div className="flex justify-start">
              <div className="bg-card border border-line rounded-2xl px-5 py-3 flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-blue border-t-transparent rounded-full animate-spin" />
                <span className="text-sm text-muted">L’assistant réfléchit…</span>
              </div>
            </div>
          )}

          {error && (
            <div className="text-sm text-red bg-redSoft rounded-lg px-4 py-2.5 max-w-2xl">{error}</div>
          )}

          <div ref={bottomRef} />
        </div>

        <div className="px-8 py-4 border-t border-line">
          {pendingAttachments.length > 0 && (
            <div className="flex flex-wrap gap-2 max-w-3xl mx-auto mb-3">
              {pendingAttachments.map((att, i) => (
                <div
                  key={i}
                  className="flex items-center gap-2 text-xs px-2.5 py-1.5 rounded-lg bg-panel border border-line"
                >
                  {att.type === 'image' ? '🖼️' : '📎'}
                  <span className="max-w-[140px] truncate">{att.name || att.type}</span>
                  <button
                    type="button"
                    onClick={() => removePendingAttachment(i)}
                    className="text-muted hover:text-red"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}

          <div className="flex items-center gap-2 max-w-3xl mx-auto">
            <input
              ref={imageInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFilePick}
            />
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,application/pdf"
              className="hidden"
              onChange={handleFilePick}
            />

            <button
              type="button"
              title="Ajouter une image"
              onClick={() => imageInputRef.current?.click()}
              disabled={!inputEnabled || uploading}
              className="w-10 h-10 shrink-0 rounded-lg border border-line hover:border-blue flex items-center justify-center text-lg disabled:opacity-40 disabled:cursor-not-allowed"
            >
              🖼️
            </button>
            <button
              type="button"
              title="Ajouter un fichier"
              onClick={() => fileInputRef.current?.click()}
              disabled={!inputEnabled || uploading}
              className="w-10 h-10 shrink-0 rounded-lg border border-line hover:border-blue flex items-center justify-center text-lg disabled:opacity-40 disabled:cursor-not-allowed"
            >
              📎
            </button>

            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              disabled={!inputEnabled}
              placeholder={
                uploading
                  ? 'Envoi de la pièce jointe…'
                  : inputEnabled
                  ? 'Écrivez votre réponse…'
                  : 'En attente d’une action de l’assistant…'
              }
              className="input flex-1 disabled:opacity-40 disabled:cursor-not-allowed"
            />
            <button
              type="button"
              onClick={handleSend}
              disabled={!inputEnabled || (!input.trim() && pendingAttachments.length === 0)}
              className="btn-primary rounded-lg px-5 py-2.5 text-sm font-semibold disabled:opacity-40"
            >
              Envoyer
            </button>
          </div>
          <p className="text-center text-xs text-muted mt-2">
            La zone de saisie s’active uniquement lorsque l’assistant attend une réponse.
          </p>
        </div>
      </div>
    </DashboardShell>
  );
}
