'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import DashboardShell from '@/components/DashboardShell';
import { useAuth } from '@/lib/auth-context';
import { academyApi, AcademyListItem } from '@/lib/api';

type Formation = {
  id: string;
  title: string;
  description: string;
  pdfs: AcademyListItem[];
  videos: AcademyListItem[];
};

export default function AcademyPage() {
  const { user } = useAuth();
  const [formations, setFormations] = useState<Formation[]>([]);
  const [selected, setSelected] = useState<Formation | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');

  function loadAcademy() {
    setLoading(true);
    setLoadError('');
    academyApi
      .list()
      .then((r) => {
        // Grouper par formation
        const map = new Map<string, Formation>();
        r.contents.forEach((c) => {
          const fid = c.formationId || c.category || 'general';
          const ftitle = c.formationTitle || c.category || 'Formations';
          if (!map.has(fid)) {
            map.set(fid, { id: fid, title: ftitle, description: '', pdfs: [], videos: [] });
          }
          const f = map.get(fid)!;
          if (c.type === 'pdf') f.pdfs.push(c);
          else f.videos.push(c);
        });
        setFormations(Array.from(map.values()));
      })
      .catch((err) => setLoadError((err as Error).message || 'Impossible de charger l’Academy.'))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    loadAcademy();
  }, []);

  if (selected) {
    return (
      <DashboardShell>
        <div className="p-8 max-w-4xl">
          <button
            onClick={() => setSelected(null)}
            className="text-sm text-muted hover:text-white mb-6 flex items-center gap-1"
          >
            ← Retour aux formations
          </button>
          <h1 className="text-2xl font-display font-bold mb-1">{selected.title}</h1>
          <p className="text-muted text-sm mb-8">{selected.description}</p>

          {/* Catégorie PDF */}
          <section className="mb-10">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <span className="w-8 h-8 rounded-lg bg-blueSoft text-blue flex items-center justify-center text-sm">PDF</span>
              Documents PDF
            </h2>
            <div className="space-y-3">
              {selected.pdfs.length === 0 && (
                <p className="text-sm text-muted">Aucun PDF dans cette formation.</p>
              )}
              {selected.pdfs.map((item) => (
                <ContentRow key={item.id} item={item} />
              ))}
            </div>
          </section>

          {/* Catégorie Vidéos */}
          <section>
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <span className="w-8 h-8 rounded-lg bg-mintSoft text-mint flex items-center justify-center text-sm">▶</span>
              Vidéos
            </h2>
            <div className="space-y-3">
              {selected.videos.length === 0 && (
                <p className="text-sm text-muted">Aucune vidéo dans cette formation.</p>
              )}
              {selected.videos.map((item) => (
                <ContentRow key={item.id} item={item} />
              ))}
            </div>
          </section>
        </div>
      </DashboardShell>
    );
  }

  return (
    <DashboardShell>
      <div className="p-8 max-w-5xl">
        <h1 className="text-2xl font-display font-bold mb-1">Academy</h1>
        <p className="text-muted text-sm mb-8">
          Formez-vous au digital avec des PDF et vidéos pratiques.
        </p>

        {loading ? (
          <div className="flex justify-center py-20">
            <div className="w-8 h-8 border-2 border-blue border-t-transparent rounded-full animate-spin" />
          </div>
        ) : loadError ? (
          <div className="card p-10 text-center">
            <p className="text-red mb-4">{loadError}</p>
            <button onClick={loadAcademy} className="btn-secondary rounded-lg px-5 py-2 text-sm inline-block">
              Réessayer
            </button>
          </div>
        ) : formations.length === 0 ? (
          <div className="card p-16 text-center text-muted">
            Aucun contenu disponible pour le moment.
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-5">
            {formations.map((f) => {
              const hasPremium = [...f.pdfs, ...f.videos].some((c) => c.access === 'payant');
              return (
                <button
                  key={f.id}
                  onClick={() => setSelected(f)}
                  className="card p-6 text-left hover:border-lineLt transition-colors group"
                >
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="font-semibold text-lg group-hover:text-blue transition-colors">
                      {f.title}
                    </h3>
                    {hasPremium && <span className="badge-premium">Premium</span>}
                  </div>
                  <p className="text-sm text-muted mb-4 line-clamp-2">{f.description}</p>
                  <div className="flex gap-4 text-xs text-muted">
                    <span>{f.pdfs.length} PDF</span>
                    <span>{f.videos.length} vidéo{f.videos.length > 1 ? 's' : ''}</span>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </DashboardShell>
  );
}

function ContentRow({ item }: { item: AcademyListItem }) {
  const isLocked = item.locked || item.access === 'payant';
  return (
    <div
      className={`card p-4 flex items-center justify-between ${
        isLocked ? 'opacity-70' : 'hover:border-lineLt'
      }`}
    >
      <div className="flex items-center gap-3 min-w-0">
        <div className="w-10 h-10 rounded-lg bg-panel flex items-center justify-center text-sm shrink-0">
          {item.type === 'pdf' ? '📄' : '▶'}
        </div>
        <div className="min-w-0">
          <div className="font-medium text-sm truncate">{item.title}</div>
          <div className="flex items-center gap-2 mt-0.5">
            {item.access === 'gratuit' ? (
              <span className="badge-free">Gratuit</span>
            ) : (
              <span className="badge-premium">Premium</span>
            )}
          </div>
        </div>
      </div>
      {isLocked ? (
        <div className="text-xs text-muted text-right shrink-0 ml-3">
          <div>🔒</div>
          <div className="mt-0.5">Abonnement requis</div>
        </div>
      ) : (
        <Link
          href={`/academy/${item.id}`}
          className="btn-primary rounded-lg px-4 py-2 text-xs font-semibold shrink-0 ml-3"
        >
          Ouvrir
        </Link>
      )}
    </div>
  );
}
