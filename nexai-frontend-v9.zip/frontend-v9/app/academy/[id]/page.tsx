'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import DashboardShell from '@/components/DashboardShell';
import SecurePdfViewer from '@/components/SecurePdfViewer';
import { useAuth } from '@/lib/auth-context';
import { academyApi, AcademyContentMeta, ApiError, toBackendUrl } from '@/lib/api';

export default function AcademyContentPage() {
  const params = useParams<{ id: string }>();
  const id = params.id;
  const { user } = useAuth();

  const [content, setContent] = useState<AcademyContentMeta | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [locked, setLocked] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    academyApi
      .getFreshMeta(id)
      .then(setContent)
      .catch((err) => {
        if (err instanceof ApiError && err.status === 404) setNotFound(true);
        else if (err instanceof ApiError && err.status === 403) setLocked(true);
        else setError((err as Error).message || 'Erreur de chargement du contenu.');
      })
      .finally(() => setLoading(false));
  }, [id]);

  // Le backend ne renvoie jamais l'URL réelle du fichier : uniquement un
  // chemin de streaming protégé par token courte durée (voir academy.routes.ts).
  const mediaUrl = content?.streamUrl ? toBackendUrl(content.streamUrl) : '';
  const isExternalEmbed = content?.type === 'video' && content?.hosting === 'embed_externe';

  return (
    <DashboardShell>
      <div className="p-8 max-w-4xl">
        <Link
          href="/academy"
          className="text-sm text-muted hover:text-white mb-6 flex items-center gap-1"
        >
          ← Retour aux formations
        </Link>

        {loading ? (
          <div className="flex justify-center py-20">
            <div className="w-8 h-8 border-2 border-blue border-t-transparent rounded-full animate-spin" />
          </div>
        ) : notFound ? (
          <div className="card p-16 text-center">
            <p className="text-muted mb-6">Ce contenu est introuvable.</p>
            <Link href="/academy" className="btn-primary rounded-lg px-6 py-2.5 text-sm inline-block">
              Retour à l’Academy
            </Link>
          </div>
        ) : error ? (
          <div className="card p-16 text-center">
            <p className="text-red mb-2">{error}</p>
          </div>
        ) : locked ? (
          <div className="card p-16 text-center">
            <div className="text-3xl mb-3">🔒</div>
            <p className="text-muted mb-6">
              Ce contenu nécessite un abonnement supérieur pour être consulté.
            </p>
            <Link
              href="/parametres?tab=abonnement"
              className="btn-primary rounded-lg px-6 py-2.5 text-sm inline-block"
            >
              Voir les abonnements
            </Link>
          </div>
        ) : (
          <>
            <h1 className="text-2xl font-display font-bold mb-1">
              {content?.title || 'Contenu Academy'}
            </h1>

            {isExternalEmbed ? (
              content?.embedHint ? (
                <div className="card p-2 overflow-hidden">
                  <iframe
                    src={content.embedHint}
                    className="w-full rounded-lg aspect-video"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                </div>
              ) : (
                <div className="card p-16 text-center">
                  <p className="text-muted">Aucune source disponible pour cette vidéo.</p>
                </div>
              )
            ) : !mediaUrl ? (
              <div className="card p-16 text-center">
                <p className="text-muted">
                  Aucun fichier disponible pour ce contenu pour le moment.
                </p>
              </div>
            ) : content?.type === 'video' ? (
              // Académie = consultation uniquement, jamais de téléchargement.
              // controlsList retire le bouton "Télécharger" des contrôles
              // natifs (Chrome/Edge) et on bloque le clic droit "Enregistrer
              // la vidéo sous…". Limite connue : ces protections réduisent
              // fortement le téléchargement occasionnel mais ne bloquent pas
              // un utilisateur déterminé (outils dev navigateur) — c'est
              // pourquoi le flux est en plus signé (token 2 min) et jamais
              // mis en cache côté backend.
              <div className="card p-2 overflow-hidden">
                <video
                  src={mediaUrl}
                  controls
                  controlsList="nodownload noremoteplayback"
                  disablePictureInPicture
                  onContextMenu={(e) => e.preventDefault()}
                  className="w-full rounded-lg aspect-video bg-black"
                />
                <p className="text-xs text-muted text-center mt-2">
                  Contenu réservé à la consultation — téléchargement désactivé.
                </p>
              </div>
            ) : (
              // PDF : plus de rendu natif navigateur (embed/iframe). Les octets
              // sont récupérés nous-mêmes puis dessinés page par page sur des
              // <canvas> via pdf.js — aucun lecteur PDF natif, donc aucun bouton
              // "Enregistrer"/"Imprimer" fourni par le navigateur, et aucune URL
              // de fichier exploitable. Voir components/SecurePdfViewer.tsx.
              <SecurePdfViewer
                url={mediaUrl}
                watermarkText={user?.email ? `${user.email} — NexAI Académie` : 'NexAI Académie'}
              />
            )}
          </>
        )}
      </div>
    </DashboardShell>
  );
}
