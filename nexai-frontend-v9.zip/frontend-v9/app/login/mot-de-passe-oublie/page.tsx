'use client';

import { useState } from 'react';
import Link from 'next/link';
import { authApi } from '@/lib/api';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [password, setPassword] = useState('');
  const [step, setStep] = useState<'email' | 'reset'>('email');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function sendCode(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await authApi.forgotPassword(email);
      setMessage('Un code a été envoyé à votre email.');
      setStep('reset');
    } catch (err: any) {
      setError(err.message || 'Erreur');
    } finally {
      setLoading(false);
    }
  }

  async function resetPwd(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await authApi.resetPassword(email, code, password);
      setMessage('Mot de passe mis à jour. Vous pouvez vous connecter.');
    } catch (err: any) {
      setError(err.message || 'Erreur');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <img src="/brand/nexai-logo.svg" alt="NexAI" className="h-8 w-auto" />
          </Link>
          <h1 className="text-2xl font-display font-bold">Mot de passe oublié</h1>
        </div>
        <div className="card p-8 space-y-4">
          {error && <div className="text-sm text-red bg-redSoft rounded-lg px-4 py-2.5">{error}</div>}
          {message && <div className="text-sm text-mint bg-mintSoft rounded-lg px-4 py-2.5">{message}</div>}
          {step === 'email' ? (
            <form onSubmit={sendCode} className="space-y-4">
              <div>
                <label className="text-sm text-muted mb-1.5 block">Email</label>
                <input type="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} required />
              </div>
              <button type="submit" disabled={loading} className="btn-primary w-full rounded-lg py-3 text-sm font-semibold">
                {loading ? 'Envoi…' : 'Envoyer le code'}
              </button>
            </form>
          ) : (
            <form onSubmit={resetPwd} className="space-y-4">
              <div>
                <label className="text-sm text-muted mb-1.5 block">Code reçu</label>
                <input className="input" value={code} onChange={(e) => setCode(e.target.value)} required />
              </div>
              <div>
                <label className="text-sm text-muted mb-1.5 block">Nouveau mot de passe</label>
                <input type="password" className="input" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={8} />
              </div>
              <button type="submit" disabled={loading} className="btn-primary w-full rounded-lg py-3 text-sm font-semibold">
                {loading ? 'Enregistrement…' : 'Réinitialiser'}
              </button>
            </form>
          )}
        </div>
        <p className="text-center text-sm text-muted mt-6">
          <Link href="/login" className="text-blue hover:underline">Retour à la connexion</Link>
        </p>
      </div>
    </div>
  );
}
