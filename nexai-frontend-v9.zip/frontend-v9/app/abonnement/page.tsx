'use client';

import { useEffect, useState } from 'react';
import DashboardShell from '@/components/DashboardShell';
import { useAuth } from '@/lib/auth-context';
import { plansApi, ApiError } from '@/lib/api';

type Plan = {
  id: string;
  nom: string;
  prixFcfa: number;
  prixUsd: number;
  inclus: string[];
  nonInclus: string[];
  creditsParMois: number;
  domainesInclus: number;
  logosInclus: number;
  actuel: boolean;
  populaire?: boolean;
};

type Parrainage = {
  code: string;
  totalFilleuls: number;
  filleulsConvertis: number;
  creditsGagnes: number;
  recompenseParFilleul: number;
  regle: string;
};

type Recu = {
  id: string;
  date: string;
  libelle: string;
  montantFcfa: number | null;
  numero: string;
  telechargeable: boolean;
};

export default function AbonnementPage() {
  const { user } = useAuth();
  const [plans, setPlans] = useState<Plan[]>([]);
  const [planActuel, setPlanActuel] = useState('');
  const [illimite, setIllimite] = useState(false);
  const [parrainage, setParrainage] = useState<Parrainage | null>(null);
  const [recus, setRecus] = useState<Recu[]>([]);
  const [chargement, setChargement] = useState(true);
  const [erreur, setErreur] = useState('');
  const [achatEnCours, setAchatEnCours] = useState('');
  const [codeCopie, setCodeCopie] = useState(false);

  useEffect(() => {
    let actif = true;
    (async () => {
      try {
        const liste = await plansApi.list();
        if (!actif) return;
        setPlans(liste.plans);
        setPlanActuel(liste.planActuel);
        setIllimite(liste.creditsIllimites);

        // Parrainage : disponible pour tous les comptes.
        plansApi.parrainage().then((p) => actif && setParrainage(p)).catch(() => {});

        // Reçus : réservés Agence et Pro Max. Un refus 403 est normal
        // pour les autres plans, on n'affiche donc pas d'erreur.
        plansApi
          .recus()
          .then((r) => actif && setRecus(r.recus))
          .catch(() => {});
      } catch (e) {
        if (actif) setErreur(e instanceof ApiError ? e.message : 'Chargement impossible.');
      } finally {
        if (actif) setChargement(false);
      }
    })();
    return () => {
      actif = false;
    };
  }, []);

  async function souscrire(id: string) {
    setErreur('');
    setAchatEnCours(id);
    try {
      const r = await plansApi.acheter(id as 'starter' | 'createur' | 'agence' | 'pro_max');
      // Le plan sera activé par le webhook après paiement confirmé.
      if (r.paymentLink) window.location.href = r.paymentLink;
      else setErreur("Le lien de paiement n'a pas pu être généré. Réessayez.");
    } catch (e) {
      setErreur(e instanceof ApiError ? e.message : 'Souscription impossible.');
    } finally {
      setAchatEnCours('');
    }
  }

  function copierCode() {
    if (!parrainage?.code) return;
    navigator.clipboard?.writeText(parrainage.code).then(
      () => {
        setCodeCopie(true);
        setTimeout(() => setCodeCopie(false), 2000);
      },
      () => {}
    );
  }

  return (
    <DashboardShell>
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-1">Abonnement</h1>
        <p className="text-sm text-[var(--muted)]">
          {illimite
            ? 'Compte administrateur — accès complet à toutes les fonctions.'
            : 'Choisissez la formule qui correspond à votre activité.'}
        </p>
      </div>

      {erreur && (
        <div className="mb-6 rounded border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-300">
          {erreur}
        </div>
      )}

      {/* Formules */}
      <section className="mb-12">
        {chargement ? (
          <p className="text-sm text-[var(--muted)]">Chargement…</p>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            {plans.map((p) => (
              <div
                key={p.id}
                className={`flex flex-col rounded-lg border bg-[var(--panel)] p-5 ${
                  p.actuel || p.id === planActuel
                    ? 'border-emerald-500'
                    : p.populaire
                    ? 'border-[var(--blue)]'
                    : 'border-[var(--line)]'
                }`}
              >
                {(p.actuel || p.id === planActuel) && (
                  <span className="mb-2 self-start rounded bg-emerald-500/15 px-2 py-1 text-[0.65rem] font-bold uppercase tracking-wide text-emerald-400">
                    Votre formule
                  </span>
                )}
                {p.populaire && !(p.actuel || p.id === planActuel) && (
                  <span className="mb-2 self-start rounded bg-[var(--blue)]/15 px-2 py-1 text-[0.65rem] font-bold uppercase tracking-wide text-[var(--blue-text)]">
                    Le plus complet
                  </span>
                )}

                <h3 className="text-lg font-bold">{p.nom}</h3>
                <p className="mb-1 mt-2 text-2xl font-bold">
                  {p.prixFcfa.toLocaleString('fr-FR')}
                  <span className="ml-1 text-sm font-normal text-[var(--muted)]">FCFA/mois</span>
                </p>
                <p className="mb-4 text-xs text-[var(--muted)]">
                  {p.creditsParMois} crédits par mois
                </p>

                <ul className="mb-5 flex-1 space-y-1.5 text-sm">
                  {p.inclus.map((i) => (
                    <li key={i} className="flex gap-2">
                      <span className="text-emerald-400">✓</span>
                      <span>{i}</span>
                    </li>
                  ))}
                  {p.nonInclus.map((i) => (
                    <li key={i} className="flex gap-2 text-[var(--muted)]">
                      <span>—</span>
                      <span>{i}</span>
                    </li>
                  ))}
                </ul>

                <button
                  type="button"
                  onClick={() => souscrire(p.id)}
                  disabled={p.actuel || p.id === planActuel || achatEnCours !== '' || illimite}
                  className="w-full rounded bg-[var(--blue)] px-4 py-2.5 text-sm font-bold uppercase tracking-wide text-[#0E1118] disabled:opacity-50"
                >
                  {p.actuel || p.id === planActuel
                    ? 'Formule actuelle'
                    : achatEnCours === p.id
                    ? 'Redirection…'
                    : 'Choisir'}
                </button>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Parrainage */}
      {parrainage && (
        <section className="mb-12">
          <h2 className="mb-3 text-lg font-semibold">Parrainage</h2>
          <div className="rounded-lg border border-[var(--line)] bg-[var(--panel)] p-6">
            <p className="mb-4 text-sm leading-relaxed text-[var(--muted)]">{parrainage.regle}</p>

            <div className="mb-5 flex flex-wrap items-center gap-3">
              <code className="rounded border border-[var(--line)] bg-[var(--bg)] px-4 py-2.5 font-mono text-lg tracking-widest">
                {parrainage.code}
              </code>
              <button
                type="button"
                onClick={copierCode}
                className="rounded border border-[var(--line)] px-4 py-2.5 text-sm font-semibold"
              >
                {codeCopie ? 'Copié' : 'Copier'}
              </button>
            </div>

            <div className="grid gap-4 sm:grid-cols-3">
              <div>
                <p className="text-xl font-bold">{parrainage.totalFilleuls}</p>
                <p className="text-xs uppercase tracking-wide text-[var(--muted)]">Filleuls inscrits</p>
              </div>
              <div>
                <p className="text-xl font-bold">{parrainage.filleulsConvertis}</p>
                <p className="text-xs uppercase tracking-wide text-[var(--muted)]">Abonnements payés</p>
              </div>
              <div>
                <p className="text-xl font-bold text-emerald-400">{parrainage.creditsGagnes}</p>
                <p className="text-xs uppercase tracking-wide text-[var(--muted)]">Crédits gagnés</p>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Reçus — Agence et Pro Max uniquement */}
      {recus.length > 0 && (
        <section>
          <h2 className="mb-3 text-lg font-semibold">Reçus de paiement</h2>
          <div className="overflow-x-auto rounded-lg border border-[var(--line)] bg-[var(--panel)]">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[var(--line)] text-left text-xs uppercase tracking-wide text-[var(--muted)]">
                  <th className="px-4 py-3">Numéro</th>
                  <th className="px-4 py-3">Date</th>
                  <th className="px-4 py-3">Objet</th>
                  <th className="px-4 py-3 text-right">Montant</th>
                  <th className="px-4 py-3" />
                </tr>
              </thead>
              <tbody>
                {recus.map((r) => (
                  <tr key={r.id} className="border-b border-[var(--line)] last:border-0">
                    <td className="px-4 py-3 font-mono text-xs">{r.numero}</td>
                    <td className="px-4 py-3 text-[var(--muted)]">
                      {new Date(r.date).toLocaleDateString('fr-FR')}
                    </td>
                    <td className="px-4 py-3">{r.libelle}</td>
                    <td className="px-4 py-3 text-right">
                      {r.montantFcfa ? `${r.montantFcfa.toLocaleString('fr-FR')} FCFA` : '—'}
                    </td>
                    <td className="px-4 py-3 text-right">
                      {r.telechargeable ? (
                        <a
                          href={plansApi.recuUrl(r.id)}
                          className="text-sm font-semibold text-[var(--blue-text)]"
                        >
                          Télécharger
                        </a>
                      ) : (
                        <span className="text-xs text-[var(--muted)]">Indisponible</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </DashboardShell>
  );
}
