'use client';

import { useEffect, useRef, useState } from 'react';
import DashboardShell from '@/components/DashboardShell';
import Link from 'next/link';
import { supportApi, SupportMessage, SupportTicket } from '@/lib/api';

/**
 * Assistance client : chat sur le site.
 * 1) L'IA répond en premier niveau
 * 2) Si besoin humain → status needs_human (signal admin)
 * L'email du compte est utilisé ; pas de saisie d'email supplémentaire.
 */
export default function AidePage() {
  const [ticket, setTicket] = useState<SupportTicket | null>(null);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [booting, setBooting] = useState(true);
  const [error, setError] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    supportApi
      .myThread()
      .then((r) => setTicket(r.ticket))
      .catch((err) => setError((err as Error).message || 'Impossible de charger la conversation.'))
      .finally(() => setBooting(false));
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [ticket?.messages?.length]);

  async function send(e?: React.FormEvent) {
    e?.preventDefault();
    const content = input.trim();
    if (!content || loading) return;
    setInput('');
    setError('');
    setLoading(true);

    // Optimistic user message
    const optimistic: SupportMessage = {
      id: `tmp_${Date.now()}`,
      role: 'user',
      content,
      createdAt: new Date().toISOString(),
    };
    setTicket((t) =>
      t
        ? { ...t, messages: [...(t.messages || []), optimistic] }
        : { id: 'local', status: 'ai', messages: [optimistic] }
    );

    try {
      const r = await supportApi.send(content);
      setTicket(r.ticket);
    } catch (err) {
      // On retire le message optimiste : il n'a pas réellement été envoyé.
      setTicket((t) =>
        t ? { ...t, messages: (t.messages || []).filter((m) => m.id !== optimistic.id) } : t
      );
      setInput(content);
      setError(
        (err as Error).message || "Votre message n'a pas pu être envoyé. Réessayez."
      );
    } finally {
      setLoading(false);
    }
  }

  const statusLabel =
    ticket?.status === 'needs_human'
      ? 'Conseiller notifié — réponse à venir ici'
      : ticket?.status === 'closed'
        ? 'Conversation clôturée'
        : 'Assistant NexAI';

  return (
    <DashboardShell>
      <div className="p-4 md:p-8 max-w-3xl mx-auto flex flex-col h-[calc(100vh-2rem)]">
        <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-display font-bold">Assistance</h1>
            <p className="text-sm text-muted mt-1">
              {statusLabel} · réponse sur le site (pas besoin d’autre email)
            </p>
          </div>
          <Link href="/guide" className="text-sm text-blue hover:underline">
            Voir le Guide →
          </Link>
        </div>

        {ticket?.status === 'needs_human' && (
          <div className="mb-3 text-sm rounded-lg px-4 py-2.5 bg-amber-500/10 text-amber-300 border border-amber-500/30">
            Votre demande a été transmise à un conseiller. La réponse apparaîtra dans ce fil.
          </div>
        )}

        {error && (
          <div className="mb-3 text-sm text-red bg-redSoft rounded-lg px-4 py-2.5">{error}</div>
        )}

        <div className="card flex-1 flex flex-col min-h-0 overflow-hidden">
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {booting && (
              <p className="text-sm text-muted text-center py-8">Chargement…</p>
            )}
            {!booting &&
              (ticket?.messages || []).map((m) => (
                <div
                  key={m.id}
                  className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                      m.role === 'user'
                        ? 'bg-blue text-white rounded-br-md'
                        : m.role === 'admin'
                          ? 'bg-mint/15 border border-mint/30 text-white rounded-bl-md'
                          : 'bg-panel border border-line text-white rounded-bl-md'
                    }`}
                  >
                    {m.role === 'admin' && (
                      <div className="text-[10px] uppercase tracking-wide text-mint mb-1">
                        Conseiller NexAI
                      </div>
                    )}
                    {m.role === 'assistant' && (
                      <div className="text-[10px] uppercase tracking-wide text-muted mb-1">
                        Assistant IA
                      </div>
                    )}
                    {m.content}
                  </div>
                </div>
              ))}
            <div ref={bottomRef} />
          </div>

          <form
            onSubmit={send}
            className="border-t border-line p-3 flex gap-2 items-end"
          >
            <textarea
              className="input min-h-[44px] max-h-32 resize-none flex-1 text-sm"
              rows={1}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  send();
                }
              }}
              placeholder="Décrivez votre besoin…"
              disabled={ticket?.status === 'closed'}
            />
            <button
              type="submit"
              disabled={loading || !input.trim() || ticket?.status === 'closed'}
              className="btn-primary rounded-xl px-5 py-2.5 text-sm font-semibold shrink-0"
            >
              {loading ? '…' : 'Envoyer'}
            </button>
          </form>
        </div>

        <details className="mt-4 text-sm">
          <summary className="text-muted cursor-pointer hover:text-white">FAQ rapide</summary>
          <ul className="mt-2 space-y-2 text-muted">
            <li>Générer un site : 10 crédits · Lancer : 15 · Modif IA : 5</li>
            <li>Édition manuelle des textes : gratuite et illimitée</li>
            <li>Sous-domaine NexAI gratuit · domaine payant en crédits</li>
          </ul>
        </details>
      </div>
    </DashboardShell>
  );
}
