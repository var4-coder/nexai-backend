'use client';

import { useEffect, useState } from 'react';
import DashboardShell from '@/components/DashboardShell';
import { useAuth } from '@/lib/auth-context';
import { adminApi } from '@/lib/api';
import { isAdmin } from '@/lib/plans';
import { useRouter } from 'next/navigation';

type Tab =
  | 'overview'
  | 'users'
  | 'payments'
  | 'avis'
  | 'academy'
  | 'ia'
  | 'alertes'
  | 'support'
  | 'tickets'
  | 'video';

const SUPPORT_EMAIL = process.env.NEXT_PUBLIC_SUPPORT_EMAIL || 'support@nexai.fr';

export default function AdminPage() {
  const { user } = useAuth();
  const router = useRouter();
  const [tab, setTab] = useState<Tab>('overview');
  const [users, setUsers] = useState<any[]>([]);
  const [payments, setPayments] = useState<any[]>([]);
  const [avis, setAvis] = useState<any[]>([]);
  const [alertes, setAlertes] = useState<any[]>([]);
  const [supportFile, setSupportFile] = useState<any[]>([])
  const [tickets, setTickets] = useState<any[]>([])
  const [activeTicket, setActiveTicket] = useState<any | null>(null)
  const [reply, setReply] = useState('');
  const [iaPrompt, setIaPrompt] = useState('');
  const [iaReply, setIaReply] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Instructions complémentaires du chat IA (F9 / B8) — persistées côté
  // backend, injectées après les règles anti (verrouillées, non éditables).
  const [chatInstructions, setChatInstructions] = useState('');
  const [chatInstructionsLoaded, setChatInstructionsLoaded] = useState(false);
  const [savingInstructions, setSavingInstructions] = useState(false);
  const [instructionsMsg, setInstructionsMsg] = useState('');
  const [instructionsErr, setInstructionsErr] = useState('');
  const CHAT_INSTRUCTIONS_MAX = 4000;

  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [editPlan, setEditPlan] = useState('trial');
  const [editCredits, setEditCredits] = useState('0');
  const [savingUser, setSavingUser] = useState(false);
  const [userEditError, setUserEditError] = useState('');

  // Stats vidéo IA (taux d'échec réel, coût perdu, dégradations, relances) — voir /admin/video-ads/stats.
  const [videoStats, setVideoStats] = useState<Awaited<ReturnType<typeof adminApi.videoAdsStats>> | null>(null);
  const [videoStatsDays, setVideoStatsDays] = useState(30);
  const [videoStatsLoading, setVideoStatsLoading] = useState(false);

  async function saveUserEdit(id: string) {
    setSavingUser(true);
    setUserEditError('');
    try {
      const credits = Number(editCredits);
      await adminApi.updateUser(id, {
        plan: editPlan,
        creditsBalance: Number.isFinite(credits) ? credits : undefined,
      });
      const r = await adminApi.users();
      setUsers(r.users);
      setEditingUserId(null);
    } catch (err) {
      setUserEditError((err as Error).message || 'Impossible de mettre à jour cet utilisateur.');
    } finally {
      setSavingUser(false);
    }
  }

  useEffect(() => {
    if (user && !isAdmin(user.plan, user.role)) {
      router.replace('/dashboard');
    }
  }, [user, router]);

  useEffect(() => {
    setError('');
    if (tab === 'users') {
      adminApi
        .users()
        .then((r) => setUsers(r.users))
        .catch((err) => setError((err as Error).message || 'Impossible de charger les utilisateurs.'));
    }
    if (tab === 'payments') {
      adminApi
        .payments()
        .then((r) => setPayments(r.payments))
        .catch((err) => setError((err as Error).message || 'Impossible de charger les paiements.'));
    }
    if (tab === 'avis') {
      adminApi
        .avis()
        .then((r) => setAvis(r.avis))
        .catch((err) => setError((err as Error).message || 'Impossible de charger les avis.'));
    }
    if (tab === 'alertes') {
      adminApi
        .alertes()
        .then((r) => setAlertes(r.sites || []))
        .catch((err) => setError((err as Error).message || 'Impossible de charger les alertes.'));
    }
    if (tab === 'tickets') {
      adminApi
        .supportTickets()
        .then((r) => setTickets(r.tickets || []))
        .catch((err) => setError((err as Error).message || 'Impossible de charger les tickets.'));
    }
    if (tab === 'support') {
      adminApi
        .supportFile()
        .then((r) => setSupportFile(r.sites || []))
        .catch((err) => setError((err as Error).message || 'Impossible de charger la file support.'));
    }
    if (tab === 'ia' && !chatInstructionsLoaded) {
      adminApi
        .getChatInstructions()
        .then((r) => setChatInstructions(r.instructions || ''))
        .catch(() => {
          /* endpoint pas encore déployé côté backend — champ reste vide, non bloquant */
        })
        .finally(() => setChatInstructionsLoaded(true));
    }
    if (tab === 'video') {
      setVideoStatsLoading(true);
      adminApi
        .videoAdsStats(videoStatsDays)
        .then((r) => setVideoStats(r))
        .catch((err) => setError((err as Error).message || 'Impossible de charger les stats vidéo IA.'))
        .finally(() => setVideoStatsLoading(false));
    }
  }, [tab, chatInstructionsLoaded, videoStatsDays]);

  async function saveChatInstructions() {
    setSavingInstructions(true);
    setInstructionsMsg('');
    setInstructionsErr('');
    try {
      await adminApi.updateChatInstructions(chatInstructions);
      setInstructionsMsg('Instructions enregistrées.');
    } catch (err) {
      setInstructionsErr(
        (err as Error).message || "Impossible d'enregistrer les instructions pour le moment."
      );
    } finally {
      setSavingInstructions(false);
    }
  }

  async function handleIaPrompt() {
    if (!iaPrompt.trim()) return;
    setLoading(true);
    setError('');
    try {
      const r = await adminApi.promptIA(iaPrompt);
      setIaReply(r.reply);
    } catch (err: any) {
      setError(err.message || 'Erreur prompt IA');
      setIaReply('');
    } finally {
      setLoading(false);
    }
  }

  const tabs: { id: Tab; label: string }[] = [
    { id: 'overview', label: 'Vue d’ensemble' },
    { id: 'users', label: 'Utilisateurs' },
    { id: 'payments', label: 'Paiements' },
    { id: 'video', label: 'Vidéo IA' },
    { id: 'alertes', label: 'Alertes' },
    { id: 'support', label: 'Support sites' },
    { id: 'tickets', label: 'Assistance clients' },
    { id: 'avis', label: 'Avis' },
    { id: 'academy', label: 'Académie' },
    { id: 'ia', label: 'Instructions IA' },
  ];

  const statusBadge = (status: string) => {
    if (status === 'failed') return 'bg-red/20 text-red';
    if (status === 'pending_support') return 'bg-amber-500/20 text-amber-400';
    return 'bg-panel text-muted';
  };

  return (
    <DashboardShell>
      <div className="p-6 md:p-8 max-w-6xl">
        <div className="mb-6">
          <h1 className="text-2xl font-display font-bold">Administration</h1>
          <p className="text-sm text-muted mt-1">
            Accès réservé · crédits illimités · contact clients :{' '}
            <a href={`mailto:${SUPPORT_EMAIL}`} className="text-blue hover:underline">
              {SUPPORT_EMAIL}
            </a>
          </p>
        </div>

        <div className="flex flex-wrap gap-2 mb-8 border-b border-line pb-4">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors ${
                tab === t.id ? 'bg-blue text-white' : 'text-muted hover:text-white hover:bg-panel'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {error && (
          <div className="mb-4 text-sm text-red bg-redSoft rounded-lg px-4 py-2.5">{error}</div>
        )}

        {/* OVERVIEW */}
        {tab === 'overview' && (
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: 'Utilisateurs', desc: 'Plans, crédits, rôles', tab: 'users' as Tab },
              { label: 'Paiements Chariow', desc: 'Valider les paiements manuels', tab: 'payments' as Tab },
              { label: 'Vidéo IA', desc: 'Taux d’échec, coût perdu, relances', tab: 'video' as Tab },
              { label: 'Alertes', desc: 'Sites failed / pending_support', tab: 'alertes' as Tab },
              { label: 'File Support sites', desc: 'pending_support pipeline IA', tab: 'support' as Tab },
              { label: 'Assistance clients', desc: 'Chat escaladé vers humain', tab: 'tickets' as Tab },
            ].map((c) => (
              <button
                key={c.label}
                onClick={() => setTab(c.tab)}
                className="card p-5 text-left hover:border-blue transition-colors"
              >
                <div className="font-semibold mb-1">{c.label}</div>
                <div className="text-sm text-muted">{c.desc}</div>
              </button>
            ))}
            <div className="card p-5 sm:col-span-2">
              <div className="font-semibold mb-2">Support client (email)</div>
              <p className="text-sm text-muted mb-3 leading-relaxed">
                Les questions clients passent par Assistance (chat). Les mails marketing (fin d’essai) via Brevo. Secours :{' '}
                <strong className="text-white">{SUPPORT_EMAIL}</strong>. Les problèmes techniques
                (génération, Opus, lancement) apparaissent ici dans{' '}
                <strong className="text-white">Alertes</strong> et{' '}
                <strong className="text-white">Support</strong>.
              </p>
              <a
                href={`mailto:${SUPPORT_EMAIL}`}
                className="text-sm text-blue hover:underline"
              >
                Ouvrir la boîte mail →
              </a>
            </div>
          </div>
        )}

        {/* USERS */}
        {tab === 'users' && (
          <div className="card overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-panel text-muted text-left">
                <tr>
                  <th className="px-4 py-3 font-medium">Email</th>
                  <th className="px-4 py-3 font-medium">Plan</th>
                  <th className="px-4 py-3 font-medium">Crédits</th>
                  <th className="px-4 py-3 font-medium">Créé le</th>
                  <th className="px-4 py-3 font-medium"></th>
                </tr>
              </thead>
              <tbody>
                {users.map((u) => {
                  const isEditing = editingUserId === u.id;
                  return (
                    <tr key={u.id} className="border-t border-line align-top">
                      <td className="px-4 py-3">{u.email}</td>
                      {isEditing ? (
                        <>
                          <td className="px-4 py-3">
                            <select
                              className="input py-1.5 text-xs"
                              value={editPlan}
                              onChange={(e) => setEditPlan(e.target.value)}
                            >
                              {['trial', 'starter', 'createur', 'agence', 'pro_max'].map((p) => (
                                <option key={p} value={p}>
                                  {p}
                                </option>
                              ))}
                            </select>
                          </td>
                          <td className="px-4 py-3">
                            <input
                              type="number"
                              min={0}
                              className="input py-1.5 text-xs w-24"
                              value={editCredits}
                              onChange={(e) => setEditCredits(e.target.value)}
                            />
                          </td>
                          <td className="px-4 py-3 text-muted">
                            {u.createdAt ? new Date(u.createdAt).toLocaleDateString('fr-FR') : '—'}
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <button
                                disabled={savingUser}
                                onClick={() => saveUserEdit(u.id)}
                                className="text-xs text-blue hover:underline disabled:opacity-50"
                              >
                                {savingUser ? 'Enregistrement…' : 'Enregistrer'}
                              </button>
                              <button
                                onClick={() => setEditingUserId(null)}
                                className="text-xs text-muted hover:text-white"
                              >
                                Annuler
                              </button>
                            </div>
                            {userEditError && (
                              <div className="text-xs text-red mt-1">{userEditError}</div>
                            )}
                          </td>
                        </>
                      ) : (
                        <>
                          <td className="px-4 py-3 capitalize">{u.plan}</td>
                          <td className="px-4 py-3">{u.creditsBalance}</td>
                          <td className="px-4 py-3 text-muted">
                            {u.createdAt ? new Date(u.createdAt).toLocaleDateString('fr-FR') : '—'}
                          </td>
                          <td className="px-4 py-3">
                            <button
                              onClick={() => {
                                setEditingUserId(u.id);
                                setEditPlan(u.plan === 'essai' ? 'trial' : u.plan);
                                setEditCredits(String(u.creditsBalance ?? 0));
                                setUserEditError('');
                              }}
                              className="text-xs text-blue hover:underline"
                            >
                              Modifier
                            </button>
                          </td>
                        </>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* PAYMENTS */}
        {tab === 'payments' && (
          <div className="card overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-panel text-muted text-left">
                <tr>
                  <th className="px-4 py-3 font-medium">Email</th>
                  <th className="px-4 py-3 font-medium">Montant</th>
                  <th className="px-4 py-3 font-medium">Statut</th>
                  <th className="px-4 py-3 font-medium">Date</th>
                  <th className="px-4 py-3 font-medium"></th>
                </tr>
              </thead>
              <tbody>
                {payments.map((p) => (
                  <tr key={p.id} className="border-t border-line">
                    <td className="px-4 py-3">{p.userEmail}</td>
                    <td className="px-4 py-3">{p.amount?.toLocaleString('fr-FR')} FCFA</td>
                    <td className="px-4 py-3">
                      <span
                        className={`text-xs px-2 py-0.5 rounded-full ${
                          p.status === 'paid' ? 'bg-mint/20 text-mint' : 'bg-amber-500/20 text-amber-400'
                        }`}
                      >
                        {p.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-muted">
                      {p.createdAt ? new Date(p.createdAt).toLocaleDateString('fr-FR') : '—'}
                    </td>
                    <td className="px-4 py-3">
                      {p.status === 'pending' && (
                        <button
                          onClick={async () => {
                            try {
                              await adminApi.markPaid(p.id);
                              const r = await adminApi.payments();
                              setPayments(r.payments);
                            } catch (err) {
                              setError((err as Error).message || 'Impossible de marquer ce paiement.');
                            }
                          }}
                          className="text-xs text-blue hover:underline"
                        >
                          Marquer payé
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* VIDÉO IA — stats échecs / coût perdu / relances */}
        {tab === 'video' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <p className="text-sm text-muted max-w-2xl leading-relaxed">
                Taux d’échec réel des générations vidéo IA, coût fournisseur perdu sur les
                remboursements, et suivi des livraisons dégradées (badge « résultat perfectible »)
                avec leur taux d’utilisation de la relance corrective à moitié prix.
              </p>
              <select
                value={videoStatsDays}
                onChange={(e) => setVideoStatsDays(Number(e.target.value))}
                className="bg-panel border border-line rounded-lg px-3 py-2 text-sm"
              >
                <option value={7}>7 derniers jours</option>
                <option value={30}>30 derniers jours</option>
                <option value={90}>90 derniers jours</option>
              </select>
            </div>

            {videoStatsLoading && <p className="text-sm text-muted">Chargement…</p>}

            {videoStats && !videoStatsLoading && (
              <>
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="card p-5">
                    <div className="text-xs text-muted uppercase tracking-wide mb-1">Vidéos générées</div>
                    <div className="text-2xl font-bold">{videoStats.totalVideosGenerees}</div>
                  </div>
                  <div className="card p-5">
                    <div className="text-xs text-muted uppercase tracking-wide mb-1">Taux d’échec</div>
                    <div className="text-2xl font-bold text-red">
                      {(videoStats.tauxEchec * 100).toFixed(1)}%
                    </div>
                    <div className="text-xs text-muted mt-1">{videoStats.totalRembourses} remboursées</div>
                  </div>
                  <div className="card p-5">
                    <div className="text-xs text-muted uppercase tracking-wide mb-1">Coût réel perdu</div>
                    <div className="text-2xl font-bold text-red">
                      ${videoStats.coutReelPerduUsd.toFixed(2)}
                    </div>
                    <div className="text-xs text-muted mt-1">{videoStats.creditsPerdus} crédits remboursés</div>
                  </div>
                  <div className="card p-5">
                    <div className="text-xs text-muted uppercase tracking-wide mb-1">Livraisons dégradées</div>
                    <div className="text-2xl font-bold text-amber-400">
                      {(videoStats.tauxDegradation * 100).toFixed(1)}%
                    </div>
                    <div className="text-xs text-muted mt-1">
                      {videoStats.livraisonsDegradees} vidéos · relance utilisée{' '}
                      {(videoStats.tauxUtilisationRelance * 100).toFixed(0)}% du temps
                    </div>
                  </div>
                </div>

                <div className="card overflow-hidden">
                  <table className="w-full text-sm">
                    <thead className="bg-panel text-muted text-left">
                      <tr>
                        <th className="px-4 py-3 font-medium">Mode</th>
                        <th className="px-4 py-3 font-medium">Total</th>
                        <th className="px-4 py-3 font-medium">Remboursées</th>
                        <th className="px-4 py-3 font-medium">Dégradées</th>
                      </tr>
                    </thead>
                    <tbody>
                      {Object.entries(videoStats.parMode).map(([mode, s]) => (
                        <tr key={mode} className="border-t border-line">
                          <td className="px-4 py-3 font-medium">{mode}</td>
                          <td className="px-4 py-3">{s.total}</td>
                          <td className="px-4 py-3">
                            {s.rembourses}{' '}
                            <span className="text-muted text-xs">
                              ({s.total ? ((s.rembourses / s.total) * 100).toFixed(0) : 0}%)
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            {s.degrades}{' '}
                            <span className="text-muted text-xs">
                              ({s.total ? ((s.degrades / s.total) * 100).toFixed(0) : 0}%)
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </div>
        )}

        {/* ALERTES */}
        {tab === 'alertes' && (
          <div>
            <p className="text-sm text-muted mb-4 leading-relaxed">
              Sites en <strong className="text-white">failed</strong> ou{' '}
              <strong className="text-white">pending_support</strong> — notamment quand l’IA Aide
              (Opus) n’a pas pu corriger un problème de génération.
            </p>
            <div className="card overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-panel text-muted text-left">
                  <tr>
                    <th className="px-4 py-3 font-medium">Client</th>
                    <th className="px-4 py-3 font-medium">Niche / nom</th>
                    <th className="px-4 py-3 font-medium">Statut</th>
                    <th className="px-4 py-3 font-medium">Mis à jour</th>
                  </tr>
                </thead>
                <tbody>
                  {alertes.length === 0 && (
                    <tr>
                      <td colSpan={4} className="px-4 py-8 text-center text-muted">
                        Aucune alerte pour le moment
                      </td>
                    </tr>
                  )}
                  {alertes.map((s) => (
                    <tr key={s.id || s._id} className="border-t border-line">
                      <td className="px-4 py-3">
                        {typeof s.userId === 'object' ? s.userId?.email : s.userEmail || '—'}
                      </td>
                      <td className="px-4 py-3">
                        {s.name || s.niche || '—'}
                      </td>
                      <td className="px-4 py-3">
                        <span className={`text-xs px-2 py-0.5 rounded-full ${statusBadge(s.status)}`}>
                          {s.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-muted">
                        {s.updatedAt ? new Date(s.updatedAt).toLocaleString('fr-FR') : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        
        {/* ASSISTANCE CLIENTS */}
        {tab === 'tickets' && (
          <div className="grid lg:grid-cols-5 gap-4">
            <div className="lg:col-span-2 space-y-2">
              <p className="text-sm text-muted mb-3">
                Conversations où l’IA a demandé un relais humain, ou tickets ouverts.
              </p>
              {tickets.length === 0 && (
                <div className="card p-6 text-center text-muted text-sm">Aucun ticket</div>
              )}
              {tickets.map((t) => (
                <button
                  key={t.id}
                  onClick={() => {
                    setActiveTicket(t);
                    setReply('');
                  }}
                  className={`w-full text-left card p-4 transition-colors ${
                    activeTicket?.id === t.id ? 'border-blue' : 'hover:border-line'
                  }`}
                >
                  <div className="flex justify-between gap-2 text-sm">
                    <span className="font-medium truncate">{t.userEmail || t.id}</span>
                    <span
                      className={`text-xs shrink-0 px-2 py-0.5 rounded-full ${
                        t.status === 'needs_human'
                          ? 'bg-amber-500/20 text-amber-400'
                          : t.status === 'closed'
                            ? 'bg-panel text-muted'
                            : 'bg-blue/20 text-blue'
                      }`}
                    >
                      {t.status}
                    </span>
                  </div>
                  <div className="text-xs text-muted mt-1">
                    {t.updatedAt ? new Date(t.updatedAt).toLocaleString('fr-FR') : ''}
                  </div>
                </button>
              ))}
            </div>
            <div className="lg:col-span-3 card flex flex-col min-h-[360px]">
              {!activeTicket ? (
                <div className="flex-1 flex items-center justify-center text-sm text-muted p-6">
                  Sélectionnez un ticket pour répondre
                </div>
              ) : (
                <>
                  <div className="p-4 border-b border-line flex justify-between gap-2">
                    <div>
                      <div className="font-medium text-sm">{activeTicket.userEmail}</div>
                      <div className="text-xs text-muted">{activeTicket.status}</div>
                    </div>
                    {activeTicket.status !== 'closed' && (
                      <button
                        className="text-xs text-muted hover:text-white"
                        onClick={async () => {
                          try {
                            const r = await adminApi.closeSupport(activeTicket.id);
                            setActiveTicket(r.ticket);
                            setTickets((list) =>
                              list.map((x) => (x.id === r.ticket.id ? r.ticket : x))
                            );
                          } catch (err) {
                            setError((err as Error).message || 'Impossible de clôturer ce ticket.');
                          }
                        }}
                      >
                        Clôturer
                      </button>
                    )}
                  </div>
                  <div className="flex-1 overflow-y-auto p-4 space-y-2 max-h-[320px]">
                    {(activeTicket.messages || []).map((m: any) => (
                      <div
                        key={m.id}
                        className={`text-sm rounded-xl px-3 py-2 max-w-[90%] ${
                          m.role === 'user'
                            ? 'ml-auto bg-blue/30'
                            : m.role === 'admin'
                              ? 'bg-mint/15 border border-mint/30'
                              : 'bg-panel border border-line'
                        }`}
                      >
                        <div className="text-[10px] text-muted mb-0.5">
                          {m.role === 'user' ? 'Client' : m.role === 'admin' ? 'Vous' : 'IA'}
                        </div>
                        {m.content}
                      </div>
                    ))}
                  </div>
                  {activeTicket.status !== 'closed' && (
                    <form
                      className="p-3 border-t border-line flex gap-2"
                      onSubmit={async (e) => {
                        e.preventDefault();
                        if (!reply.trim()) return;
                        try {
                          const r = await adminApi.replySupport(activeTicket.id, reply.trim());
                          setActiveTicket(r.ticket);
                          setTickets((list) =>
                            list.map((x) => (x.id === r.ticket.id ? r.ticket : x))
                          );
                          setReply('');
                        } catch (err) {
                          setError((err as Error).message || 'Impossible d’envoyer cette réponse.');
                        }
                      }}
                    >
                      <input
                        className="input flex-1 text-sm"
                        value={reply}
                        onChange={(e) => setReply(e.target.value)}
                        placeholder="Répondre au client…"
                      />
                      <button type="submit" className="btn-primary rounded-lg px-4 py-2 text-sm font-semibold">
                        Envoyer
                      </button>
                    </form>
                  )}
                </>
              )}
            </div>
          </div>
        )}


        {/* SUPPORT FILE */}
        {tab === 'support' && (
          <div>
            <p className="text-sm text-muted mb-4 leading-relaxed">
              File d’attente <strong className="text-white">pending_support</strong> : cas techniques
              où le pipeline IA n’a pas abouti. Traite-les manuellement (regénération, correction,
              contact client).
            </p>
            <div className="space-y-3">
              {supportFile.length === 0 && (
                <div className="card p-8 text-center text-muted text-sm">File support vide</div>
              )}
              {supportFile.map((s) => (
                <div key={s.id || s._id} className="card p-5 flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <div className="font-medium">
                      {s.name || s.niche || 'Site'}{' '}
                      <span className="text-xs text-amber-400 ml-2">pending_support</span>
                    </div>
                    <div className="text-sm text-muted mt-1">
                      {typeof s.userId === 'object' ? s.userId?.email : '—'}
                      {s.updatedAt && (
                        <> · {new Date(s.updatedAt).toLocaleString('fr-FR')}</>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <a
                      href={`mailto:${typeof s.userId === 'object' ? s.userId?.email : ''}?subject=NexAI Support — ${encodeURIComponent(s.name || s.niche || 'votre site')}`}
                      className="btn-secondary rounded-lg px-4 py-2 text-xs"
                    >
                      Contacter le client
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* AVIS */}
        {tab === 'avis' && (
          <div className="space-y-3">
            {avis.map((a) => (
              <div key={a.id} className="card p-5">
                <div className="flex justify-between gap-3 mb-2">
                  <div>
                    <span className="font-medium">{a.name}</span>
                    <span className="text-muted text-sm ml-2">{a.role}</span>
                  </div>
                  <span className="text-amber-400 text-sm">{'★'.repeat(a.rating || 5)}</span>
                </div>
                <p className="text-sm text-muted leading-relaxed">{a.content}</p>
              </div>
            ))}
          </div>
        )}

        {/* ACADEMY */}
        {tab === 'academy' && (
          <div className="card p-6 text-sm text-muted leading-relaxed">
            <p className="mb-3">
              Upload PDF / vidéo via les endpoints admin backend existants (
              <code className="text-white">POST /admin/academy</code>
              ).
            </p>
            <p>
              Une fois le formulaire d’upload branché côté API, cette section affichera la liste et
              l’ajout de contenus.
            </p>
          </div>
        )}

        {/* INSTRUCTIONS IA */}
        {tab === 'ia' && (
          <div className="max-w-2xl space-y-10">
            {/* Instructions complémentaires — persistées, injectées dans le prompt chat (F9/B8) */}
            <div className="space-y-4">
              <div>
                <h2 className="font-semibold text-lg mb-1">Instructions complémentaires</h2>
                <p className="text-sm text-muted leading-relaxed">
                  Ce texte est ajouté à la fin du prompt du chat IA (tous modes confondus), après les
                  règles de sécurité qui restent verrouillées et non modifiables depuis cette page.
                  Utilisez-le pour affiner le ton, rappeler des consignes commerciales, etc.
                </p>
              </div>

              <textarea
                className="input min-h-[160px]"
                value={chatInstructions}
                onChange={(e) => setChatInstructions(e.target.value.slice(0, CHAT_INSTRUCTIONS_MAX))}
                placeholder="Ex : Toujours vouvoyer le client. Mettre en avant l’offre Agence pour les profils multi-sites…"
                maxLength={CHAT_INSTRUCTIONS_MAX}
              />
              <div className="flex items-center justify-between text-xs text-muted">
                <span>
                  {chatInstructions.length} / {CHAT_INSTRUCTIONS_MAX} caractères
                </span>
              </div>

              {instructionsErr && (
                <div className="text-sm text-red bg-redSoft rounded-lg px-4 py-2.5">
                  {instructionsErr}
                </div>
              )}
              {instructionsMsg && (
                <div className="text-sm text-mint bg-mintSoft rounded-lg px-4 py-2.5">
                  {instructionsMsg}
                </div>
              )}

              <button
                onClick={saveChatInstructions}
                disabled={savingInstructions || !chatInstructionsLoaded}
                className="btn-primary rounded-lg px-5 py-2.5 text-sm font-semibold disabled:opacity-50"
              >
                {savingInstructions ? 'Enregistrement…' : 'Enregistrer'}
              </button>
            </div>

            {/* Bac à sable — tester l'IA, sans impact sur les vraies conversations */}
            <div className="space-y-4 pt-8 border-t border-line">
              <div>
                <h2 className="font-semibold text-lg mb-1">Tester l’IA</h2>
                <p className="text-sm text-muted">
                  Bac à sable admin uniquement, sans débit de crédits — n’affecte aucune session client.
                </p>
              </div>
              <textarea
                className="input min-h-[120px]"
                value={iaPrompt}
                onChange={(e) => setIaPrompt(e.target.value)}
                placeholder="Votre message à l’IA…"
              />
              <button
                onClick={handleIaPrompt}
                disabled={loading}
                className="btn-secondary rounded-lg px-5 py-2.5 text-sm font-semibold"
              >
                {loading ? 'Envoi…' : 'Envoyer'}
              </button>
              {iaReply && (
                <div className="card p-5 text-sm whitespace-pre-wrap leading-relaxed">{iaReply}</div>
              )}
            </div>
          </div>
        )}
      </div>
    </DashboardShell>
  );
}
