'use client';

import { useEffect, useState } from 'react';
import DashboardShell from '@/components/DashboardShell';
import { useAuth } from '@/lib/auth-context';
import { boutiqueApi, ApiError } from '@/lib/api';

type Pack = {
  id: string; titre: string; sousTitre: string | null; description: string | null;
  creditsCost: number; gratuit: boolean; imageUrl: string | null;
  nbProduits: number; accessible: boolean;
};
type Produit = {
  id: string; title: string; description: string | null; imageUrl: string | null;
  creditsCost: number; isFreeForSubscriber: boolean; unlocked: boolean;
};

/**
 * Boutique NexAI — organisée en PACKS.
 * Le client voit d'abord des cartes de packs (même principe que les options
 * de NexAI Web), puis les PDF du pack ouvert. Uniquement des PDF ici :
 * les vidéos restent à l'Académie.
 */
export default function BoutiquePage() {
  const { user } = useAuth();
  const [packs, setPacks] = useState<Pack[]>([]);
  const [packOuvert, setPackOuvert] = useState<Pack | null>(null);
  const [produits, setProduits] = useState<Produit[]>([]);
  const [chargement, setChargement] = useState(true);
  const [chargementProduits, setChargementProduits] = useState(false);
  const [erreur, setErreur] = useState('');
  const [achatEnCours, setAchatEnCours] = useState('');

  const estEssai = user?.plan === 'trial' && user?.role !== 'admin';

  useEffect(() => {
    let actif = true;
    boutiqueApi.packs()
      .then((r) => { if (actif) setPacks(r.packs); })
      .catch((e) => { if (actif) setErreur(e instanceof ApiError ? e.message : 'Chargement impossible.'); })
      .finally(() => { if (actif) setChargement(false); });
    return () => { actif = false; };
  }, []);

  async function ouvrirPack(pack: Pack) {
    setErreur(''); setPackOuvert(pack); setChargementProduits(true);
    try {
      const r = await boutiqueApi.produitsDuPack(pack.id);
      setProduits(r.produits);
    } catch (e) {
      setErreur(e instanceof ApiError ? e.message : 'Chargement du pack impossible.');
      setProduits([]);
    } finally { setChargementProduits(false); }
  }

  async function debloquer(produit: Produit) {
    setErreur(''); setAchatEnCours(produit.id);
    try {
      await boutiqueApi.purchase(produit.id);
      if (packOuvert) await ouvrirPack(packOuvert);
    } catch (e) {
      setErreur(e instanceof ApiError ? e.message : 'Déblocage impossible.');
    } finally { setAchatEnCours(''); }
  }

  if (packOuvert) {
    return (
      <DashboardShell>
        <button type="button" onClick={() => { setPackOuvert(null); setProduits([]); }}
          className="mb-5 text-sm font-semibold text-muted hover:text-blue">
          &larr; Tous les packs
        </button>
        <div className="mb-8">
          <h1 className="text-2xl font-bold mb-1">{packOuvert.titre}</h1>
          {packOuvert.sousTitre && <p className="text-sm text-muted">{packOuvert.sousTitre}</p>}
        </div>
        {erreur && <div className="mb-6 rounded border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-300">{erreur}</div>}
        {chargementProduits ? (
          <p className="text-sm text-muted">Chargement&hellip;</p>
        ) : produits.length === 0 ? (
          <p className="text-sm text-muted">Aucun document publié dans ce pack pour l&apos;instant.</p>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {produits.map((p) => (
              <div key={p.id} className="flex flex-col rounded-lg border border-line bg-panel p-4">
                <h3 className="mb-1 text-sm font-semibold">{p.title}</h3>
                {p.description && <p className="mb-3 flex-1 text-xs leading-relaxed text-muted">{p.description}</p>}
                {p.unlocked ? (
                  <span className="mt-auto text-xs font-bold uppercase tracking-wide text-mint">Débloqué</span>
                ) : estEssai ? (
                  <span className="mt-auto text-xs text-muted">Réservé aux abonnés</span>
                ) : (
                  <button type="button" onClick={() => debloquer(p)} disabled={achatEnCours !== ''}
                    className="mt-auto rounded bg-blue px-3 py-2 text-xs font-bold uppercase tracking-wide text-inkBtn disabled:opacity-60">
                    {achatEnCours === p.id ? '…' : p.creditsCost === 0 ? 'Obtenir' : `Débloquer — ${p.creditsCost} cr`}
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </DashboardShell>
    );
  }

  return (
    <DashboardShell>
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-1">Boutique NexAI</h1>
        <p className="text-sm text-muted">Des packs de produits digitaux prêts à revendre, droit de revente inclus.</p>
      </div>
      {erreur && <div className="mb-6 rounded border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-300">{erreur}</div>}
      {chargement ? (
        <p className="text-sm text-muted">Chargement&hellip;</p>
      ) : packs.length === 0 ? (
        <p className="text-sm text-muted">Aucun pack publié pour l&apos;instant. Revenez bientôt.</p>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {packs.map((pack) => (
            <button key={pack.id} type="button" onClick={() => pack.accessible && ouvrirPack(pack)}
              disabled={!pack.accessible}
              className={`flex flex-col rounded-lg border bg-panel p-5 text-left transition ${
                !pack.accessible
                  ? 'border-line opacity-70 cursor-not-allowed'
                  : pack.gratuit
                  ? 'border-mint/60 hover:-translate-y-0.5'
                  : 'border-line hover:border-blue hover:-translate-y-0.5'}`}>
              <span className={`mb-3 self-start rounded px-2 py-1 text-[0.65rem] font-bold uppercase tracking-wide ${
                pack.gratuit ? 'bg-mint/15 text-mint' : 'bg-blueSoft text-blue'}`}>
                {pack.gratuit ? 'Offert' : 'Pack'}
              </span>
              <h3 className="mb-1 text-base font-bold">{pack.titre}</h3>
              {pack.sousTitre && <p className="mb-2 text-sm text-muted">{pack.sousTitre}</p>}
              {pack.description && <p className="mb-3 flex-1 text-xs leading-relaxed text-muted">{pack.description}</p>}
              <div className="mt-auto flex items-center justify-between pt-2">
                <span className="text-xs text-muted">{pack.nbProduits} document{pack.nbProduits > 1 ? 's' : ''}</span>
                <span className={`text-sm font-bold ${pack.gratuit ? 'text-mint' : 'text-blue'}`}>
                  {pack.gratuit ? 'Gratuit' : `${pack.creditsCost} crédits`}
                </span>
              </div>
              {!pack.accessible && (
                <span className="mt-3 border-t border-line pt-2 text-[0.7rem] font-semibold text-muted">
                  Réservé aux abonnements payants
                </span>
              )}
            </button>
          ))}
        </div>
      )}
    </DashboardShell>
  );
}
