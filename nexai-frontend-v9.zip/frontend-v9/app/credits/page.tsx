'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import DashboardShell from '@/components/DashboardShell';
import { useAuth } from '@/lib/auth-context';
import { creditsApi, usersApi, ApiError } from '@/lib/api';

type Pack = {
  id: string;
  credits: number;
  label: string;
};

type Transaction = {
  id?: string;
  _id?: string;
  type: string;
  amount: number;
  balanceAfter: number;
  note?: string;
  createdAt: string;
};

/** Libellés lisibles des types de transaction renvoyés par le backend. */
const LIBELLES: Record<string, string> = {
  achat_pack: 'Achat de crédits',
  achat_abonnement: 'Abonnement',
  apercu_site: 'Création de site',
  mise_en_ligne: 'Mise en ligne',
  logo: 'Création de logo',
  coach_business: 'Coach business',
  modification_ia: 'Amélioration IA',
  video_ad: 'Vidéo IA',
  video_ad_relance: 'Relance vidéo',
  achat_domaine: 'Nom de domaine',
  achat_boutique: 'Achat Boutique',
  achat_academy: 'Achat Académie',
  ajustement_admin: 'Ajustement',
  remboursement: 'Remboursement',
};

export default function CreditsPage() {
  const { user } = useAuth();
  const [packs, setPacks] = useState<Pack[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [solde, setSolde] = useState<number | null>(null);
  const [chargement, setChargement] = useState(true);
  const [erreur, setErreur] = useState('');
  const [achatEnCours, setAchatEnCours] = useState<number | null>(null);

  // L'essai gratuit ne peut pas acheter de packs (Architecture v6, section 8).
  const estEssai = user?.plan === 'trial' && user?.role !== 'admin';
  const illimite = user?.role === 'admin';

  useEffect(() => {
    let actif = true;
    (async () => {
      try {
        const [p, t] = await Promise.all([
          creditsApi.packs().catch(() => ({ packs: [], balance: 0 })),
          usersApi.credits().catch(() => ({ transactions: [], creditsBalance: 0 })),
        ]);
        if (!actif) return;
        setPacks((p as { packs?: Pack[] }).packs ?? []);
        const td = t as { transactions?: Transaction[]; creditsBalance?: number };
        setTransactions(td.transactions ?? []);
        if (typeof td.creditsBalance === 'number') setSolde(td.creditsBalance);
      } catch (e) {
        if (actif) setErreur(e instanceof ApiError ? e.message : 'Chargement impossible.');
      } finally {
        if (actif) setChargement(false);
      }
    })();
    return () => {
      actif = false;
    };
  }, []);

  async function acheter(pack: Pack) {
    setErreur('');
    setAchatEnCours(pack.credits);
    try {
      const r = await creditsApi.acheter({ packId: pack.id, currency: 'XOF' });
      const lien = (r as { paymentLink?: string }).paymentLink;
      // Le paiement se fait chez le prestataire : les crédits ne sont
      // ajoutés qu'à la confirmation du webhook, jamais au clic.
      if (lien) window.location.href = lien;
      else setErreur("Le lien de paiement n'a pas pu être généré. Réessayez.");
    } catch (e) {
      setErreur(e instanceof ApiError ? e.message : 'Achat impossible.');
    } finally {
      setAchatEnCours(null);
    }
  }

  return (
    <DashboardShell>
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-1">Crédits</h1>
        <p className="text-sm text-[var(--muted)]">
          Vos crédits servent à créer des sites, des logos et des vidéos.
        </p>
      </div>

      {erreur && (
        <div className="mb-6 rounded border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-300">
          {erreur}
        </div>
      )}

      {/* Solde */}
      <div className="mb-8 rounded-lg border border-[var(--line)] bg-[var(--panel)] p-6">
        <p className="text-xs uppercase tracking-wide text-[var(--muted)] mb-2">Solde actuel</p>
        <p className="text-3xl font-bold">
          {illimite ? '∞' : solde ?? user?.creditsBalance ?? 0}
          {!illimite && <span className="ml-2 text-base font-normal text-[var(--muted)]">crédits</span>}
        </p>
        {illimite && (
          <p className="mt-2 text-sm text-[var(--muted)]">
            Compte administrateur — aucun débit n&apos;est appliqué.
          </p>
        )}
      </div>

      {/* Packs */}
      <section className="mb-10">
        <h2 className="text-lg font-semibold mb-3">Recharger</h2>

        {estEssai ? (
          <div className="rounded-lg border border-[var(--line)] bg-[var(--panel)] p-6">
            <p className="text-sm leading-relaxed text-[var(--muted)] mb-4">
              Les packs de crédits vous permettent de générer plus de sites, logos et vidéos sans
              attendre votre renouvellement mensuel. Disponible dès votre abonnement.
            </p>
            <Link
              href="/abonnement"
              className="inline-block rounded bg-[var(--blue)] px-5 py-2.5 text-sm font-bold uppercase tracking-wide text-[#0E1118]"
            >
              Voir les abonnements
            </Link>
          </div>
        ) : chargement ? (
          <p className="text-sm text-[var(--muted)]">Chargement…</p>
        ) : packs.length === 0 ? (
          <p className="text-sm text-[var(--muted)]">Aucun pack disponible pour le moment.</p>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {packs.map((p) => (
              <div
                key={p.credits}
                className="rounded-lg border border-[var(--line)] bg-[var(--panel)] p-5"
              >
                <p className="text-2xl font-bold">{p.credits}</p>
                <p className="mb-3 text-xs uppercase tracking-wide text-[var(--muted)]">crédits</p>
                <p className="mb-4 text-sm font-semibold text-[var(--blue-text)]">{p.label}</p>
                <button
                  type="button"
                  onClick={() => acheter(p)}
                  disabled={achatEnCours !== null}
                  className="w-full rounded bg-[var(--blue)] px-4 py-2.5 text-sm font-bold uppercase tracking-wide text-[#0E1118] disabled:opacity-60"
                >
                  {achatEnCours === p.credits ? 'Redirection…' : 'Acheter'}
                </button>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Historique */}
      <section>
        <h2 className="text-lg font-semibold mb-3">Historique</h2>
        <div className="overflow-x-auto rounded-lg border border-[var(--line)] bg-[var(--panel)]">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[var(--line)] text-left text-xs uppercase tracking-wide text-[var(--muted)]">
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3">Opération</th>
                <th className="px-4 py-3 text-right">Crédits</th>
                <th className="px-4 py-3 text-right">Solde</th>
              </tr>
            </thead>
            <tbody>
              {chargement ? (
                <tr>
                  <td colSpan={4} className="px-4 py-8 text-center text-[var(--muted)]">
                    Chargement…
                  </td>
                </tr>
              ) : transactions.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-4 py-8 text-center text-[var(--muted)]">
                    Aucune opération pour l&apos;instant.
                  </td>
                </tr>
              ) : (
                transactions.map((t) => (
                  <tr key={t.id ?? t._id} className="border-b border-[var(--line)] last:border-0">
                    <td className="px-4 py-3 text-[var(--muted)]">
                      {new Date(t.createdAt).toLocaleDateString('fr-FR', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                      })}
                    </td>
                    <td className="px-4 py-3">{LIBELLES[t.type] ?? t.note ?? t.type}</td>
                    <td
                      className={`px-4 py-3 text-right font-semibold ${
                        t.amount > 0 ? 'text-emerald-400' : ''
                      }`}
                    >
                      {t.amount > 0 ? `+${t.amount}` : t.amount}
                    </td>
                    <td className="px-4 py-3 text-right text-[var(--muted)]">{t.balanceAfter}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>
    </DashboardShell>
  );
}
