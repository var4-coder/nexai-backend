'use client';

import DashboardShell from '@/components/DashboardShell';
import Link from 'next/link';

const SECTIONS = [
  {
    id: 'demarrer',
    title: 'Démarrer avec NexAI',
    items: [
      {
        q: 'Comment créer mon compte ?',
        a: 'Cliquez sur « Créer mon site » ou « Commencer l’essai de 7 jours ». Indiquez votre email et un mot de passe (8 caractères minimum). Un code à 6 chiffres vous est envoyé par email : saisissez-le pour activer votre compte. Vous recevez 12 crédits offerts.',
      },
      {
        q: 'Qu’est-ce qu’un crédit ?',
        a: 'Les crédits servent à payer les actions de l’IA : générer un site (10), le mettre en ligne (15), le régénérer (15), le modifier par IA (5), créer un logo (5), ou un nom de domaine hors quota (environ 25). Modifier un texte à la main ne coûte rien.',
      },
      {
        q: 'Quelle est la différence entre les abonnements ?',
        a: 'Starter = surtout l’Académie (formations). Créateur = créer et lancer des sites avec l’IA. Agence et Pro Max = multi-clients (Espace Agence) + Analytics et SEO. Vous pouvez changer de plan à tout moment.',
      },
    ],
  },
  {
    id: 'sites',
    title: 'Créer et gérer un site',
    items: [
      {
        q: 'Comment créer un site avec l’IA ?',
        a: 'Allez dans « IA & Création ». Décrivez votre activité en quelques phrases. Choisissez la niche qui correspond le mieux. L’assistant pose des questions précises. Quand le brief est clair, cliquez sur « Générer le site » (10 crédits). Vous verrez des propositions : choisissez celle qui vous plaît.',
      },
      {
        q: 'Pourquoi la zone d’écriture est parfois grisée ?',
        a: 'Pour éviter les discussions inutiles. Vous ne pouvez écrire que lorsque l’assistant attend une réponse (choix de niche, description, clarification). Cela garantit un brief de qualité et un site bien compris.',
      },
      {
        q: 'Que signifient « En ligne » et « Hors ligne » ?',
        a: 'En ligne = votre site est publié et accessible sur internet. Hors ligne = le site n’est pas (ou plus) publié. Vous pouvez le remettre en ligne plus tard.',
      },
      {
        q: 'Puis-je modifier mon site après le lancement ?',
        a: 'Oui. L’édition manuelle des textes (titres, paragraphes) est gratuite et illimitée. Pour un changement plus important (structure, style, nouvelle section), utilisez « Modifier par IA » (5 crédits).',
      },
    ],
  },
  {
    id: 'video',
    title: 'Vidéo publicitaire IA',
    items: [
      {
        q: 'Quels types de vidéo puis-je créer ?',
        a: 'Trois formats, pensés pour des besoins différents. « Publicité IA avec voix » : un montage cinématique en plusieurs plans avec une narration et une musique de fond, sans personnage à l\u2019écran — idéal pour mettre en avant votre site et vos produits. « Publicité IA avec avatar » : un présentateur généré par IA qui parle directement à la caméra, en format court — pour donner un visage humain à votre marque. « Mini-Film IA » : un format long (2 minutes) avec avatar sur toute la durée, pour un contenu plus narratif (mini-film de marque, présentation approfondie, épisode de série).',
      },
      {
        q: 'Que dois-je fournir pour lancer une vidéo ?',
        a: 'Au minimum une description de votre produit/service, ou l\u2019URL de votre site (les deux ensemble donnent le meilleur résultat). Vous choisissez ensuite le type de vidéo, le ratio (16:9 ou 9:16), le style visuel et la durée. Le nom de marque et le texte du bouton d\u2019appel à l\u2019action sont optionnels — sans eux, NexAI utilise des valeurs par défaut raisonnables.',
      },
      {
        q: 'Pourquoi on me demande parfois de préciser ma description avant de lancer ?',
        a: 'Si vous ne fournissez pas d\u2019URL de site, votre description est la seule source d\u2019information pour écrire le texte de la publicité. Une description trop vague donnerait une vidéo générique qui ne vous ressemble pas — NexAI vous indique alors précisément ce qui manque (le produit, la cible, votre marque…) avant de lancer la génération, pour vous éviter de dépenser des crédits sur un résultat décevant. Avec une URL de site, cette vérification n\u2019est pas nécessaire : le contenu réel de votre site suffit à personnaliser la vidéo.',
      },
      {
        q: 'Puis-je ajouter mes propres photos produit ?',
        a: 'Oui, jusqu\u2019à 6 photos (PNG, JPEG ou WEBP). Elles sont utilisées en priorité pour mettre en scène vos vrais produits dans la vidéo, mélangées avec des visuels d\u2019ambiance choisis pour correspondre à votre univers de marque. Si vous avez une URL de site, NexAI peut aussi repérer automatiquement des photos produit présentes sur votre site — les photos que vous ajoutez vous-même restent toujours prioritaires.',
      },
      {
        q: 'Le rendu utilise-t-il vraiment mon site, ou tout est généré par l\u2019IA ?',
        a: 'Les deux, volontairement. Une partie de la vidéo montre un vrai extrait de votre site (la preuve concrète que c\u2019est bien le vôtre), et les autres plans sont générés par IA en s\u2019appuyant sur vos vraies photos produit quand elles sont disponibles. Ce mélange donne un résultat plus crédible qu\u2019une vidéo 100% générique.',
      },
      {
        q: 'Combien de temps prend une génération, et que se passe-t-il si ça échoue ?',
        a: 'Comptez 2 à 4 minutes en général. Vous voyez la progression en direct (mise en file, génération, finalisation). Les crédits sont débités au lancement ; en cas d\u2019échec technique, ils vous sont automatiquement remboursés.',
      },
      {
        q: 'Combien coûte une vidéo ?',
        a: 'Le coût dépend du type et de la durée choisis, affiché en crédits directement sur chaque option avant de lancer. Génération réservée aux abonnements Créateur, Agence et Pro Max (Starter peut explorer l\u2019outil mais pas lancer de génération).',
      },
    ],
  },
  {
    id: 'domaines',
    title: 'Noms de domaine',
    items: [
      {
        q: 'Qu’est-ce qu’un sous-domaine NexAI ?',
        a: 'C’est une adresse gratuite du type mon-studio.nexai.fr. Idéal pour démarrer rapidement, sans rien acheter. Votre site est tout de suite accessible.',
      },
      {
        q: 'Acheter un nom de domaine, c’est quoi ?',
        a: 'Vous obtenez une adresse professionnelle du type monstudio.fr ou monstudio.com. Si votre abonnement inclut encore un domaine gratuit, c’est sans crédit supplémentaire. Sinon, cela coûte des crédits (le prix s’affiche avant validation).',
      },
      {
        q: 'J’ai déjà mon propre domaine (BYOD)',
        a: 'Si vous possédez déjà un nom de domaine ailleurs, vous pouvez l’utiliser. Vous indiquerez l’adresse au moment du lancement. Aucun crédit n’est débité pour cette option.',
      },
      {
        q: 'Pourquoi on me propose des variantes ?',
        a: 'Pour éviter les regrets. Avant de prélever des crédits, NexAI vous montre le nom choisi + des variantes (disponibles et leur coût). Vous validez seulement quand vous êtes sûr.',
      },
    ],
  },
  {
    id: 'academy',
    title: 'Académie',
    items: [
      {
        q: 'Comment fonctionne l’Académie ?',
        a: 'Chaque formation contient deux catégories séparées : PDF et Vidéos. Cliquez sur une formation, puis sur la catégorie, puis sur le contenu pour l’ouvrir.',
      },
      {
        q: 'Que signifie le badge « Premium » ?',
        a: 'Les contenus Premium sont réservés aux abonnés (Starter et plus). En essai gratuit, vous voyez tout mais seuls les contenus gratuits s’ouvrent. Le badge vous montre la valeur de l’abonnement.',
      },
      {
        q: 'Puis-je télécharger les PDF ou vidéos ?',
        a: 'Non. Tout est en consultation uniquement (lecteur sécurisé, filigrane sur les PDF). Cela protège le contenu tout en vous permettant de vous former.',
      },
    ],
  },
  {
    id: 'boutique',
    title: 'Boutique',
    items: [
      {
        q: 'À quoi sert la Boutique ?',
        a: 'Elle propose des templates, ressources et produits digitaux (parfois avec droit de revente). Certains sont gratuits pour les abonnés, d’autres s’achètent avec des crédits.',
      },
      {
        q: 'En essai, puis-je acheter ?',
        a: 'Non. La boutique est visible en essai mais les achats sont verrouillés. Passez à un abonnement pour débloquer.',
      },
    ],
  },
  {
    id: 'agence',
    title: 'Espace Agence (Agence & Pro Max)',
    items: [
      {
        q: 'À qui s’adresse l’Espace Agence ?',
        a: 'Aux agences, freelances et développeurs qui créent des sites pour plusieurs clients. Vous gérez clients, sites et suivi au même endroit.',
      },
      {
        q: 'Mes clients ont-ils un compte NexAI ?',
        a: 'Non. Dans la version actuelle, c’est vous qui gérez tout depuis votre compte. Vos clients n’ont pas besoin de s’inscrire.',
      },
    ],
  },
  {
    id: 'paiements',
    title: 'Paiements sur vos sites',
    items: [
      {
        q: 'Lien personnel',
        a: 'Vous collez le lien de votre page de paiement (Chariow recommandé). NexAI n’encaisse pas : l’argent va chez vous. Réglages : Paramètres → Paiements.',
      },
      {
        q: 'Recevoir via mon compte NexAI',
        a: 'Les paiements sont encaissés via votre compte NexAI, puis reversés tous les 3 jours (Mobile Money ou adresse crypto) après validation. Idéal si vous n’avez pas encore de page de paiement personnelle. Réglages : Paramètres → Paiements.',
      },
    ],
  },
  {
    id: 'credits',
    title: 'Crédits et abonnements',
    items: [
      {
        q: 'Que faire si je n’ai plus de crédits ?',
        a: 'Achetez un pack de crédits (10, 20, 50, 100 ou 200) depuis Paramètres → Crédits, sans changer de plan. Ou passez à un abonnement supérieur qui donne plus de crédits chaque mois.',
      },
      {
        q: 'Les crédits non utilisés sont-ils perdus ?',
        a: 'Les crédits de votre solde restent tant que le compte est actif. Les crédits mensuels de l’abonnement sont ajoutés à chaque renouvellement.',
      },
    ],
  },
];

export default function GuidePage() {
  return (
    <DashboardShell>
      <div className="p-8 max-w-3xl">
        <h1 className="text-2xl font-display font-bold mb-1">Guide NexAI</h1>
        <p className="text-muted text-sm mb-8">
          Tout ce qu’il faut savoir, expliqué simplement. Cliquez sur une question pour voir la réponse.
        </p>

        <div className="space-y-10">
          {SECTIONS.map((section) => (
            <section key={section.id} id={section.id}>
              <h2 className="text-lg font-semibold mb-4 text-blue">{section.title}</h2>
              <div className="space-y-3">
                {section.items.map((item) => (
                  <details key={item.q} className="card p-5 group">
                    <summary className="font-medium cursor-pointer list-none flex justify-between items-start gap-3">
                      <span>{item.q}</span>
                      <span className="text-muted group-open:rotate-180 transition-transform shrink-0">▾</span>
                    </summary>
                    <p className="text-sm text-muted mt-3 leading-relaxed">{item.a}</p>
                  </details>
                ))}
              </div>
            </section>
          ))}
        </div>

        <div className="mt-12 pt-8 border-t border-line">
          <p className="text-sm text-muted mb-3">Vous ne trouvez pas la réponse ?</p>
          <Link
            href="/aide"
            className="btn-primary rounded-lg px-6 py-2.5 text-sm font-semibold inline-block"
          >
            Contacter le support
          </Link>
        </div>
      </div>
    </DashboardShell>
  );
}
