'use client';

import Link from 'next/link';
import DashboardShell from '@/components/DashboardShell';
import { useAuth } from '@/lib/auth-context';

/**
 * Hub NexAI Web — Architecture v6, section 5.
 *
 * Les 4 options sont TOUJOURS visibles. Celles qui ne sont pas incluses
 * dans l'abonnement du client restent affichées, verrouillées, avec le
 * texte expliquant quel abonnement les débloque : c'est un levier de
 * conversion, jamais un simple refus.
 *
 * Les crédits s'affichent sur la carte, jamais noyés dans le descriptif.
 */

interface Option {
  href: string;
  tag: string;
  titre: string;
  description: string;
  prix: string;
  /** Plans qui peuvent réellement lancer cette option */
  plansAutorises: string[];
  principal?: boolean;
}

const OPTIONS: Option[] = [
  {
    href: '/assistant?mode=site',
    tag: 'Principal',
    titre: 'Créer un site',
    description:
      "NexAI Web crée votre site et vous montre l'aperçu avant sa mise en ligne.",
    prix: 'Normale 12 cr · Premium 25 cr',
    plansAutorises: ['trial', 'createur', 'agence', 'pro_max'],
    principal: true,
  },
  {
    href: '/assistant?mode=business',
    tag: 'Coach',
    titre: 'Trouver mon business',
    description:
      "Pas encore d'idée ? Le coach vous propose une activité et un plan pour démarrer.",
    prix: '6 crédits',
    // Disponible sur TOUS les plans, essai compris (section 6).
    plansAutorises: ['trial', 'starter', 'createur', 'agence', 'pro_max'],
  },
  {
    href: '/assistant?mode=logo',
    tag: 'Identité',
    titre: 'Créer un logo',
    description:
      'Un logo professionnel pour votre marque, réutilisable sur tous vos sites.',
    prix: '6 crédits',
    plansAutorises: ['createur', 'agence', 'pro_max'],
  },
  {
    href: '/assistant?mode=edit',
    tag: 'Évolution',
    titre: 'Modifier un site',
    description:
      "Modifiez les textes, les visuels ou la structure d'un site déjà créé.",
    prix: 'Textes 0 cr · Améliorer 8 cr',
    plansAutorises: ['createur', 'agence', 'pro_max'],
  },
];

export default function CreerUnSitePage() {
  const { user } = useAuth();
  const plan = user?.plan ?? 'trial';
  // Le compte administrateur accède à tout, sans restriction (section 18).
  const estAdmin = user?.role === 'admin';

  return (
    <DashboardShell>
      <div className="mb-8">
        <h1 className="text-2xl font-semibold mb-2">Créer un site</h1>
        <p className="text-muted">
          Les options affichées dépendent de votre abonnement. Passez à une offre supérieure pour
          débloquer les autres.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 max-w-4xl">
        {OPTIONS.map((o) => {
          const autorise = estAdmin || o.plansAutorises.includes(plan);

          if (!autorise) {
            return (
              <div
                key={o.titre}
                className="block p-5 rounded-lg border border-line bg-panel opacity-60"
              >
                <span className="inline-block text-[10px] font-bold uppercase tracking-wider text-blue bg-blue/15 px-2 py-0.5 rounded mb-2.5">
                  {o.tag}
                </span>
                <h3 className="text-base font-semibold mb-1.5">{o.titre}</h3>
                <p className="text-sm text-muted leading-relaxed mb-2.5">{o.description}</p>
                <span className="text-xs font-bold text-blue">{o.prix}</span>
                <p className="mt-3 pt-3 border-t border-line text-xs font-semibold text-muted">
                  Réservé aux abonnements payants
                </p>
              </div>
            );
          }

          return (
            <Link
              key={o.titre}
              href={o.href}
              className={`block p-5 rounded-lg border bg-panel transition-all hover:-translate-y-0.5 ${
                o.principal ? 'border-blue' : 'border-line hover:border-blue'
              }`}
            >
              <span className="inline-block text-[10px] font-bold uppercase tracking-wider text-blue bg-blue/15 px-2 py-0.5 rounded mb-2.5">
                {o.tag}
              </span>
              <h3 className="text-base font-semibold mb-1.5">{o.titre}</h3>
              <p className="text-sm text-muted leading-relaxed mb-2.5">{o.description}</p>
              <span className="text-xs font-bold text-blue">{o.prix}</span>
            </Link>
          );
        })}
      </div>
    </DashboardShell>
  );
}
