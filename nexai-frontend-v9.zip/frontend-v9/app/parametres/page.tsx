'use client';

import { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import DashboardShell from '@/components/DashboardShell';
import { useAuth } from '@/lib/auth-context';
import { PLANS } from '@/lib/plans';
import {
  usersApi,
  creditsApi,
  type PaymentModeUi,
  type CompteReversement,
  type PaymentProviderUi,
} from '@/lib/api';
import Link from 'next/link';

type Tab = 'profil' | 'securite' | 'abonnement' | 'credits' | 'paiements';

const SUPPORT_EMAIL = process.env.NEXT_PUBLIC_SUPPORT_EMAIL || 'support@nexai.fr';

export default function ParametresPage() {
  return (
    <Suspense fallback={null}>
      <ParametresContent />
    </Suspense>
  );
}

function ParametresContent() {
  const { user, refresh } = useAuth();
  const searchParams = useSearchParams();
  const tabFromUrl = searchParams.get('tab') as Tab | null;
  const initialTab: Tab =
    tabFromUrl && ['profil', 'securite', 'abonnement', 'credits', 'paiements'].includes(tabFromUrl)
      ? tabFromUrl
      : 'profil';
  const [tab, setTab] = useState<Tab>(initialTab);
  const planInfo = PLANS.find((p) => p.id === user?.plan);

  useEffect(() => {
    const t = searchParams.get('tab') as Tab | null;
    if (t && ['profil', 'securite', 'abonnement', 'credits', 'paiements'].includes(t)) {
      setTab(t);
    }
  }, [searchParams]);

  // Paiements state
  const [payMode, setPayMode] = useState<PaymentModeUi>('nexai');
  const [personalLink, setPersonalLink] = useState('');
  const [personalProvider, setPersonalProvider] = useState<PaymentProviderUi | ''>('chariow');
  const [revType, setRevType] = useState<'mobile_money' | 'crypto'>('mobile_money');
  const [operateur, setOperateur] = useState('Wave');
  const [numero, setNumero] = useState('');
  const [cryptoAddress, setCryptoAddress] = useState('');
  const [paySaving, setPaySaving] = useState(false);
  const [payMsg, setPayMsg] = useState<string | null>(null);
  const [payErr, setPayErr] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    usersApi
      .me()
      .then((u: any) => {
        if (cancelled) return;
        if (u.defaultPaymentMode) setPayMode(u.defaultPaymentMode);
        if (u.personalPaymentLink) setPersonalLink(u.personalPaymentLink);
        if (u.personalPaymentProvider) setPersonalProvider(u.personalPaymentProvider);
        const rev = u.compteReversement as CompteReversement | null;
        if (rev?.type) setRevType(rev.type);
        if (rev?.operateur) setOperateur(rev.operateur);
        if (rev?.numero) setNumero(rev.numero);
        if (rev?.cryptoAddress) setCryptoAddress(rev.cryptoAddress);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, []);

  async function savePayments() {
    setPaySaving(true);
    setPayMsg(null);
    setPayErr(null);
    try {
      await usersApi.updatePayments({
        defaultPaymentMode: payMode,
        personalPaymentLink: payMode === 'lien_personnel' ? personalLink : undefined,
        personalPaymentProvider:
          payMode === 'lien_personnel' && personalProvider ? personalProvider : undefined,
        compteReversement:
          payMode === 'nexai'
            ? {
                type: revType,
                operateur: revType === 'mobile_money' ? operateur : undefined,
                numero: revType === 'mobile_money' ? numero : undefined,
                cryptoAddress: revType === 'crypto' ? cryptoAddress : undefined,
              }
            : undefined,
      });
      setPayMsg('Réglages de paiement enregistrés.');
      await refresh();
    } catch (e: any) {
      setPayErr(e.message || 'Erreur lors de l’enregistrement');
    } finally {
      setPaySaving(false);
    }
  }

  // Achat de crédits
  const [packs, setPacks] = useState<{ id: string; credits: number; label: string }[]>([]);
  const [buyingPack, setBuyingPack] = useState<string | null>(null);
  const [creditsErr, setCreditsErr] = useState<string | null>(null);

  useEffect(() => {
    if (tab !== 'credits') return;
    creditsApi
      .packs()
      .then((r) => setPacks(r.packs))
      .catch((e) => setCreditsErr(e.message || 'Impossible de charger les packs de crédits.'));
  }, [tab]);

  async function buyPack(packId: string) {
    setBuyingPack(packId);
    setCreditsErr(null);
    try {
      const r = await creditsApi.acheter({ packId });
      if (r.paymentLink) {
        window.open(r.paymentLink, '_blank', 'noopener,noreferrer');
      } else {
        setCreditsErr(
          "Le lien de paiement n'a pas pu être généré pour le moment. Réessayez dans un instant."
        );
      }
    } catch (e: any) {
      setCreditsErr(e.message || "Erreur lors de la création du lien de paiement.");
    } finally {
      setBuyingPack(null);
    }
  }

  const tabs: { id: Tab; label: string }[] = [
    { id: 'profil', label: 'Profil' },
    { id: 'securite', label: 'Sécurité' },
    { id: 'abonnement', label: 'Abonnement' },
    { id: 'credits', label: 'Crédits' },
    { id: 'paiements', label: 'Paiements' },
  ];

  return (
    <DashboardShell>
      <div className="p-8 max-w-3xl">
        <h1 className="text-2xl font-display font-bold mb-1">Paramètres</h1>
        <p className="text-muted text-sm mb-8">Gérez votre compte, abonnement et encaissements</p>

        <div className="flex gap-1 mb-8 border-b border-line overflow-x-auto">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`px-4 py-2.5 text-sm border-b-2 -mb-px transition-colors whitespace-nowrap ${
                tab === t.id
                  ? 'border-blue text-blue font-medium'
                  : 'border-transparent text-muted hover:text-white'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {tab === 'profil' && (
          <div className="space-y-6">
            <div>
              <label className="text-sm text-muted block mb-1.5">Nom</label>
              <input className="input max-w-md" defaultValue={user?.name || ''} disabled />
              <p className="text-xs text-muted mt-1.5">
                Le nom affiché n’est pas encore modifiable depuis cette page. Contactez le
                support pour le mettre à jour.
              </p>
            </div>
            <div>
              <label className="text-sm text-muted block mb-1.5">Email</label>
              <input className="input max-w-md" defaultValue={user?.email || ''} disabled />
            </div>
          </div>
        )}

        {tab === 'securite' && (
          <div className="space-y-6">
            <p className="text-sm text-muted">Changez votre mot de passe depuis la page de connexion (mot de passe oublié) ou contactez le support.</p>
          </div>
        )}

        {tab === 'abonnement' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between py-3 border-b border-line">
              <span className="text-muted">Plan actuel</span>
              <span className="font-semibold">{planInfo?.label || user?.plan}</span>
            </div>
            <div className="flex items-center justify-between py-3 border-b border-line">
              <span className="text-muted">Crédits mensuels</span>
              <span>{planInfo?.credits ?? '—'}</span>
            </div>
            <div className="flex items-center justify-between py-3 border-b border-line">
              <span className="text-muted">Domaines inclus</span>
              <span>{planInfo?.domainsIncluded ?? 0}</span>
            </div>
            <p className="text-sm text-muted">
              Le changement de plan n’est pas encore en libre-service depuis cette page.
              Contactez-nous pour passer à un autre abonnement — le changement et les crédits
              associés sont appliqués rapidement.
            </p>
            <div className="grid sm:grid-cols-2 gap-3">
              {PLANS.filter((p) => p.id !== 'essai' && p.id !== 'admin').map((p) => (
                <a
                  key={p.id}
                  href={`mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(
                    `Changement d'abonnement vers ${p.label}`
                  )}`}
                  className={`text-left p-4 rounded-xl border transition-colors block ${
                    p.id === user?.plan
                      ? 'border-blue bg-blueSoft'
                      : 'border-line hover:border-lineLt'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="font-semibold">{p.label}</div>
                    {p.id === user?.plan && (
                      <span className="text-xs text-blue font-medium shrink-0">Plan actuel</span>
                    )}
                  </div>
                  <div className="text-sm text-muted mt-0.5">
                    {p.price}/mois · {p.credits} crédits
                  </div>
                  {p.id !== user?.plan && (
                    <div className="text-xs text-blue mt-2">Nous contacter pour passer à ce plan →</div>
                  )}
                </a>
              ))}
            </div>
          </div>
        )}

        {tab === 'credits' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between py-3 border-b border-line">
              <span className="text-muted">Solde actuel</span>
              <span className="text-2xl font-bold text-blue">{user?.creditsBalance ?? 0}</span>
            </div>
            <p className="text-sm text-muted">
              Achetez un pack de crédits complémentaire sans changer de plan. Un lien de
              paiement s’ouvre dans un nouvel onglet ; les crédits sont ajoutés dès que le
              paiement est confirmé.
            </p>
            {user?.plan === 'essai' && (
              <p className="text-sm text-amber">
                L’achat de crédits est réservé aux abonnés. Passez à un abonnement pour en
                acheter.
              </p>
            )}
            {creditsErr && (
              <div className="text-sm text-red bg-redSoft rounded-lg px-4 py-2.5">{creditsErr}</div>
            )}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {packs.map((p) => (
                <button
                  key={p.id}
                  onClick={() => buyPack(p.id)}
                  disabled={buyingPack !== null || user?.plan === 'essai'}
                  className="p-4 rounded-xl border border-line hover:border-blue text-center transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <div className="font-bold text-lg">{p.credits}</div>
                  <div className="text-xs text-muted">
                    {buyingPack === p.id ? 'Ouverture…' : 'crédits'}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* PAIEMENTS — sans exposer le prestataire interne NexAI */}
        {tab === 'paiements' && (
          <div className="space-y-6">
            <p className="text-sm text-muted leading-relaxed">
              Choisissez comment vous encaissez les paiements sur les sites créés avec NexAI.
              Ce réglage s’applique par défaut au lancement de vos sites.
            </p>

            {/* Option 1 — lien personnel */}
            <button
              type="button"
              onClick={() => setPayMode('lien_personnel')}
              className={`w-full text-left p-5 rounded-xl border transition-all ${
                payMode === 'lien_personnel' ? 'border-blue ring-1 ring-blue bg-blueSoft/30' : 'border-line hover:border-lineLt'
              }`}
            >
              <div className="font-semibold mb-1">Mon propre lien de paiement</div>
              <p className="text-sm text-muted leading-relaxed">
                Vous redirigez vos clients vers <strong className="text-white">votre page de paiement</strong>
                (lien Chariow recommandé). NexAI n’encaisse pas : l’argent va directement chez vous.
              </p>
              <p className="text-xs text-blue mt-2">
                💡 Conseil : Chariow est l’option la plus simple et la plus utilisée avec NexAI (Mobile Money, etc.).
              </p>
            </button>

            {payMode === 'lien_personnel' && (
              <div className="pl-1 space-y-4 animate-fade-in">
                <div>
                  <label className="text-sm text-muted block mb-1.5">Prestataire de paiement</label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {(
                      [
                        { id: 'chariow', label: 'Chariow', help: 'Le plus simple, Mobile Money inclus.' },
                        { id: 'maketou', label: 'Maketou', help: 'Simple, populaire localement.' },
                        { id: 'stripe', label: 'Stripe', help: 'Configuration technique côté client.' },
                        { id: 'autre', label: 'Autre', help: 'Tout autre lien de paiement.' },
                      ] as { id: PaymentProviderUi; label: string; help: string }[]
                    ).map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => setPersonalProvider(p.id)}
                        className={`text-left p-3 rounded-lg border transition-colors ${
                          personalProvider === p.id
                            ? 'border-blue ring-1 ring-blue bg-blueSoft/30'
                            : 'border-line hover:border-lineLt'
                        }`}
                      >
                        <div className="font-semibold text-sm">{p.label}</div>
                        <div className="text-[11px] text-muted mt-0.5 leading-snug">{p.help}</div>
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-sm text-muted block mb-1.5">Lien de votre page de paiement</label>
                  <input
                    className="input"
                    type="url"
                    placeholder={
                      personalProvider === 'stripe'
                        ? 'https://buy.stripe.com/votre-lien'
                        : personalProvider === 'maketou'
                        ? 'https://maketou.co/votre-page'
                        : 'https://pay.chariow.com/votre-page'
                    }
                    value={personalLink}
                    onChange={(e) => setPersonalLink(e.target.value)}
                  />
                  <p className="text-xs text-muted mt-1.5">
                    Collez l’URL de votre page de paiement {personalProvider ? `(${personalProvider})` : ''}.
                  </p>
                </div>
              </div>
            )}

            {/* Option 2 — via NexAI */}
            <button
              type="button"
              onClick={() => setPayMode('nexai')}
              className={`w-full text-left p-5 rounded-xl border transition-all ${
                payMode === 'nexai' ? 'border-blue ring-1 ring-blue bg-blueSoft/30' : 'border-line hover:border-lineLt'
              }`}
            >
              <div className="font-semibold mb-1">Recevoir via mon compte NexAI</div>
              <p className="text-sm text-muted leading-relaxed">
                Les paiements sont encaissés via NexAI. Vous recevez un <strong className="text-white">reversement</strong> des fonds validés.
              </p>
              <p className="text-xs text-muted mt-2">
                Options dispo : <strong className="text-white">Mobile Money</strong> · <strong className="text-white">adresse crypto</strong>.
                NexAI vous reverse vos fonds validés <strong className="text-white">tous les 3 jours</strong>.
              </p>
              <p className="text-xs text-muted mt-1">
                Idéal si vous n’avez pas encore de page de paiement personnelle.
              </p>
            </button>

            {payMode === 'nexai' && (
              <div className="pl-1 space-y-4 animate-fade-in">
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setRevType('mobile_money')}
                    className={`flex-1 py-2 rounded-lg text-sm border ${
                      revType === 'mobile_money' ? 'border-blue bg-blueSoft text-blue' : 'border-line'
                    }`}
                  >
                    Mobile Money
                  </button>
                  <button
                    type="button"
                    onClick={() => setRevType('crypto')}
                    className={`flex-1 py-2 rounded-lg text-sm border ${
                      revType === 'crypto' ? 'border-blue bg-blueSoft text-blue' : 'border-line'
                    }`}
                  >
                    Crypto
                  </button>
                </div>

                {revType === 'mobile_money' && (
                  <>
                    <div>
                      <label className="text-sm text-muted block mb-1.5">Opérateur</label>
                      <select
                        className="input"
                        value={operateur}
                        onChange={(e) => setOperateur(e.target.value)}
                      >
                        <option>Wave</option>
                        <option>Orange Money</option>
                        <option>MTN MoMo</option>
                        <option>Moov Money</option>
                        <option>Autre</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-sm text-muted block mb-1.5">Numéro de reversement</label>
                      <input
                        className="input"
                        placeholder="Ex. 07 XX XX XX XX"
                        value={numero}
                        onChange={(e) => setNumero(e.target.value)}
                      />
                    </div>
                  </>
                )}

                {revType === 'crypto' && (
                  <div>
                    <label className="text-sm text-muted block mb-1.5">Adresse crypto</label>
                    <input
                      className="input"
                      placeholder="Adresse de réception"
                      value={cryptoAddress}
                      onChange={(e) => setCryptoAddress(e.target.value)}
                    />
                  </div>
                )}
              </div>
            )}

            {payErr && (
              <div className="text-sm text-red-400 bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2">
                {payErr}
              </div>
            )}
            {payMsg && (
              <div className="text-sm text-mint bg-mintSoft border border-mint/30 rounded-lg px-3 py-2">
                {payMsg}
              </div>
            )}

            <button
              type="button"
              disabled={paySaving}
              onClick={savePayments}
              className="btn-primary rounded-lg px-6 py-2.5 text-sm font-semibold disabled:opacity-50"
            >
              {paySaving ? 'Enregistrement…' : 'Enregistrer les réglages'}
            </button>
          </div>
        )}
      </div>
    </DashboardShell>
  );
}
