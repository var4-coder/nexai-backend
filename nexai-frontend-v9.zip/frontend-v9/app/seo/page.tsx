'use client';

import DashboardShell from '@/components/DashboardShell';
import { useAuth } from '@/lib/auth-context';
import { planHasAnalytics } from '@/lib/plans';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

export default function SeoPage() {
  const { user } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (user && !planHasAnalytics(user.plan)) router.replace('/dashboard');
  }, [user, router]);

  return (
    <DashboardShell>
      <div className="p-8 max-w-5xl">
        <h1 className="text-2xl font-display font-bold mb-1">SEO</h1>
        <p className="text-muted text-sm mb-8">
          Recommandations et scores SEO de vos sites (Agence & Pro Max)
        </p>

        <div className="card p-10 text-center">
          <p className="text-muted mb-2">Analyse SEO automatisée</p>
          <p className="text-sm text-muted max-w-md mx-auto">
            Bientôt : score SEO par site, suggestions de titres, meta descriptions et structure.
            Les données de base (titres, meta) sont déjà intégrées à la génération IA.
          </p>
        </div>
      </div>
    </DashboardShell>
  );
}
