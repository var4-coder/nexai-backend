'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import DashboardShell from '@/components/DashboardShell';
import UpsellPassage from '@/components/UpsellPassage';
import { useAuth } from '@/lib/auth-context';
import { sitesApi, academyApi, Site } from '@/lib/api';
import { PLANS, planHasAgencyAccess, isFormationOnlyPlan } from '@/lib/plans';
import { getNicheLabel } from '@/lib/niches';

function statusBadge(status: string) {
  if (status === 'launched') return <span className="badge-online"><span className="w-1.5 h-1.5 rounded-full bg-mint" /> En ligne</span>;
  if (status === 'ready' || status === 'generating') return <span className="badge-draft"><span className="w-1.5 h-1.5 rounded-full bg-amber" /> En préparation</span>;
  if (status === 'failed' || status === 'offline') return <span className="badge-offline"><span className="w-1.5 h-1.5 rounded-full bg-red" /> Hors ligne</span>;
  return <span className="badge bg-white/10 text-muted"><span className="w-1.5 h-1.5 rounded-full bg-muted" /> Brouillon</span>;
}

/**
 * Tableau de bord Starter — compte 100% Académie (formation en ligne).
 * Pas de widgets "sites" (hors sujet pour ce marché) : on met en avant
 * l'Académie, et UN unique point de passerelle discret vers Créateur /
 * Agence-Pro Max (voir UpsellPassage) plutôt que des modules verrouillés.
 */
function StarterDashboard({ userName }: { userName?: string }) {
  const [formationsCount, setFormationsCount] = useState<number | null>(null);

  useEffect(() => {
    academyApi
      .list()
      .then((r) => {
        const ids = new Set(r.contents.map((c) => c.formationId || c.category || 'general'));
        setFormationsCount(ids.size);
      })
      .catch(() => setFormationsCount(null));
  }, []);

  return (
    <div className="p-8 max-w-6xl">
      <div className="flex items-start justify-between mb-10 flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-display font-bold mb-1">
            Bonjour{userName ? `, ${userName.split(' ')[0]}` : ''} 👋
          </h1>
          <p className="text-muted text-sm">
            Plan <span className="text-white font-medium">Starter</span>
            {' · '}
            <span className="text-blue">Accès complet à l’Académie</span>
          </p>
        </div>
        <Link href="/academy" className="btn-primary rounded-lg px-5 py-2.5 text-sm font-semibold">
          Continuer ma formation
        </Link>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-10">
        <div className="card p-5">
          <div className="text-2xl font-bold">{formationsCount ?? '—'}</div>
          <div className="text-sm text-muted mt-1">Formations disponibles</div>
        </div>
        <div className="card p-5">
          <div className="text-2xl font-bold">PDF & vidéos</div>
          <div className="text-sm text-muted mt-1">Documents approfondis, livres, cours</div>
        </div>
      </div>

      <div className="mb-10">
        <UpsellPassage />
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const { user } = useAuth();
  const [sites, setSites] = useState<Site[]>([]);
  const isFormationOnly = isFormationOnlyPlan(user?.plan);

  useEffect(() => {
    if (isFormationOnly) return;
    sitesApi.list().then((r) => setSites(r.sites)).catch(() => setSites([]));
  }, [isFormationOnly]);

  if (isFormationOnly) {
    return (
      <DashboardShell>
        <StarterDashboard userName={user?.name} />
      </DashboardShell>
    );
  }

  const planLabel = PLANS.find((p) => p.id === user?.plan)?.label ?? user?.plan;
  const onlineCount = sites.filter((s) => s.status === 'launched').length;

  return (
    <DashboardShell>
      <div className="p-8 max-w-6xl">
        <div className="flex items-start justify-between mb-10">
          <div>
            <h1 className="text-2xl font-display font-bold mb-1">
              Bonjour{user?.name ? `, ${user.name.split(' ')[0]}` : ''} 👋
            </h1>
            <p className="text-muted text-sm">
              Plan <span className="text-white font-medium">{planLabel}</span>
              {' · '}
              <span className="text-blue">{user?.creditsBalance ?? 0} crédits</span>
            </p>
          </div>
          <div className="flex gap-3">
            {planHasAgencyAccess(user?.plan) && (
              <Link href="/agence" className="btn-secondary rounded-lg px-4 py-2.5 text-sm">
                Espace Agence
              </Link>
            )}
            <Link href="/assistant" className="btn-primary rounded-lg px-5 py-2.5 text-sm">
              + Créer mon site avec l’IA
            </Link>
          </div>
        </div>

        {/* Stats rapides */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          <div className="card p-5">
            <div className="text-2xl font-bold">{sites.length}</div>
            <div className="text-sm text-muted mt-1">Sites créés</div>
          </div>
          <div className="card p-5">
            <div className="text-2xl font-bold text-mint">{onlineCount}</div>
            <div className="text-sm text-muted mt-1">En ligne</div>
          </div>
          <div className="card p-5">
            <div className="text-2xl font-bold text-blue">{user?.creditsBalance ?? 0}</div>
            <div className="text-sm text-muted mt-1">Crédits restants</div>
          </div>
          <div className="card p-5">
            <div className="text-2xl font-bold">{planLabel}</div>
            <div className="text-sm text-muted mt-1">Abonnement</div>
          </div>
        </div>

        {/* Derniers sites */}
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold">Vos sites récents</h2>
          <Link href="/sites" className="text-sm text-blue hover:underline">
            Voir tous →
          </Link>
        </div>

        {sites.length === 0 ? (
          <div className="card p-12 text-center">
            <p className="text-muted mb-4">Aucun site pour le moment.</p>
            <Link href="/assistant" className="btn-primary rounded-lg px-6 py-2.5 text-sm inline-block">
              Créer mon premier site
            </Link>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {sites.slice(0, 6).map((site) => (
              <Link
                key={site.id}
                href={`/sites/${site.id}`}
                className="card p-5 hover:border-lineLt transition-colors group"
              >
                <div className="flex items-start justify-between mb-3">
                  {statusBadge(site.status)}
                </div>
                <h3 className="font-semibold group-hover:text-blue transition-colors">
                  {site.name || getNicheLabel(site.niche)}
                </h3>
                <p className="text-sm text-muted mt-1">{getNicheLabel(site.niche)}</p>
                {site.domainName && (
                  <p className="text-xs text-blue mt-2 truncate">{site.domainName}</p>
                )}
              </Link>
            ))}
          </div>
        )}
      </div>
    </DashboardShell>
  );
}
