'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import DashboardShell from '@/components/DashboardShell';
import { useAuth } from '@/lib/auth-context';
import { domainsApi, ApiError } from '@/lib/api';
import { CREDIT_COSTS } from '@/lib/plans';

type DomainOption = 'sous_domaine' | 'godaddy' | 'byod';

type Quota = {
  plan: string;
  included: number;
  used: number;
  remaining: number;
};

export default function DomainesPage() {
  const { user } = useAuth();
  const [option, setOption] = useState<DomainOption>('sous_domaine');
  const [name, setName] = useState('');
  const [customDomain, setCustomDomain] = useState('');
  const [checkResult, setCheckResult] = useState<{
    domain?: string;
    available?: boolean;
    priceCredits?: number;
    variants?: { domain: string; available: boolean; priceCredits: number }[];
  } | null>(null);
  const [checkError, setCheckError] = useState('');
  const [loading, setLoading] = useState(false);
  const [quota, setQuota] = useState<Quota | null>(null);

  useEffect(() => {
    domainsApi.quota().then(setQuota).catch(() => {});
  }, []);

  // Le sous-domaine NexAI n'a pas besoin d'une vérification GoDaddy : il est
  // toujours disponible, seul le format du nom compte.
  const isSubdomain = option === 'sous_domaine';

  async function checkDomain() {
    const base = isSubdomain ? name.trim() : customDomain.trim();
    if (!base) return;
    setLoading(true);
    setCheckError('');
    setCheckResult(null);
    try {
      if (isSubdomain) {
        setCheckResult({
          domain: `${base}.nexai.fr`,
          available: true,
          priceCredits: 0,
        });
        return;
      }

      const [check, variantsRes] = await Promise.all([
        domainsApi.check(base),
        domainsApi.variants(base),
      ]);
      setCheckResult({
        domain: check.domain,
        available: check.available,
        priceCredits: check.priceCredits ?? CREDIT_COSTS.DOMAIN_EXTRA,
        variants: variantsRes.variants,
      });
    } catch (e) {
      const message =
        e instanceof ApiError ? e.message : (e as Error).message || 'Vérification impossible.';
      setCheckError(message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <DashboardShell>
      <div className="p-8 max-w-3xl">
        <h1 className="text-2xl font-display font-bold mb-1">Domaines</h1>
        <p className="text-muted text-sm mb-8">
          Configurez le nom de domaine de vos sites. Le réglage choisi sera proposé par défaut au lancement.
        </p>

        {quota && (
          <div className="card p-4 mb-8 flex items-center justify-between text-sm">
            <span className="text-muted">
              Quota domaines : {quota.used}/{quota.included} utilisés
            </span>
            <span className="text-blue">{user?.creditsBalance ?? 0} crédits</span>
          </div>
        )}

        {/* 3 options avec descriptifs clairs */}
        <div className="space-y-3 mb-8">
          {[
            {
              id: 'sous_domaine' as const,
              title: 'Sous-domaine NexAI',
              desc: 'Gratuit · Adresse du type mon-studio.nexai.fr',
              detail:
                'Idéal pour démarrer tout de suite, sans rien acheter. Votre site est accessible immédiatement. Vous pourrez passer à un nom personnalisé plus tard.',
            },
            {
              id: 'godaddy' as const,
              title: 'Acheter ou obtenir un nom de domaine',
              desc: 'Adresse pro (ex. monstudio.fr) · Via notre partenaire',
              detail:
                'Un nom personnalisé renforce votre image professionnelle. S’il reste dans votre quota d’abonnement, c’est gratuit. Sinon le coût en crédits s’affiche avant validation — vous ne payez que si vous confirmez.',
            },
            {
              id: 'byod' as const,
              title: 'J’ai déjà mon propre domaine',
              desc: 'Vous possédez déjà un nom de domaine ailleurs',
              detail:
                'Indiquez simplement l’adresse que vous avez déjà (ex. monentreprise.com). Aucun crédit n’est débité. Vous configurerez la redirection au moment du lancement.',
            },
          ].map((opt) => (
            <button
              key={opt.id}
              onClick={() => {
                setOption(opt.id);
                setCheckResult(null);
                setCheckError('');
              }}
              className={`w-full card p-5 text-left transition-all ${
                option === opt.id ? 'ring-1 ring-blue border-blue' : 'hover:border-lineLt'
              }`}
            >
              <div className="flex items-start gap-3">
                <div
                  className={`w-4 h-4 mt-1 rounded-full border-2 flex items-center justify-center shrink-0 ${
                    option === opt.id ? 'border-blue' : 'border-line'
                  }`}
                >
                  {option === opt.id && <div className="w-2 h-2 rounded-full bg-blue" />}
                </div>
                <div>
                  <div className="font-semibold">{opt.title}</div>
                  <div className="text-sm text-muted mt-0.5">{opt.desc}</div>
                  {option === opt.id && (
                    <p className="text-xs text-muted mt-2 leading-relaxed border-t border-line pt-2">
                      {opt.detail}
                    </p>
                  )}
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Formulaire selon option */}
        <div className="card p-6 space-y-4">
          {option === 'sous_domaine' && (
            <>
              <label className="text-sm font-medium">Choisissez votre sous-domaine</label>
              <div className="flex items-center gap-2">
                <input
                  className="input flex-1"
                  placeholder="mon-studio"
                  value={name}
                  onChange={(e) => setName(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ''))}
                />
                <span className="text-muted text-sm">.nexai.fr</span>
              </div>
            </>
          )}

          {(option === 'godaddy' || option === 'byod') && (
            <>
              <label className="text-sm font-medium">
                {option === 'byod' ? 'Votre nom de domaine' : 'Rechercher un nom de domaine'}
              </label>
              <input
                className="input"
                placeholder="exemple.fr"
                value={customDomain}
                onChange={(e) => setCustomDomain(e.target.value.toLowerCase())}
              />
            </>
          )}

          {checkError && (
            <div className="text-sm text-red bg-redSoft rounded-lg px-4 py-2.5">{checkError}</div>
          )}

          <button
            onClick={checkDomain}
            disabled={loading || (!name && !customDomain)}
            className="btn-primary rounded-lg px-6 py-2.5 text-sm font-semibold disabled:opacity-40"
          >
            {loading ? 'Vérification…' : 'Vérifier la disponibilité'}
          </button>
        </div>

        {/* Résultat + variantes */}
        {checkResult && (
          <div className="mt-6 card p-6 space-y-4 animate-fade-in">
            <div className="flex items-center justify-between">
              <span className="font-medium">
                {checkResult.domain && <span className="text-white mr-2">{checkResult.domain}</span>}
                {checkResult.available ? (
                  <span className="text-mint">Disponible</span>
                ) : (
                  <span className="text-red">Indisponible</span>
                )}
              </span>
              {checkResult.priceCredits !== undefined && (
                <span className="text-sm text-muted">
                  Coût : <strong className="text-white">{checkResult.priceCredits} crédits</strong>
                </span>
              )}
            </div>

            {!!checkResult.priceCredits && checkResult.priceCredits > (user?.creditsBalance ?? 0) && (
              <p className="text-sm text-amber">
                Solde insuffisant. Choisissez un autre nom ou achetez des crédits.
              </p>
            )}

            {checkResult.variants && checkResult.variants.length > 0 && (
              <div>
                <p className="text-sm text-muted mb-3">
                  Variantes suggérées — choisissez avant de confirmer :
                </p>
                <div className="space-y-2">
                  {checkResult.variants.map((v) => (
                    <button
                      key={v.domain}
                      onClick={() => setCustomDomain(v.domain)}
                      className="w-full flex items-center justify-between px-4 py-2.5 rounded-lg bg-panel border border-line hover:border-blue text-sm transition-colors"
                    >
                      <span>{v.domain}</span>
                      <span className="text-muted">
                        {v.available ? (
                          <span className="text-mint">{v.priceCredits} crédits</span>
                        ) : (
                          <span className="text-red">Indisponible</span>
                        )}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            <Link
              href="/sites"
              className={`btn-primary rounded-lg px-6 py-2.5 text-sm font-semibold w-full block text-center ${
                !checkResult.available || (checkResult.priceCredits ?? 0) > (user?.creditsBalance ?? 0)
                  ? 'pointer-events-none opacity-40'
                  : ''
              }`}
            >
              Utiliser ce domaine pour un de mes sites
            </Link>
            <p className="text-xs text-muted text-center">
              La configuration se termine dans les Paramètres du site choisi. Les crédits ne sont
              prélevés qu’au moment du lancement.
            </p>
          </div>
        )}
      </div>
    </DashboardShell>
  );
}
