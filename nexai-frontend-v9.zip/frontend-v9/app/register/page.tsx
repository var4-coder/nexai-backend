'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { authApi } from '@/lib/api';

export default function RegisterPage() {
  const router = useRouter();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (password.length < 8) {
      setError('Le mot de passe doit contenir au moins 8 caractères');
      return;
    }
    setLoading(true);
    try {
      await authApi.register(email, password, name);
      router.push(`/register/verifier?email=${encodeURIComponent(email)}`);
    } catch (err: any) {
      setError(err.message || 'Erreur lors de l’inscription');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <img src="/brand/nexai-logo.svg" alt="NexAI" className="h-8 w-auto" />
          </Link>
          <h1 className="text-2xl font-display font-bold">Créer un compte</h1>
          <p className="text-muted text-sm mt-1">
            12 crédits offerts · Essai 7 jours · Sans carte bancaire
          </p>
        </div>

        <form onSubmit={handleSubmit} className="card p-8 space-y-4">
          {error && (
            <div className="text-sm text-red bg-redSoft rounded-lg px-4 py-2.5">{error}</div>
          )}
          <div>
            <label className="text-sm text-muted mb-1.5 block">Nom (optionnel)</label>
            <input
              type="text"
              className="input"
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoComplete="name"
            />
          </div>
          <div>
            <label className="text-sm text-muted mb-1.5 block">Email</label>
            <input
              type="email"
              className="input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoComplete="email"
            />
          </div>
          <div>
            <label className="text-sm text-muted mb-1.5 block">Mot de passe</label>
            <input
              type="password"
              className="input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={8}
              autoComplete="new-password"
            />
            <p className="text-xs text-muted mt-1">8 caractères minimum</p>
          </div>
          <button
            type="submit"
            disabled={loading}
            className="btn-primary w-full rounded-lg py-3 text-sm font-semibold"
          >
            {loading ? 'Création…' : 'Créer mon compte'}
          </button>
        </form>

        <p className="text-center text-sm text-muted mt-6">
          Déjà un compte ?{' '}
          <Link href="/login" className="text-blue hover:underline">
            Se connecter
          </Link>
        </p>
      </div>
    </div>
  );
}
