'use client';

import { useState, useEffect, Suspense } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { authApi } from '@/lib/api';
import { useAuth } from '@/lib/auth-context';

function VerifierForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const email = searchParams.get('email') || '';
  const { setUser, refresh } = useAuth();
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [resending, setResending] = useState(false);
  const [resendMessage, setResendMessage] = useState('');
  const [cooldown, setCooldown] = useState(0);

  useEffect(() => {
    if (cooldown <= 0) return;
    const t = setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [cooldown]);

  async function handleResend() {
    if (!email || cooldown > 0) return;
    setResending(true);
    setResendMessage('');
    setError('');
    try {
      await authApi.resendCode(email);
      setResendMessage('Un nouveau code a été envoyé.');
      setCooldown(30);
    } catch (err: any) {
      setError(err.message || "Impossible de renvoyer le code pour l'instant.");
    } finally {
      setResending(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const { user } = await authApi.verify(email, code);
      setUser(user);
      await refresh();
      router.push('/dashboard');
    } catch (err: any) {
      setError(err.message || 'Code invalide');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <img src="/brand/nexai-logo.svg" alt="NexAI" className="h-8 w-auto" />
          </Link>
          <h1 className="text-2xl font-display font-bold">Vérifiez votre email</h1>
          <p className="text-muted text-sm mt-1">
            Un code à 6 chiffres a été envoyé à <strong className="text-white">{email}</strong>
          </p>
        </div>

        <form onSubmit={handleSubmit} className="card p-8 space-y-4">
          {error && (
            <div className="text-sm text-red bg-redSoft rounded-lg px-4 py-2.5">{error}</div>
          )}
          <div>
            <label className="text-sm text-muted mb-1.5 block">Code de vérification</label>
            <input
              type="text"
              className="input text-center tracking-[0.3em] text-lg"
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
              required
              maxLength={6}
              placeholder="000000"
            />
          </div>
          <button
            type="submit"
            disabled={loading || code.length < 6}
            className="btn-primary w-full rounded-lg py-3 text-sm font-semibold disabled:opacity-40"
          >
            {loading ? 'Vérification…' : 'Valider'}
          </button>
        </form>

        <div className="text-center mt-5 text-sm text-muted">
          {resendMessage && <p className="text-mint mb-2">{resendMessage}</p>}
          Vous n’avez rien reçu ?{' '}
          <button
            type="button"
            onClick={handleResend}
            disabled={resending || cooldown > 0}
            className="text-blue hover:underline disabled:opacity-40 disabled:no-underline"
          >
            {cooldown > 0
              ? `Renvoyer le code (${cooldown}s)`
              : resending
              ? 'Envoi…'
              : 'Renvoyer le code'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function VerifierPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center">Chargement…</div>}>
      <VerifierForm />
    </Suspense>
  );
}
