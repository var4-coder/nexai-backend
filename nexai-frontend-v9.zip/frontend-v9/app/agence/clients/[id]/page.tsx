'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import DashboardShell from '@/components/DashboardShell';
import { agencyApi, AgencyClient, Site, ApiError } from '@/lib/api';
import { getNicheLabel } from '@/lib/niches';

function statusBadge(status: string) {
  if (status === 'launched')
    return (
      <span className="badge-online">
        <span className="w-1.5 h-1.5 rounded-full bg-mint" /> En ligne
      </span>
    );
  if (status === 'ready' || status === 'generating')
    return (
      <span className="badge-draft">
        <span className="w-1.5 h-1.5 rounded-full bg-amber" /> En préparation
      </span>
    );
  if (status === 'failed' || status === 'offline')
    return (
      <span className="badge-offline">
        <span className="w-1.5 h-1.5 rounded-full bg-red" /> Hors ligne
      </span>
    );
  return (
    <span className="badge bg-white/10 text-muted">
      <span className="w-1.5 h-1.5 rounded-full bg-muted" /> Brouillon
    </span>
  );
}

export default function AgenceClientDetailPage() {
  const params = useParams<{ id: string }>();
  const id = params.id;

  const [client, setClient] = useState<AgencyClient | null>(null);
  const [sites, setSites] = useState<Site[]>([]);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    agencyApi
      .getClient(id)
      .then((r) => {
        setClient(r.client);
        setSites(r.sites);
      })
      .catch((err) => {
        if (err instanceof ApiError && err.status === 404) setNotFound(true);
        else setError((err as Error).message || 'Erreur de chargement du client.');
      })
      .finally(() => setLoading(false));
  }, [id]);

  return (
    <DashboardShell>
      <div className="p-8 max-w-5xl">
        <Link
          href="/agence"
          className="text-sm text-muted hover:text-white mb-6 flex items-center gap-1"
        >
          ← Retour à l’Espace Agence
        </Link>

        {loading ? (
          <div className="flex justify-center py-20">
            <div className="w-8 h-8 border-2 border-blue border-t-transparent rounded-full animate-spin" />
          </div>
        ) : notFound || !client ? (
          <div className="card p-16 text-center">
            <p className="text-muted mb-6">Ce client est introuvable.</p>
            <Link href="/agence" className="btn-primary rounded-lg px-6 py-2.5 text-sm inline-block">
              Retour à l’Espace Agence
            </Link>
          </div>
        ) : (
          <>
            <div className="flex items-start justify-between mb-8">
              <div>
                <h1 className="text-2xl font-display font-bold">{client.name}</h1>
                <p className="text-muted text-sm mt-1">
                  {client.email || 'Aucun email renseigné'}
                  {client.phone && <> · {client.phone}</>}
                </p>
              </div>
              {client.active ? (
                <span className="badge-online">Actif</span>
              ) : (
                <span className="badge bg-white/10 text-muted">Inactif</span>
              )}
            </div>

            {error && (
              <div className="text-sm text-red bg-redSoft rounded-lg px-4 py-2.5 mb-6">{error}</div>
            )}

            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Sites de ce client</h2>
              <span className="text-sm text-muted">{sites.length} site(s)</span>
            </div>

            {sites.length === 0 ? (
              <div className="card p-12 text-center text-muted">
                Ce client n’a pas encore de site. Créez-en un depuis « IA & Création » en
                rattachant ce client.
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {sites.map((site) => (
                  <Link
                    key={site.id}
                    href={`/sites/${site.id}`}
                    className="card p-5 hover:border-lineLt transition-colors group"
                  >
                    <div className="flex items-start justify-between mb-3">{statusBadge(site.status)}</div>
                    <h3 className="font-semibold group-hover:text-blue transition-colors">
                      {site.name || getNicheLabel(site.niche)}
                    </h3>
                    <p className="text-sm text-muted mt-1">{getNicheLabel(site.niche)}</p>
                    {site.domainName && (
                      <p className="text-xs text-blue mt-2 truncate">{site.domainName}</p>
                    )}
                  </Link>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </DashboardShell>
  );
}
