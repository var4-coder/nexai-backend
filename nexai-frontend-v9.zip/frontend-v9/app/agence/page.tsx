'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import DashboardShell from '@/components/DashboardShell';
import { useAuth } from '@/lib/auth-context';
import { agencyApi, AgencyClient, ApiError } from '@/lib/api';
import { planHasAgencyAccess } from '@/lib/plans';
import { useRouter } from 'next/navigation';

export default function AgencePage() {
  const { user } = useAuth();
  const router = useRouter();
  const [clients, setClients] = useState<AgencyClient[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [creating, setCreating] = useState(false);
  const [formError, setFormError] = useState('');

  useEffect(() => {
    if (user && !planHasAgencyAccess(user.plan)) {
      router.replace('/dashboard');
    }
  }, [user, router]);

  function loadClients() {
    setLoading(true);
    setLoadError('');
    agencyApi
      .clients()
      .then((r) => setClients(r.clients))
      .catch((err) => setLoadError((err as Error).message || 'Impossible de charger vos clients.'))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    loadClients();
  }, []);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setCreating(true);
    setFormError('');
    try {
      const { client } = await agencyApi.createClient({ name, email: email || undefined });
      setClients((c) => [client, ...c]);
      setShowForm(false);
      setName('');
      setEmail('');
    } catch (err) {
      const message =
        err instanceof ApiError ? err.message : (err as Error).message || 'Création impossible.';
      setFormError(message);
    } finally {
      setCreating(false);
    }
  }

  return (
    <DashboardShell>
      <div className="p-8 max-w-5xl">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-display font-bold">Espace Agence</h1>
            <p className="text-muted text-sm mt-1">
              Gérez vos clients et leurs sites au même endroit
            </p>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="btn-primary rounded-lg px-5 py-2.5 text-sm font-semibold"
          >
            + Nouveau client
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <div className="card p-5">
            <div className="text-2xl font-bold">{clients.length}</div>
            <div className="text-sm text-muted mt-1">Clients</div>
          </div>
          <div className="card p-5">
            <div className="text-2xl font-bold text-mint">
              {clients.reduce((s, c) => s + c.sitesCount, 0)}
            </div>
            <div className="text-sm text-muted mt-1">Sites créés</div>
          </div>
          <div className="card p-5">
            <div className="text-2xl font-bold">
              {clients.filter((c) => c.active).length}
            </div>
            <div className="text-sm text-muted mt-1">Clients actifs</div>
          </div>
        </div>

        {showForm && (
          <form onSubmit={handleCreate} className="card p-6 mb-6 space-y-4 animate-fade-in">
            <h3 className="font-semibold">Nouveau client</h3>
            {formError && (
              <div className="text-sm text-red bg-redSoft rounded-lg px-4 py-2.5">{formError}</div>
            )}
            <input
              className="input"
              placeholder="Nom du client"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
            <input
              className="input"
              placeholder="Email (optionnel)"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <div className="flex gap-3">
              <button
                type="submit"
                disabled={creating}
                className="btn-primary rounded-lg px-5 py-2 text-sm font-semibold disabled:opacity-50"
              >
                {creating ? 'Création…' : 'Créer'}
              </button>
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="btn-secondary rounded-lg px-5 py-2 text-sm"
              >
                Annuler
              </button>
            </div>
          </form>
        )}

        {loading ? (
          <div className="flex justify-center py-16">
            <div className="w-8 h-8 border-2 border-blue border-t-transparent rounded-full animate-spin" />
          </div>
        ) : loadError ? (
          <div className="card p-10 text-center">
            <p className="text-red mb-4">{loadError}</p>
            <button onClick={loadClients} className="btn-secondary rounded-lg px-5 py-2 text-sm inline-block">
              Réessayer
            </button>
          </div>
        ) : clients.length === 0 ? (
          <div className="card p-16 text-center text-muted">
            Aucun client pour le moment. Créez votre premier client pour commencer.
          </div>
        ) : (
          <div className="card overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-line text-muted text-left">
                  <th className="px-5 py-3 font-medium">Client</th>
                  <th className="px-5 py-3 font-medium">Sites</th>
                  <th className="px-5 py-3 font-medium">Statut</th>
                  <th className="px-5 py-3 font-medium"></th>
                </tr>
              </thead>
              <tbody>
                {clients.map((c) => (
                  <tr key={c.id} className="border-b border-line/50 hover:bg-white/[0.02]">
                    <td className="px-5 py-3">
                      <div className="font-medium">{c.name}</div>
                      {c.email && <div className="text-xs text-muted">{c.email}</div>}
                    </td>
                    <td className="px-5 py-3">{c.sitesCount}</td>
                    <td className="px-5 py-3">
                      {c.active ? (
                        <span className="badge-online">Actif</span>
                      ) : (
                        <span className="badge bg-white/10 text-muted">Inactif</span>
                      )}
                    </td>
                    <td className="px-5 py-3 text-right">
                      <Link
                        href={`/agence/clients/${c.id}`}
                        className="text-blue text-xs hover:underline"
                      >
                        Voir →
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </DashboardShell>
  );
}
