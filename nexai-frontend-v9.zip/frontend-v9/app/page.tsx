/**
 * Fallback — la page d'accueil réelle est public/landing-nexai.html
 * (landing variant B : badge Premium Pro Max + hero object-position 55% 28%).
 * Le middleware réécrit / vers /landing-nexai.html.
 */
import { redirect } from 'next/navigation';

export default function HomePage() {
  redirect('/landing-nexai.html');
}
