'use client';

import { useState, useEffect } from 'react';
import DashboardShell from '@/components/DashboardShell';
import { useAuth } from '@/lib/auth-context';
import { planHasVideoAccess } from '@/lib/plans';
import Link from 'next/link';

type Aspect = '9:16' | '16:9';
type Format = '30s' | '60s' | '120s';
type VideoAdMode = 'voix_off' | 'avatar_standard' | 'avatar_scenario';

/**
 * Les 3 produits vidéo IA, avec des noms et descriptifs pensés pour que le
 * client sache immédiatement lequel correspond à ce qu'il veut, sans avoir à
 * deviner ce que "voix off" ou "avatar standard" signifie.
 */
const MODE_INFO: Record<
  VideoAdMode,
  { title: string; description: string; formats: Format[]; defaultFormat: Format }
> = {
  voix_off: {
    title: 'Publicité IA avec voix',
    description:
      "Montage cinématique en plusieurs plans, avec une narration IA et une musique de fond. Aucun personnage à l'écran — idéal pour mettre en avant votre site, vos produits et votre offre.",
    formats: ['30s', '60s', '120s'],
    defaultFormat: '30s',
  },
  avatar_standard: {
    title: 'Publicité IA avec avatar',
    description:
      "Un présentateur généré par IA parle directement à la caméra pour vendre votre offre. Donne un visage humain à votre marque, en format court.",
    formats: ['30s', '60s'],
    defaultFormat: '30s',
  },
  avatar_scenario: {
    title: 'Mini-Film IA',
    description:
      "Format long (2 minutes) avec avatar sur toute la durée, pour un contenu plus narratif : mini-film de marque, présentation approfondie ou épisode de série à publier sur vos réseaux.",
    formats: ['120s'],
    defaultFormat: '120s',
  },
};

const API_BASE = (process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api/v1').replace(/\/$/, '');

export default function VideoPage() {
  const { user } = useAuth();
  // Accès réel à la génération : Agence + Pro Max (voir lib/plans.ts).
  // Starter / Créateur peuvent ouvrir cette page et explorer l'interface —
  // « on leur montre la sauce » — mais ne peuvent pas lancer de génération.
  const hasVideoAccess = planHasVideoAccess(user?.plan);
  const canPoll = hasVideoAccess;

  const [description, setDescription] = useState('');
  const [siteUrl, setSiteUrl] = useState('');
  const [productImages, setProductImages] = useState<{ url: string; previewName: string }[]>([]);
  const [uploadingProductImage, setUploadingProductImage] = useState(false);
  const [productImageError, setProductImageError] = useState<string | null>(null);
  const [aspect, setAspect] = useState<Aspect>('9:16');
  const [mode, setMode] = useState<VideoAdMode>('voix_off');
  const [format, setFormat] = useState<Format>('30s');
  const [brandName, setBrandName] = useState('');
  const [ctaText, setCtaText] = useState('');
  const [style, setStyle] = useState('Moderne & Dynamique');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [briefWarning, setBriefWarning] = useState<{ feedback: string; missingElements: string[] } | null>(null);
  // Recommandation NON-bloquante renvoyée par le backend (voir
  // enqueueVideoAd) quand le site a plus d'offres distinctes qu'un format
  // court ne peut en évoquer. La génération est déjà lancée à ce stade —
  // c'est juste une suggestion pour la prochaine vidéo, jamais un blocage.
  const [formatRecommendation, setFormatRecommendation] = useState<string | null>(null);
  const [checkingBrief, setCheckingBrief] = useState(false);
  const [jobId, setJobId] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [finalUrl, setFinalUrl] = useState<string | null>(null);
  const [urlValidating, setUrlValidating] = useState(false);
  const [tarifs, setTarifs] = useState<Record<string, { formats: Record<string, number> }> | null>(null);
  // Défaut mineur détecté par le contrôle qualité (voir video-qc.service.ts) —
  // la vidéo EST livrée (finalUrl rempli), mais avec un badge et une offre de
  // relance corrective à prix réduit tant que relaunchOffer.used est faux.
  const [qcDegraded, setQcDegraded] = useState(false);
  const [relaunchOffer, setRelaunchOffer] = useState<{ eligible: boolean; used: boolean; priceCredits: number } | null>(
    null
  );
  const [relaunching, setRelaunching] = useState(false);
  const [relaunchError, setRelaunchError] = useState<string | null>(null);
  // Vidéo d'origine, gardée accessible pendant qu'une relance corrective génère.
  const [previousFinalUrl, setPreviousFinalUrl] = useState<string | null>(null);

  // Grille de prix — chargée une fois pour afficher le coût en crédits en
  // face de chaque choix, sans dupliquer les tarifs en dur côté frontend.
  useEffect(() => {
    fetch(`${API_BASE}/video-ads/tarifs`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => data && setTarifs(data))
      .catch(() => {});
  }, []);

  // Changer de produit vidéo (mode) réajuste automatiquement la durée si le
  // format actuellement sélectionné n'existe pas pour ce mode (ex : passer à
  // "Mini-Film IA" qui n'existe qu'en 2 minutes).
  function handleModeChange(newMode: VideoAdMode) {
    setMode(newMode);
    const allowed = MODE_INFO[newMode].formats;
    if (!allowed.includes(format)) {
      setFormat(MODE_INFO[newMode].defaultFormat);
    }
  }

  function creditCostFor(m: VideoAdMode, f: Format): number | null {
    return tarifs?.[m]?.formats?.[f] ?? null;
  }

  useEffect(() => {
    if (!jobId || !canPoll) return;
    const interval = setInterval(async () => {
      try {
        const res = await fetch(`${API_BASE}/video-ads/${jobId}`, { credentials: 'include' });
        if (!res.ok) return;
        const data = await res.json();
        setStatus(data.status);
        if (data.status === 'generating') {
          const done = (data.scenes || []).filter((s: any) => s.status === 'completed').length;
          const total = (data.scenes || []).length || 1;
          setProgress(Math.round((done / total) * 90));
        }
        if (data.status === 'completed') {
          setProgress(100);
          setFinalUrl(data.finalVideoUrl);
          setQcDegraded(Boolean(data.qcReport?.degraded));
          setRelaunchOffer(data.relaunchOffer || null);
          setLoading(false);
          clearInterval(interval);
        }
        if (data.status === 'failed' || data.status === 'refunded') {
          setError(data.errorMessage || 'Génération échouée — crédits remboursés');
          setLoading(false);
          clearInterval(interval);
        }
      } catch {
        /* ignore poll errors */
      }
    }, 3000);
    return () => clearInterval(interval);
  }, [jobId, canPoll]);

  const MAX_PRODUCT_IMAGES = 6;

  // Upload d'une ou plusieurs photos produit vers Cloudinary (via le backend)
  // — les URLs obtenues sont envoyées au lancement dans
  // brief.clientProductImageUrls (voir product-image-sourcing.service.ts côté
  // backend, qui les utilise en priorité comme référence image-to-image).
  async function handleProductImagesSelected(files: FileList | null) {
    if (!files || files.length === 0) return;
    setProductImageError(null);

    const remaining = MAX_PRODUCT_IMAGES - productImages.length;
    if (remaining <= 0) {
      setProductImageError(`Maximum ${MAX_PRODUCT_IMAGES} photos produit.`);
      return;
    }

    const toUpload = Array.from(files).slice(0, remaining);
    setUploadingProductImage(true);
    try {
      for (const file of toUpload) {
        if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) {
          setProductImageError('Format non supporté (PNG, JPEG ou WEBP uniquement).');
          continue;
        }
        const formData = new FormData();
        formData.append('file', file);
        const res = await fetch(`${API_BASE}/video-ads/photos-produit`, {
          method: 'POST',
          credentials: 'include',
          body: formData,
        });
        const data = await res.json();
        if (!res.ok) {
          setProductImageError(data.message || data.error || `Erreur ${res.status}`);
          continue;
        }
        setProductImages((prev) => [...prev, { url: data.url, previewName: file.name }]);
      }
    } finally {
      setUploadingProductImage(false);
    }
  }

  function removeProductImage(url: string) {
    setProductImages((prev) => prev.filter((img) => img.url !== url));
  }

  async function handleGenerate() {
    if (!hasVideoAccess) {
      setError(
        'La génération vidéo est réservée aux abonnements Créateur, Agence et Pro Max. Passez à l’un de ces plans pour lancer votre première vidéo.'
      );
      return;
    }
    setError(null);
    setBriefWarning(null);
    setFormatRecommendation(null);
    setFinalUrl(null);
    setProgress(0);
    setStatus(null);
    setQcDegraded(false);
    setRelaunchOffer(null);
    setRelaunchError(null);
    setPreviousFinalUrl(null);

    if (!description.trim() && !siteUrl.trim()) {
      setError('Fournissez une description ou une URL de site.');
      return;
    }

    setLoading(true);
    try {
      // Scan qualité du brief AVANT de lancer quoi que ce soit — uniquement
      // quand aucune URL de site n'est fournie (le site apporte déjà tout le
      // contexte nécessaire, voir video-brief-quality.service.ts côté backend).
      if (!siteUrl.trim()) {
        setCheckingBrief(true);
        try {
          const briefRes = await fetch(`${API_BASE}/video-ads/analyser-brief`, {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              description: description.trim(),
              brandName: brandName.trim() || undefined,
              ctaText: ctaText.trim() || undefined,
            }),
          });
          if (briefRes.ok) {
            const analysis = await briefRes.json();
            if (!analysis.complete) {
              setBriefWarning({ feedback: analysis.feedback, missingElements: analysis.missingElements || [] });
              setLoading(false);
              setCheckingBrief(false);
              return;
            }
          }
        } finally {
          setCheckingBrief(false);
        }
      }

      if (siteUrl.trim()) {
        setUrlValidating(true);
      }
      const res = await fetch(`${API_BASE}/video-ads`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode,
          format,
          aspectRatio: aspect,
          brief: {
            description: description.trim() || undefined,
            siteUrl: siteUrl.trim() || undefined,
            style,
            brandName: brandName.trim() || user?.name || undefined,
            ctaText: ctaText.trim() || undefined,
            clientProductImageUrls: productImages.length ? productImages.map((img) => img.url) : undefined,
          },
        }),
      });
      setUrlValidating(false);
      const data = await res.json();
      if (!res.ok) {
        // Le backend renvoie { error: { message, details } } — voir errorHandler.ts.
        const apiError = data?.error;
        const missing: string[] | undefined = apiError?.details?.missingElements;
        if (missing?.length) {
          // Garde-fou serveur déclenché (contournement du scan frontend, ou
          // brief modifié entre le scan et l'envoi) — même traitement visuel.
          setBriefWarning({ feedback: apiError.message, missingElements: missing });
          setLoading(false);
          return;
        }
        throw new Error(apiError?.message || data.message || `Erreur ${res.status}`);
      }
      setJobId(data.videoAdId || data.id);
      setStatus('queued');
      setProgress(5);
      if (data.formatRecommendation) {
        setFormatRecommendation(data.formatRecommendation);
      }
    } catch (err: any) {
      setError(err.message || 'Erreur lors du lancement');
      setLoading(false);
      setUrlValidating(false);
      setCheckingBrief(false);
    }
  }

  /**
   * Relance corrective d'une vidéo livrée avec un défaut mineur (badge
   * "résultat perfectible"). Débite le prix réduit côté backend et bascule
   * le suivi sur la nouvelle vidéo — la vidéo d'origine reste accessible via
   * `previousFinalUrl` pendant que la nouvelle génère.
   */
  async function handleRelaunch() {
    if (!jobId || relaunching) return;
    setRelaunchError(null);
    setRelaunching(true);
    try {
      const res = await fetch(`${API_BASE}/video-ads/${jobId}/relancer`, {
        method: 'POST',
        credentials: 'include',
      });
      const data = await res.json();
      if (!res.ok) {
        const apiError = data?.error;
        throw new Error(apiError?.message || data.message || `Erreur ${res.status}`);
      }
      setPreviousFinalUrl(finalUrl);
      setFinalUrl(null);
      setQcDegraded(false);
      setRelaunchOffer(null);
      setProgress(5);
      setStatus('queued');
      setLoading(true);
      setJobId(data.videoAdId || data.id);
    } catch (err: any) {
      setRelaunchError(err.message || 'Erreur lors de la relance');
    } finally {
      setRelaunching(false);
    }
  }

  return (
    <DashboardShell>
      <div className="min-h-screen bg-bg text-white">
        <div className="border-b border-line px-6 py-4 flex items-center justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-xl font-bold tracking-tight">Créer une vidéo avec l&apos;IA</h1>
            <p className="text-sm text-muted">Décrivez votre vision. L&apos;IA s&apos;occupe du reste.</p>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted">
            <span className="px-2 py-1 rounded bg-panel border border-line">
              {hasVideoAccess
                ? user?.plan === 'pro_max'
                  ? 'Pro Max'
                  : user?.plan === 'agence'
                    ? 'Agence'
                    : 'Créateur'
                : 'Créateur, Agence & Pro Max'}
            </span>
            <span>{user?.creditsBalance ?? 0} crédits</span>
          </div>
        </div>

        {/* Bandeau upsell — Starter / Créateur peuvent explorer l'interface,
            mais pas lancer de génération. On leur montre la valeur sans les
            bloquer à l'entrée : le blocage porte sur l'action, pas sur la vue. */}
        {!hasVideoAccess && (
          <div className="mx-6 mt-6 rounded-xl border border-blue/40 bg-blue/10 px-5 py-4 flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue/20 text-blue flex items-center justify-center text-lg shrink-0">
                🔒
              </div>
              <div>
                <div className="font-semibold text-sm">
                  Vidéo IA générative — disponible à partir du plan Créateur
                </div>
                <p className="text-xs text-muted mt-0.5 leading-relaxed">
                  Vous pouvez explorer l’interface et préparer votre brief librement. Le lancement de
                  la génération est réservé aux abonnements <strong className="text-white">Créateur</strong>,{' '}
                  <strong className="text-white">Agence</strong> et{' '}
                  <strong className="text-white">Pro Max</strong>.
                </p>
              </div>
            </div>
            <Link
              href="/parametres?tab=abonnement"
              className="shrink-0 px-4 py-2 rounded-lg bg-blue text-white text-sm font-semibold hover:opacity-90"
            >
              Passer à Créateur
            </Link>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-0 min-h-[calc(100vh-80px)]">
          {/* Left — form (Maquette B) */}
          <div className="p-6 lg:p-8 border-r border-line space-y-6">
            <div>
              <h2 className="text-sm font-semibold uppercase tracking-wider text-muted mb-4">
                Paramètres de votre vidéo
              </h2>

              <label className="block text-sm font-medium mb-1.5">
                Décrivez votre vidéo / pub
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={4}
                maxLength={1000}
                placeholder="Présentez notre nouvelle solution SaaS pour les équipes marketing : gain de temps, automatisation des rapports… Ton moderne, dynamique et professionnel."
                className="w-full bg-panel border border-line rounded-lg px-3 py-2.5 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue/40"
              />
              <div className="text-xs text-muted mt-1 text-right">{description.length}/1000</div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-1.5">
                URL de votre site <span className="text-muted font-normal">(optionnel — pour personnaliser)</span>
              </label>
              <div className="relative">
                <input
                  type="url"
                  value={siteUrl}
                  onChange={(e) => setSiteUrl(e.target.value)}
                  placeholder="https://www.votre-site.fr"
                  className="w-full bg-panel border border-line rounded-lg px-3 py-2.5 text-sm pl-9 focus:outline-none focus:ring-2 focus:ring-blue/40"
                />
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted text-sm">🔗</span>
              </div>
              <p className="text-xs text-muted mt-1.5">
                L&apos;IA analyse le titre, la description et l&apos;univers de votre site pour personnaliser la vidéo.
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium mb-1.5">
                Vos photos produit <span className="text-muted font-normal">(optionnel — jusqu&apos;à {MAX_PRODUCT_IMAGES})</span>
              </label>
              <p className="text-xs text-muted mb-2 leading-relaxed">
                Ajoutez vos vraies photos produit pour ancrer la vidéo dans la réalité de votre marque.
                L&apos;IA les mélange avec des visuels d&apos;ambiance pour les plans qui n&apos;ont pas besoin
                d&apos;être une photo exacte du produit.
              </p>

              <div className="flex flex-wrap gap-2 mb-2">
                {productImages.map((img) => (
                  <div key={img.url} className="relative group">
                    <img
                      src={img.url}
                      alt={img.previewName}
                      className="w-16 h-16 object-cover rounded-lg border border-line"
                    />
                    <button
                      type="button"
                      onClick={() => removeProductImage(img.url)}
                      className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center opacity-0 group-hover:opacity-100 transition"
                      aria-label={`Retirer ${img.previewName}`}
                    >
                      ✕
                    </button>
                  </div>
                ))}

                {productImages.length < MAX_PRODUCT_IMAGES && (
                  <label
                    className={`w-16 h-16 rounded-lg border border-dashed border-line flex items-center justify-center text-muted cursor-pointer hover:border-blue transition ${
                      uploadingProductImage ? 'opacity-50 pointer-events-none' : ''
                    }`}
                  >
                    {uploadingProductImage ? (
                      <span className="w-4 h-4 border-2 border-muted border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <span className="text-xl leading-none">+</span>
                    )}
                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/webp"
                      multiple
                      className="hidden"
                      onChange={(e) => {
                        handleProductImagesSelected(e.target.files);
                        e.target.value = '';
                      }}
                    />
                  </label>
                )}
              </div>

              {productImageError && (
                <p className="text-xs text-red-400">{productImageError}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Type de vidéo</label>
              <p className="text-xs text-muted mb-3">
                Choisissez le format qui correspond à ce que vous voulez obtenir.
              </p>
              <div className="grid gap-3">
                {(Object.keys(MODE_INFO) as VideoAdMode[]).map((m) => {
                  const info = MODE_INFO[m];
                  const cost = creditCostFor(m, MODE_INFO[m].defaultFormat);
                  return (
                    <button
                      key={m}
                      type="button"
                      onClick={() => handleModeChange(m)}
                      className={`text-left p-3.5 rounded-lg border transition ${
                        mode === m ? 'border-blue bg-blue/10 ring-1 ring-blue' : 'border-line bg-panel hover:border-muted'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm font-semibold">{info.title}</span>
                        <span className="flex items-center gap-2 shrink-0">
                          {cost !== null && (
                            <span className="text-xs text-muted">dès {cost} crédits</span>
                          )}
                          {mode === m && <span className="text-blue">✓</span>}
                        </span>
                      </div>
                      <p className="text-xs text-muted mt-1 leading-relaxed">{info.description}</p>
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Format</label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setAspect('9:16')}
                  className={`flex items-center gap-3 p-3 rounded-lg border transition ${
                    aspect === '9:16'
                      ? 'border-blue bg-blue/10 ring-1 ring-blue'
                      : 'border-line bg-panel hover:border-muted'
                  }`}
                >
                  <div className="w-8 h-12 rounded border-2 border-current flex items-center justify-center text-[10px] font-bold">
                    9:16
                  </div>
                  <div className="text-left">
                    <div className="text-sm font-semibold">9:16</div>
                    <div className="text-xs text-muted">Stories / Réseaux sociaux</div>
                  </div>
                  {aspect === '9:16' && <span className="ml-auto text-blue">✓</span>}
                </button>
                <button
                  type="button"
                  onClick={() => setAspect('16:9')}
                  className={`flex items-center gap-3 p-3 rounded-lg border transition ${
                    aspect === '16:9'
                      ? 'border-blue bg-blue/10 ring-1 ring-blue'
                      : 'border-line bg-panel hover:border-muted'
                  }`}
                >
                  <div className="w-12 h-8 rounded border-2 border-current flex items-center justify-center text-[10px] font-bold">
                    16:9
                  </div>
                  <div className="text-left">
                    <div className="text-sm font-semibold">16:9</div>
                    <div className="text-xs text-muted">YouTube / Web</div>
                  </div>
                  {aspect === '16:9' && <span className="ml-auto text-blue">✓</span>}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1.5">Style visuel</label>
                <select
                  value={style}
                  onChange={(e) => setStyle(e.target.value)}
                  className="w-full bg-panel border border-line rounded-lg px-3 py-2.5 text-sm"
                >
                  <option>Moderne & Dynamique</option>
                  <option>Corporate & Élégant</option>
                  <option>Minimal & Clean</option>
                  <option>Énergique & Coloré</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">Durée</label>
                <select
                  value={format}
                  onChange={(e) => setFormat(e.target.value as Format)}
                  className="w-full bg-panel border border-line rounded-lg px-3 py-2.5 text-sm"
                >
                  {MODE_INFO[mode].formats.map((f) => (
                    <option key={f} value={f}>
                      {f === '30s' ? '30 secondes' : f === '60s' ? '60 secondes' : '2 minutes'}
                      {creditCostFor(mode, f) !== null ? ` — ${creditCostFor(mode, f)} crédits` : ''}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1.5">
                  Nom de la marque <span className="text-muted font-normal">(optionnel)</span>
                </label>
                <input
                  type="text"
                  value={brandName}
                  onChange={(e) => setBrandName(e.target.value)}
                  placeholder={user?.name || 'Ex : Nova Cosmetics'}
                  className="w-full bg-panel border border-line rounded-lg px-3 py-2.5 text-sm"
                />
                <p className="text-xs text-muted mt-1.5">
                  Sans URL de site, ce nom est utilisé dans la vidéo. Laissé vide, on utilise le nom de votre compte.
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5">
                  Texte du bouton d&apos;appel à l&apos;action <span className="text-muted font-normal">(optionnel)</span>
                </label>
                <input
                  type="text"
                  value={ctaText}
                  onChange={(e) => setCtaText(e.target.value)}
                  placeholder="Ex : Commandez maintenant"
                  maxLength={40}
                  className="w-full bg-panel border border-line rounded-lg px-3 py-2.5 text-sm"
                />
                <p className="text-xs text-muted mt-1.5">
                  Affiché en incrustation à la fin de la vidéo. Par défaut : « Découvrez-en plus ».
                </p>
              </div>
            </div>

            {briefWarning && (
              <div className="text-sm bg-amber-500/10 border border-amber-500/30 rounded-lg px-3.5 py-3 space-y-1.5">
                <p className="text-amber-300 font-medium">{briefWarning.feedback}</p>
                {briefWarning.missingElements.length > 0 && (
                  <ul className="list-disc list-inside text-amber-200/80 text-xs space-y-0.5">
                    {briefWarning.missingElements.map((el, i) => (
                      <li key={i}>{el}</li>
                    ))}
                  </ul>
                )}
              </div>
            )}

            {formatRecommendation && (
              <div className="text-sm bg-blue/10 border border-blue/30 rounded-lg px-3.5 py-3 flex items-start gap-2.5">
                <span className="text-blue shrink-0 mt-0.5">💡</span>
                <p className="text-blue-200/90">{formatRecommendation}</p>
              </div>
            )}

            {error && (
              <div className="text-sm text-red-400 bg-red-500/10 border border-red-500/30 rounded-lg px-3 py-2">
                {error}
              </div>
            )}

            {hasVideoAccess ? (
              <button
                type="button"
                disabled={loading}
                onClick={handleGenerate}
                className="w-full py-3 rounded-lg bg-blue text-white font-semibold flex items-center justify-center gap-2 hover:opacity-90 disabled:opacity-50"
              >
                {loading ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    {checkingBrief ? 'Vérification du brief…' : urlValidating ? 'Analyse du site…' : 'Génération en cours…'}
                  </>
                ) : (
                  <>✨ Générer la vidéo</>
                )}
              </button>
            ) : (
              <Link
                href="/parametres?tab=abonnement"
                className="w-full py-3 rounded-lg bg-panel border border-blue/40 text-white font-semibold flex items-center justify-center gap-2 hover:border-blue transition"
              >
                🔒 Débloquer avec Créateur, Agence ou Pro Max
              </Link>
            )}
            <p className="text-xs text-muted text-center">
              {hasVideoAccess
                ? 'Génération IA — résultat estimé en 2 à 4 minutes. Les crédits sont débités au lancement (remboursés en cas d\u2019échec).'
                : 'Brief, format et style restent modifiables librement — seul le lancement de la génération est réservé aux abonnements Créateur, Agence et Pro Max.'}
            </p>
          </div>

          {/* Right — preview */}
          <div className="p-6 lg:p-8 bg-panel/40 flex flex-col">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-muted mb-4">
              Aperçu & génération
            </h2>

            <div
              className={`relative mx-auto w-full max-w-md rounded-xl overflow-hidden border border-line bg-ink flex items-center justify-center ${
                aspect === '9:16' ? 'aspect-[9/16]' : 'aspect-video'
              }`}
            >
              {finalUrl ? (
                <video src={finalUrl} controls className="w-full h-full object-contain" />
              ) : (
                <div className="text-center p-6 text-muted">
                  <div className="text-4xl mb-2 opacity-40">{hasVideoAccess ? '▶' : '🔒'}</div>
                  <div className="text-sm">
                    {status === 'generating' || status === 'queued'
                      ? 'Votre vidéo est en cours de création…'
                      : hasVideoAccess
                      ? 'L’aperçu apparaîtra ici'
                      : 'Votre vidéo apparaîtra ici dès l’upgrade vers Créateur, Agence ou Pro Max'}
                  </div>
                  {(status === 'generating' || status === 'queued') && (
                    <div className="mt-4 w-full bg-line rounded-full h-2 overflow-hidden">
                      <div
                        className="h-full bg-blue transition-all duration-500"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                  )}
                </div>
              )}
            </div>

            {(status === 'generating' || status === 'queued') && (
              <div className="mt-6 space-y-2 text-sm">
                <div className="flex items-center gap-2 text-muted">
                  <span className={progress >= 5 ? 'text-blue' : ''}>①</span> Analyse du brief
                  {progress >= 5 && <span className="text-xs text-blue">Terminé</span>}
                </div>
                <div className="flex items-center gap-2 text-muted">
                  <span className={progress >= 30 ? 'text-blue' : ''}>②</span> Création des scènes
                  {progress >= 30 && progress < 90 && <span className="text-xs text-blue">En cours</span>}
                  {progress >= 90 && <span className="text-xs text-blue">Terminé</span>}
                </div>
                <div className="flex items-center gap-2 text-muted">
                  <span className={progress >= 100 ? 'text-blue' : ''}>③</span> Finalisation vidéo
                </div>
                <p className="text-xs text-muted pt-2">
                  Vous serez notifié lorsque votre vidéo sera prête. Vous pouvez quitter cette page en toute sécurité.
                </p>
              </div>
            )}

            {finalUrl && (
              <div className="mt-6 text-center">
                <a
                  href={finalUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-4 py-2 bg-blue text-white rounded-lg text-sm font-semibold"
                >
                  Télécharger / Ouvrir la vidéo
                </a>
              </div>
            )}

            {finalUrl && qcDegraded && (
              <div className="mt-6 rounded-lg border border-amber-500/40 bg-amber-500/10 p-4 space-y-3">
                <div className="flex items-start gap-2">
                  <span className="text-lg leading-none">⚠️</span>
                  <div className="text-sm">
                    <p className="font-semibold text-amber-300">Résultat perfectible</p>
                    <p className="text-muted mt-1">
                      Cette vidéo présente un léger défaut (durée, cadrage ou son). Elle reste
                      utilisable telle quelle — mais si vous voulez un rendu plus abouti, vous
                      pouvez relancer une génération corrective à moitié prix.
                    </p>
                  </div>
                </div>

                {relaunchOffer?.used ? (
                  <p className="text-xs text-muted">
                    Relance corrective déjà utilisée pour cette vidéo.
                  </p>
                ) : relaunchOffer?.eligible ? (
                  <button
                    type="button"
                    onClick={handleRelaunch}
                    disabled={relaunching}
                    className="w-full py-2 rounded-lg border border-amber-400/60 text-amber-200 text-sm font-semibold hover:bg-amber-500/10 disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {relaunching ? (
                      <>
                        <span className="w-3.5 h-3.5 border-2 border-amber-200 border-t-transparent rounded-full animate-spin" />
                        Lancement de la relance…
                      </>
                    ) : (
                      <>🔁 Relancer pour la rendre parfaite — {relaunchOffer.priceCredits} crédits</>
                    )}
                  </button>
                ) : null}

                {relaunchError && <p className="text-xs text-red-400">{relaunchError}</p>}
              </div>
            )}

            {previousFinalUrl && (status === 'generating' || status === 'queued') && (
              <div className="mt-4 text-center text-xs text-muted">
                En attendant, votre vidéo précédente reste disponible :{' '}
                <a href={previousFinalUrl} target="_blank" rel="noopener noreferrer" className="text-blue underline">
                  l&apos;ouvrir
                </a>
              </div>
            )}
          </div>
        </div>
      </div>
    </DashboardShell>
  );
}
