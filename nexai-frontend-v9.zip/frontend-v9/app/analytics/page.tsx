'use client';

import DashboardShell from '@/components/DashboardShell';
import { useAuth } from '@/lib/auth-context';
import { planHasAnalytics } from '@/lib/plans';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

export default function AnalyticsPage() {
  const { user } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (user && !planHasAnalytics(user.plan)) router.replace('/dashboard');
  }, [user, router]);

  return (
    <DashboardShell>
      <div className="p-8 max-w-5xl">
        <h1 className="text-2xl font-display font-bold mb-1">Analytics</h1>
        <p className="text-muted text-sm mb-8">
          Données de vos sites (plans Agence & Pro Max)
        </p>

        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <div className="card p-5">
            <div className="text-2xl font-bold">—</div>
            <div className="text-sm text-muted mt-1">Sites en ligne</div>
          </div>
          <div className="card p-5">
            <div className="text-2xl font-bold">—</div>
            <div className="text-sm text-muted mt-1">Clients actifs</div>
          </div>
          <div className="card p-5">
            <div className="text-2xl font-bold">—</div>
            <div className="text-sm text-muted mt-1">Sites créés ce mois</div>
          </div>
        </div>

        <div className="card p-10 text-center">
          <p className="text-muted mb-2">Données de trafic en direct</p>
          <p className="text-sm text-muted">
            Bientôt disponible : pages vues, sources et performances de vos sites déployés.
            Pour l’instant, les statistiques internes (sites, clients, activité) sont affichées
            ci-dessus.
          </p>
        </div>
      </div>
    </DashboardShell>
  );
}
