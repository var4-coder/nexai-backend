'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import DashboardShell from '@/components/DashboardShell';
import { sitesApi, usersApi, domainsApi, Site, ApiError, type PaymentProviderUi } from '@/lib/api';
import { getNicheLabel } from '@/lib/niches';
import { CREDIT_COSTS } from '@/lib/plans';

type DomainOption = 'sous_domaine' | 'godaddy' | 'byod';

export default function SiteParametresPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const id = params.id;

  const [site, setSite] = useState<Site | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');

  const [option, setOption] = useState<DomainOption>('sous_domaine');
  const [subLabel, setSubLabel] = useState('');
  const [customDomain, setCustomDomain] = useState('');
  const [applying, setApplying] = useState(false);
  // Mode d'encaissement par défaut du compte — appliqué automatiquement au
  // lancement (réglable dans Paramètres → Paiements). 'nexai' = 'chariow' côté backend.
  const [defaultPaymentMode, setDefaultPaymentMode] = useState<'lien_personnel' | 'nexai'>('nexai');
  const [defaultPaymentProvider, setDefaultPaymentProvider] = useState<PaymentProviderUi | ''>('');
  // Override du lien/prestataire de paiement pour CE site uniquement (F8)
  const [overridePayment, setOverridePayment] = useState(false);
  const [overrideProvider, setOverrideProvider] = useState<PaymentProviderUi>('chariow');
  const [overrideLink, setOverrideLink] = useState('');

  useEffect(() => {
    sitesApi
      .get(id)
      .then(({ site }) => {
        setSite(site);
        if (site.domainType) setOption(site.domainType);
      })
      .catch((err) => {
        if (err instanceof ApiError && err.status === 404) setNotFound(true);
        else setError((err as Error).message || 'Erreur de chargement.');
      })
      .finally(() => setLoading(false));

    usersApi
      .me()
      .then((u) => {
        setDefaultPaymentMode(u.defaultPaymentMode === 'lien_personnel' ? 'lien_personnel' : 'nexai');
        setDefaultPaymentProvider(u.personalPaymentProvider || '');
        if (u.personalPaymentProvider) setOverrideProvider(u.personalPaymentProvider);
        if (u.personalPaymentLink) setOverrideLink(u.personalPaymentLink);
      })
      .catch(() => {});
  }, [id]);

  async function applyDomain(e: React.FormEvent) {
    e.preventDefault();
    setApplying(true);
    setError('');
    setMessage('');
    try {
      const paymentMode: 'lien_personnel' | 'chariow' =
        defaultPaymentMode === 'lien_personnel' ? 'lien_personnel' : 'chariow';
      const paymentOverride = overridePayment
        ? { paymentLink: overrideLink || undefined, paymentProvider: overrideProvider }
        : {};
      const domainConfig =
        option === 'sous_domaine'
          ? {
              domainType: 'sous_domaine' as const,
              subdomainSlug: subLabel || undefined,
              paymentMode,
              ...paymentOverride,
            }
          : option === 'byod'
          ? {
              domainType: 'byod' as const,
              domainName: customDomain,
              paymentMode,
              ...paymentOverride,
            }
          : {
              domainType: 'godaddy' as const,
              domainName: customDomain,
              paymentMode,
              ...paymentOverride,
            };

      const { site: updated } = await sitesApi.lancer(id, domainConfig);
      setSite(updated);
      setMessage('Configuration du domaine appliquée et site mis en ligne.');
    } catch (err) {
      setError((err as Error).message || "Impossible d'appliquer cette configuration.");
    } finally {
      setApplying(false);
    }
  }

  return (
    <DashboardShell>
      <div className="p-8 max-w-2xl">
        <Link
          href={`/sites/${id}`}
          className="text-sm text-muted hover:text-white mb-6 flex items-center gap-1"
        >
          ← Retour au site
        </Link>

        {loading ? (
          <div className="flex justify-center py-20">
            <div className="w-8 h-8 border-2 border-blue border-t-transparent rounded-full animate-spin" />
          </div>
        ) : notFound || !site ? (
          <div className="card p-16 text-center">
            <p className="text-muted mb-6">Ce site est introuvable.</p>
            <Link href="/sites" className="btn-primary rounded-lg px-6 py-2.5 text-sm inline-block">
              Retour à mes sites
            </Link>
          </div>
        ) : (
          <>
            <h1 className="text-2xl font-display font-bold mb-1">
              Paramètres — {site.name || getNicheLabel(site.niche)}
            </h1>
            <p className="text-muted text-sm mb-8">
              Gérez le domaine et les informations générales de ce site.
            </p>

            {error && (
              <div className="text-sm text-red bg-redSoft rounded-lg px-4 py-2.5 mb-4">
                {error}
              </div>
            )}
            {message && (
              <div className="text-sm text-mint bg-mintSoft rounded-lg px-4 py-2.5 mb-4">
                {message}
              </div>
            )}

            {/* Infos générales */}
            <div className="card p-5 mb-6 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted">Niche</span>
                <span>{getNicheLabel(site.niche)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted">Statut</span>
                <span>{site.status}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted">Domaine actuel</span>
                <span>{site.domainName || 'Aucun'}</span>
              </div>
              {site.createdAt && (
                <div className="flex justify-between">
                  <span className="text-muted">Créé le</span>
                  <span>
                    {new Date(site.createdAt).toLocaleDateString('fr-FR', {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric',
                    })}
                  </span>
                </div>
              )}
            </div>

            {/* Domaine */}
            <form onSubmit={applyDomain} className="card p-5 space-y-4">
              <h2 className="font-semibold text-sm">Nom de domaine</h2>

              <div className="space-y-2">
                {[
                  { id: 'sous_domaine' as const, title: 'Sous-domaine NexAI', desc: 'Gratuit' },
                  {
                    id: 'godaddy' as const,
                    title: 'Acheter / obtenir un domaine',
                    desc: `${CREDIT_COSTS.DOMAIN_EXTRA} crédits si hors quota`,
                  },
                  { id: 'byod' as const, title: "J’ai déjà mon domaine", desc: 'Gratuit' },
                ].map((opt) => (
                  <button
                    type="button"
                    key={opt.id}
                    onClick={() => setOption(opt.id)}
                    className={`w-full text-left rounded-lg border px-4 py-3 text-sm transition-colors ${
                      option === opt.id
                        ? 'border-blue bg-blueSoft'
                        : 'border-line hover:border-lineLt'
                    }`}
                  >
                    <div className="font-medium">{opt.title}</div>
                    <div className="text-xs text-muted mt-0.5">{opt.desc}</div>
                  </button>
                ))}
              </div>

              {option === 'sous_domaine' && (
                <div>
                  <label className="text-sm text-muted mb-1.5 block">Nom du sous-domaine</label>
                  <div className="flex items-center gap-2">
                    <input
                      className="input flex-1"
                      value={subLabel}
                      onChange={(e) => setSubLabel(e.target.value)}
                      placeholder="mon-studio"
                    />
                    <span className="text-muted text-sm">.nexai.fr</span>
                  </div>
                </div>
              )}

              {(option === 'godaddy' || option === 'byod') && (
                <div>
                  <label className="text-sm text-muted mb-1.5 block">Nom de domaine</label>
                  <input
                    className="input"
                    value={customDomain}
                    onChange={(e) => setCustomDomain(e.target.value)}
                    placeholder="monentreprise.com"
                  />
                </div>
              )}

              {/* Override paiement pour ce site uniquement (F8) */}
              <div className="pt-2 border-t border-line">
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input
                    type="checkbox"
                    checked={overridePayment}
                    onChange={(e) => setOverridePayment(e.target.checked)}
                    className="accent-blue"
                  />
                  Utiliser un lien de paiement différent pour ce site
                </label>

                {overridePayment && (
                  <div className="mt-3 space-y-3 animate-fade-in">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {(
                        [
                          { id: 'chariow', label: 'Chariow' },
                          { id: 'maketou', label: 'Maketou' },
                          { id: 'stripe', label: 'Stripe' },
                          { id: 'autre', label: 'Autre' },
                        ] as { id: PaymentProviderUi; label: string }[]
                      ).map((p) => (
                        <button
                          type="button"
                          key={p.id}
                          onClick={() => setOverrideProvider(p.id)}
                          className={`p-2.5 rounded-lg border text-sm transition-colors ${
                            overrideProvider === p.id
                              ? 'border-blue bg-blueSoft/30 ring-1 ring-blue'
                              : 'border-line hover:border-lineLt'
                          }`}
                        >
                          {p.label}
                        </button>
                      ))}
                    </div>
                    <input
                      className="input"
                      type="url"
                      placeholder="https://…/lien-de-paiement-pour-ce-site"
                      value={overrideLink}
                      onChange={(e) => setOverrideLink(e.target.value)}
                    />
                    <p className="text-xs text-muted">
                      S’applique uniquement à ce site. Laissez vide pour reprendre le lien du compte.
                    </p>
                  </div>
                )}
              </div>

              <button
                type="submit"
                disabled={applying}
                className="btn-primary rounded-lg px-5 py-2.5 text-sm font-semibold disabled:opacity-50"
              >
                {applying ? 'Application…' : 'Appliquer et mettre en ligne'}
              </button>
              <p className="text-xs text-muted">
                Encaissement des paiements clients :{' '}
                <strong className="text-white">
                  {overridePayment
                    ? `lien spécifique à ce site (${overrideProvider})`
                    : defaultPaymentMode === 'lien_personnel'
                    ? `votre lien personnel${defaultPaymentProvider ? ` (${defaultPaymentProvider})` : ''}`
                    : 'via NexAI'}
                </strong>
                . Modifiable dans{' '}
                <Link href="/parametres?tab=paiements" className="text-blue hover:underline">
                  Paramètres → Paiements
                </Link>
                .
              </p>
              <p className="text-xs text-muted">
                Besoin de comparer les options plus en détail ?{' '}
                <Link href="/domaines" className="text-blue hover:underline">
                  Voir la page Domaines
                </Link>
                .
              </p>
            </form>
          </>
        )}
      </div>
    </DashboardShell>
  );
}
