'use client';

import { useEffect, useState, useCallback } from 'react';
import Link from 'next/link';
import { useParams, useRouter } from 'next/navigation';
import DashboardShell from '@/components/DashboardShell';
import { sitesApi, Site, ApiError } from '@/lib/api';
import { getNicheLabel } from '@/lib/niches';
import { CREDIT_COSTS } from '@/lib/plans';

function statusBadge(status: string) {
  if (status === 'launched')
    return (
      <span className="badge-online">
        <span className="w-1.5 h-1.5 rounded-full bg-mint" /> En ligne
      </span>
    );
  if (status === 'ready' || status === 'generating')
    return (
      <span className="badge-draft">
        <span className="w-1.5 h-1.5 rounded-full bg-amber" /> En préparation
      </span>
    );
  if (status === 'failed' || status === 'offline')
    return (
      <span className="badge-offline">
        <span className="w-1.5 h-1.5 rounded-full bg-red" /> Hors ligne
      </span>
    );
  return (
    <span className="badge bg-white/10 text-muted">
      <span className="w-1.5 h-1.5 rounded-full bg-muted" /> Brouillon
    </span>
  );
}

type PanelKey = 'textes' | 'ia' | null;

export default function SiteDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const id = params.id;

  const [site, setSite] = useState<Site | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [panel, setPanel] = useState<PanelKey>(null);
  // Aperçu plein écran d'une proposition (F7 — iframe, plus d'ouverture blob)
  const [previewIndex, setPreviewIndex] = useState<number | null>(null);

  // Formulaires des panneaux
  const [textDraft, setTextDraft] = useState('');
  const [iaInstruction, setIaInstruction] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setNotFound(false);
    try {
      const { site } = await sitesApi.get(id);
      setSite(site);
      setTextDraft(
        typeof site.brief?.texteLibre === 'string' ? (site.brief.texteLibre as string) : ''
      );
    } catch (err) {
      if (err instanceof ApiError && err.status === 404) setNotFound(true);
      else setError((err as Error).message || 'Erreur de chargement du site.');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  async function runAction(key: string, fn: () => Promise<void>) {
    setActionLoading(key);
    setError('');
    setMessage('');
    try {
      await fn();
    } catch (err) {
      setError((err as Error).message || 'Une erreur est survenue.');
    } finally {
      setActionLoading(null);
    }
  }

  function handleOffline() {
    runAction('offline', async () => {
      const { site } = await sitesApi.offline(id);
      setSite(site);
      setMessage('Le site a été mis hors ligne.');
    });
  }

  function handleRegenerate() {
    runAction('regenerer', async () => {
      await sitesApi.generate(id);
      setMessage('Régénération lancée — actualisez dans quelques instants.');
      await load();
    });
  }

  function handleSaveText(e: React.FormEvent) {
    e.preventDefault();
    runAction('textes', async () => {
      const { site } = await sitesApi.updateBrief(id, { texteLibre: textDraft });
      setSite(site);
      setMessage('Textes mis à jour.');
      setPanel(null);
    });
  }

  function handleAiModify(e: React.FormEvent) {
    e.preventDefault();
    if (!iaInstruction.trim()) return;
    runAction('ia', async () => {
      await sitesApi.aiModify(id, iaInstruction);
      setMessage('Instruction envoyée à l’IA — le site va être mis à jour sous peu.');
      setIaInstruction('');
      setPanel(null);
      await load();
    });
  }

  /**
   * Mettre en ligne n'importe quelle proposition (F7) — pas seulement celle
   * choisie précédemment. On la marque choisie puis on renvoie vers la page
   * paramètres du site pour finaliser domaine + paiement.
   */
  async function handleLaunchProposal(index: number) {
    setActionLoading('choisir');
    setError('');
    try {
      await sitesApi.choose(id, index);
      router.push(`/sites/${id}/parametres`);
    } catch (err) {
      setError((err as Error).message || 'Impossible de sélectionner cette proposition.');
      setActionLoading(null);
    }
  }

  return (
    <DashboardShell>
      <div className="p-8 max-w-3xl">
        <button
          onClick={() => router.push('/sites')}
          className="text-sm text-muted hover:text-white mb-6 flex items-center gap-1"
        >
          ← Retour à mes sites
        </button>

        {loading ? (
          <div className="flex justify-center py-20">
            <div className="w-8 h-8 border-2 border-blue border-t-transparent rounded-full animate-spin" />
          </div>
        ) : notFound || !site ? (
          <div className="card p-16 text-center">
            <p className="text-muted mb-6">Ce site est introuvable.</p>
            <Link href="/sites" className="btn-primary rounded-lg px-6 py-2.5 text-sm inline-block">
              Retour à mes sites
            </Link>
          </div>
        ) : (
          <>
            <div className="flex items-start justify-between mb-2">
              <div>
                <h1 className="text-2xl font-display font-bold">
                  {site.name || getNicheLabel(site.niche)}
                </h1>
                <p className="text-muted text-sm mt-1">{getNicheLabel(site.niche)}</p>
              </div>
              <div>{statusBadge(site.status)}</div>
            </div>

            {error && (
              <div className="text-sm text-red bg-redSoft rounded-lg px-4 py-2.5 mt-4">
                {error}
              </div>
            )}
            {message && (
              <div className="text-sm text-mint bg-mintSoft rounded-lg px-4 py-2.5 mt-4">
                {message}
              </div>
            )}

            {/* Aperçu */}
            <div className="card p-4 mt-6">
              <div className="text-xs text-muted mb-2">Aperçu en direct</div>
              <div className="aspect-video bg-bg rounded-lg flex items-center justify-center text-muted text-sm">
                {site.domainName ? (
                  <a
                    href={`https://${site.domainName}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue hover:underline"
                  >
                    Ouvrir {site.domainName}
                  </a>
                ) : (
                  'Aperçu disponible après lancement'
                )}
              </div>
            </div>

            {/* Propositions (F7) — aperçu iframe, entrer dans n'importe laquelle et la mettre en ligne */}
            {site.proposals && site.proposals.length > 0 && site.status !== 'launched' && (
              <div className="card p-5 mt-4">
                <h2 className="font-semibold mb-1 text-sm">Vos propositions</h2>
                <p className="text-xs text-muted mb-4">
                  Entrez dans une proposition pour l’explorer, puis mettez en ligne celle que vous
                  préférez — pas forcément celle sélectionnée précédemment.
                </p>
                <div className="grid sm:grid-cols-2 gap-4">
                  {site.proposals.map((p: any, i: number) => (
                    <div key={i} className="rounded-xl border border-line overflow-hidden">
                      <div className="aspect-video bg-bg relative">
                        {p.htmlDemo ? (
                          <iframe
                            srcDoc={p.htmlDemo}
                            title={p.title || `Proposition ${i + 1}`}
                            sandbox="allow-same-origin"
                            className="w-full h-full border-0 pointer-events-none bg-white"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-muted text-xs">
                            Aperçu non disponible
                          </div>
                        )}
                      </div>
                      <div className="p-3">
                        <h3 className="font-semibold text-sm">
                          {p.title || p.name || `Proposition ${i + 1}`}
                          {p.recommandeBadge && (
                            <span className="ml-2 text-[10px] text-blue">Recommandée</span>
                          )}
                        </h3>
                        <div className="flex gap-2 mt-3">
                          <button
                            type="button"
                            disabled={!p.htmlDemo}
                            onClick={() => setPreviewIndex(i)}
                            className="flex-1 btn-secondary rounded-lg py-2 text-xs disabled:opacity-40 disabled:cursor-not-allowed"
                          >
                            Entrer
                          </button>
                          <button
                            type="button"
                            onClick={() => handleLaunchProposal(i)}
                            disabled={actionLoading === 'choisir'}
                            className="flex-1 btn-primary rounded-lg py-2 text-xs font-semibold disabled:opacity-50"
                          >
                            Mettre en ligne
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Modal plein écran d'une proposition */}
            {previewIndex !== null && site.proposals?.[previewIndex] && (
              <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 sm:p-8 animate-fade-in">
                <div className="bg-bg rounded-xl w-full h-full max-w-5xl flex flex-col overflow-hidden">
                  <div className="flex items-center justify-between px-4 py-3 border-b border-line">
                    <h3 className="font-semibold text-sm">
                      {site.proposals[previewIndex].title ||
                        site.proposals[previewIndex].name ||
                        `Proposition ${previewIndex + 1}`}
                    </h3>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleLaunchProposal(previewIndex)}
                        disabled={actionLoading === 'choisir'}
                        className="btn-primary rounded-lg px-4 py-2 text-xs font-semibold disabled:opacity-50"
                      >
                        Mettre en ligne cette proposition
                      </button>
                      <button
                        type="button"
                        onClick={() => setPreviewIndex(null)}
                        className="text-muted hover:text-white text-xl leading-none px-2"
                      >
                        ×
                      </button>
                    </div>
                  </div>
                  <iframe
                    srcDoc={site.proposals[previewIndex].htmlDemo}
                    title="Aperçu plein écran"
                    sandbox="allow-same-origin allow-scripts"
                    className="flex-1 w-full border-0 bg-white"
                  />
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="space-y-3 mt-6">
              <button
                onClick={() => setPanel(panel === 'textes' ? null : 'textes')}
                className="w-full btn-secondary rounded-lg px-4 py-3 text-sm text-left flex items-center justify-between"
              >
                <span>Modifier textes</span>
                <span className="text-muted">{panel === 'textes' ? '×' : '→'}</span>
              </button>
              {panel === 'textes' && (
                <form onSubmit={handleSaveText} className="card p-4 space-y-3">
                  <textarea
                    className="input min-h-[120px]"
                    value={textDraft}
                    onChange={(e) => setTextDraft(e.target.value)}
                    placeholder="Décrivez les textes que vous souhaitez sur votre site…"
                  />
                  <button
                    type="submit"
                    disabled={actionLoading === 'textes'}
                    className="btn-primary rounded-lg px-4 py-2 text-sm disabled:opacity-50"
                  >
                    {actionLoading === 'textes' ? 'Enregistrement…' : 'Enregistrer'}
                  </button>
                </form>
              )}

              {site.status === 'ready' && (
                <Link
                  href={`/sites/${id}/parametres`}
                  className="w-full btn-primary rounded-lg px-4 py-3 text-sm font-semibold text-left flex items-center justify-between block"
                >
                  <span>Mettre en ligne</span>
                  <span>→</span>
                </Link>
              )}

              {site.status === 'launched' && (
                <button
                  onClick={handleOffline}
                  disabled={actionLoading === 'offline'}
                  className="w-full btn-secondary rounded-lg px-4 py-3 text-sm text-left flex items-center justify-between disabled:opacity-50"
                >
                  <span>
                    {actionLoading === 'offline' ? 'Mise hors ligne…' : 'Mettre hors ligne'}
                  </span>
                  <span className="text-muted">→</span>
                </button>
              )}

              <button
                onClick={handleRegenerate}
                disabled={actionLoading === 'regenerer'}
                className="w-full btn-secondary rounded-lg px-4 py-3 text-sm text-left flex items-center justify-between disabled:opacity-50"
              >
                <span>{actionLoading === 'regenerer' ? 'Régénération…' : 'Régénérer'}</span>
                <span className="text-muted text-xs">{CREDIT_COSTS.REGENERATE} crédits</span>
              </button>

              <button
                onClick={() => setPanel(panel === 'ia' ? null : 'ia')}
                className="w-full btn-secondary rounded-lg px-4 py-3 text-sm text-left flex items-center justify-between"
              >
                <span>Modifier par IA</span>
                <span className="text-muted text-xs">{CREDIT_COSTS.AI_MODIFY} crédits</span>
              </button>
              {panel === 'ia' && (
                <form onSubmit={handleAiModify} className="card p-4 space-y-3">
                  <textarea
                    className="input min-h-[100px]"
                    value={iaInstruction}
                    onChange={(e) => setIaInstruction(e.target.value)}
                    placeholder="Ex : Change la couleur principale en bleu marine, ajoute une section témoignages…"
                  />
                  <button
                    type="submit"
                    disabled={actionLoading === 'ia' || !iaInstruction.trim()}
                    className="btn-primary rounded-lg px-4 py-2 text-sm disabled:opacity-50"
                  >
                    {actionLoading === 'ia' ? 'Envoi…' : 'Envoyer à l’IA'}
                  </button>
                </form>
              )}

              <Link
                href={`/sites/${id}/parametres`}
                className="w-full btn-secondary rounded-lg px-4 py-3 text-sm text-left flex items-center justify-between block"
              >
                <span>Voir les paramètres du site</span>
                <span className="text-muted">→</span>
              </Link>
            </div>
          </>
        )}
      </div>
    </DashboardShell>
  );
}
