'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import DashboardShell from '@/components/DashboardShell';
import { useAuth } from '@/lib/auth-context';
import { sitesApi, Site } from '@/lib/api';
import { planHasIA } from '@/lib/plans';
import { getNicheLabel } from '@/lib/niches';
import { CREDIT_COSTS } from '@/lib/plans';

function statusBadge(status: string) {
  if (status === 'launched')
    return (
      <span className="badge-online">
        <span className="w-1.5 h-1.5 rounded-full bg-mint" /> En ligne
      </span>
    );
  if (status === 'ready' || status === 'generating')
    return (
      <span className="badge-draft">
        <span className="w-1.5 h-1.5 rounded-full bg-amber" /> En préparation
      </span>
    );
  if (status === 'failed' || status === 'offline')
    return (
      <span className="badge-offline">
        <span className="w-1.5 h-1.5 rounded-full bg-red" /> Hors ligne
      </span>
    );
  return (
    <span className="badge bg-white/10 text-muted">
      <span className="w-1.5 h-1.5 rounded-full bg-muted" /> Brouillon
    </span>
  );
}

export default function SitesPage() {
  const { user } = useAuth();
  const [sites, setSites] = useState<Site[]>([]);
  const [selected, setSelected] = useState<Site | null>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [actionError, setActionError] = useState('');

  useEffect(() => {
    sitesApi
      .list()
      .then((r) => setSites(r.sites))
      .catch(() => setSites([]))
      .finally(() => setLoading(false));
  }, []);

  async function refreshSelected(updated: Site) {
    setSelected(updated);
    setSites((prev) => prev.map((s) => (s.id === updated.id ? updated : s)));
  }

  async function handleOffline(site: Site) {
    setActionLoading('offline');
    setActionError('');
    try {
      const { site: updated } = await sitesApi.offline(site.id);
      await refreshSelected(updated);
    } catch (err) {
      setActionError((err as Error).message || 'Impossible de mettre le site hors ligne.');
    } finally {
      setActionLoading(null);
    }
  }

  async function handleRegenerate(site: Site) {
    setActionLoading('regenerer');
    setActionError('');
    try {
      await sitesApi.generate(site.id);
      const { site: updated } = await sitesApi.get(site.id);
      await refreshSelected(updated);
    } catch (err) {
      setActionError((err as Error).message || 'Impossible de régénérer ce site.');
    } finally {
      setActionLoading(null);
    }
  }

  return (
    <DashboardShell>
      <div className="flex h-[calc(100vh)]">
        {/* Liste */}
        <div className="flex-1 p-8 overflow-y-auto">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-2xl font-display font-bold">Mes sites</h1>
              <p className="text-muted text-sm mt-1">
                Gérez tous vos sites créés avec l’IA NexAI.
              </p>
            </div>
            {planHasIA(user?.plan) ? (
              <Link
                href="/assistant"
                className="btn-primary rounded-lg px-5 py-2.5 text-sm font-semibold"
              >
                + Créer mon site avec l’IA
              </Link>
            ) : (
              <Link
                href="/assistant"
                className="btn-secondary rounded-lg px-5 py-2.5 text-sm"
              >
                Découvrir NexAI IA
              </Link>
            )}
          </div>

          {loading ? (
            <div className="flex justify-center py-20">
              <div className="w-8 h-8 border-2 border-blue border-t-transparent rounded-full animate-spin" />
            </div>
          ) : sites.length === 0 ? (
            <div className="card p-16 text-center">
              <p className="text-muted mb-6">Aucun site pour le moment.</p>
              {planHasIA(user?.plan) && (
                <Link
                  href="/assistant"
                  className="btn-primary rounded-lg px-6 py-2.5 text-sm inline-block"
                >
                  Créer mon premier site
                </Link>
              )}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
              {sites.map((site) => (
                <button
                  key={site.id}
                  onClick={() => setSelected(site)}
                  className={`card p-5 text-left transition-all hover:border-lineLt ${
                    selected?.id === site.id ? 'ring-1 ring-blue border-blue' : ''
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    {statusBadge(site.status)}
                    <span className="text-muted text-xs">⋮</span>
                  </div>
                  <h3 className="font-semibold text-base">
                    {site.name || getNicheLabel(site.niche)}
                  </h3>
                  <p className="text-sm text-muted mt-0.5">{getNicheLabel(site.niche)}</p>
                  {site.domainName && (
                    <p className="text-xs text-blue mt-2 flex items-center gap-1 truncate">
                      <span>🔗</span> {site.domainName}
                    </p>
                  )}
                  {site.createdAt && (
                    <p className="text-xs text-muted mt-3">
                      Créé le{' '}
                      {new Date(site.createdAt).toLocaleDateString('fr-FR', {
                        day: 'numeric',
                        month: 'long',
                        year: 'numeric',
                      })}
                    </p>
                  )}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Panneau latéral droit */}
        {selected && (
          <div className="w-[380px] border-l border-line bg-panel flex flex-col">
            <div className="p-5 border-b border-line flex items-center justify-between">
              <div>
                <h2 className="font-semibold">{selected.name || getNicheLabel(selected.niche)}</h2>
                <div className="mt-1">{statusBadge(selected.status)}</div>
              </div>
              <button
                onClick={() => setSelected(null)}
                className="text-muted hover:text-white text-xl leading-none"
              >
                ×
              </button>
            </div>

            <div className="p-5 flex-1 overflow-y-auto space-y-4">
              <div className="card p-4">
                <div className="text-xs text-muted mb-2">Aperçu en direct</div>
                <div className="aspect-video bg-bg rounded-lg flex items-center justify-center text-muted text-sm overflow-hidden">
                  {selected.domainName ? (
                    <a
                      href={`https://${selected.domainName}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue hover:underline"
                    >
                      Ouvrir {selected.domainName}
                    </a>
                  ) : selected.status === 'ready' &&
                    selected.proposals &&
                    selected.proposals.length > 0 &&
                    selected.proposals[0]?.htmlDemo ? (
                    <iframe
                      srcDoc={selected.proposals[0].htmlDemo}
                      title="Aperçu"
                      sandbox="allow-same-origin"
                      className="w-full h-full border-0 pointer-events-none bg-white"
                    />
                  ) : (
                    'Aperçu disponible après génération'
                  )}
                </div>
                {selected.status === 'ready' &&
                  selected.proposals &&
                  selected.proposals.length > 0 && (
                    <Link
                      href={`/sites/${selected.id}`}
                      className="text-xs text-blue hover:underline mt-2 inline-block"
                    >
                      Voir les {selected.proposals.length} propositions →
                    </Link>
                  )}
              </div>

              {actionError && (
                <div className="text-sm text-red bg-redSoft rounded-lg px-4 py-2.5">
                  {actionError}
                </div>
              )}

              <Link
                href={`/sites/${selected.id}`}
                className="w-full btn-secondary rounded-lg px-4 py-3 text-sm text-left flex items-center justify-between block"
              >
                <span>Modifier textes</span>
                <span className="text-muted">→</span>
              </Link>

              {selected.status === 'ready' && (
                <Link
                  href={`/sites/${selected.id}/parametres`}
                  className="w-full btn-primary rounded-lg px-4 py-3 text-sm font-semibold text-left flex items-center justify-between block"
                >
                  <span>Mettre en ligne</span>
                  <span>→</span>
                </Link>
              )}

              {selected.status === 'launched' && (
                <button
                  onClick={() => handleOffline(selected)}
                  disabled={actionLoading === 'offline'}
                  className="w-full btn-secondary rounded-lg px-4 py-3 text-sm text-left flex items-center justify-between disabled:opacity-50"
                >
                  <span>
                    {actionLoading === 'offline' ? 'Mise hors ligne…' : 'Mettre hors ligne'}
                  </span>
                  <span className="text-muted">→</span>
                </button>
              )}

              <button
                onClick={() => handleRegenerate(selected)}
                disabled={actionLoading === 'regenerer'}
                className="w-full btn-secondary rounded-lg px-4 py-3 text-sm text-left flex items-center justify-between disabled:opacity-50"
              >
                <span>{actionLoading === 'regenerer' ? 'Régénération…' : 'Régénérer'}</span>
                <span className="text-muted text-xs">{CREDIT_COSTS.REGENERATE} crédits</span>
              </button>

              <Link
                href={`/sites/${selected.id}`}
                className="w-full btn-secondary rounded-lg px-4 py-3 text-sm text-left flex items-center justify-between block"
              >
                <span>Modifier par IA</span>
                <span className="text-muted text-xs">{CREDIT_COSTS.AI_MODIFY} crédits</span>
              </Link>

              <Link
                href={`/sites/${selected.id}/parametres`}
                className="w-full btn-secondary rounded-lg px-4 py-3 text-sm text-left flex items-center justify-between block"
              >
                <span>Voir les paramètres du site</span>
                <span className="text-muted">→</span>
              </Link>
            </div>
          </div>
        )}
      </div>
    </DashboardShell>
  );
}
