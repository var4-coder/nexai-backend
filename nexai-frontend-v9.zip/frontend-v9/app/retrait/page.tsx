'use client';

import { useEffect, useState } from 'react';
import DashboardShell from '@/components/DashboardShell';
import { retraitApi, ApiError } from '@/lib/api';

type Mode = 'nexai' | 'lien_personnel';

type Etat = Awaited<ReturnType<typeof retraitApi.get>>;

export default function RetraitPage() {
  const [etat, setEtat] = useState<Etat | null>(null);
  const [mode, setMode] = useState<Mode>('nexai');
  const [chargement, setChargement] = useState(true);
  const [enregistrement, setEnregistrement] = useState(false);
  const [erreur, setErreur] = useState('');
  const [succes, setSucces] = useState('');

  // Compte NexAI
  const [typeRetrait, setTypeRetrait] = useState<'mobile_money' | 'crypto'>('mobile_money');
  const [operateur, setOperateur] = useState('');
  const [numero, setNumero] = useState('');
  const [cryptoType, setCryptoType] = useState<'usdt_bep20' | 'btc'>('usdt_bep20');
  const [cryptoAddress, setCryptoAddress] = useState('');

  // Lien personnel
  const [lien, setLien] = useState('');
  const [prestataire, setPrestataire] = useState<'chariow' | 'maketou' | 'stripe' | 'autre'>('chariow');

  useEffect(() => {
    let actif = true;
    (async () => {
      try {
        const e = await retraitApi.get();
        if (!actif) return;
        setEtat(e);
        setMode(e.modeActif);
        setLien(e.lienPersonnel.lien ?? '');
        if (e.lienPersonnel.prestataire) {
          setPrestataire(e.lienPersonnel.prestataire as typeof prestataire);
        }
        const c = e.compteNexai.coordonnees as Record<string, string> | null;
        if (c) {
          if (c.type === 'crypto') {
            setTypeRetrait('crypto');
            setCryptoType((c.cryptoType as typeof cryptoType) ?? 'usdt_bep20');
            setCryptoAddress(c.cryptoAddress ?? '');
          } else {
            setTypeRetrait('mobile_money');
            setOperateur(c.operateur ?? '');
            setNumero(c.numero ?? '');
          }
        }
      } catch (e) {
        if (actif) setErreur(e instanceof ApiError ? e.message : 'Chargement impossible.');
      } finally {
        if (actif) setChargement(false);
      }
    })();
    return () => {
      actif = false;
    };
  }, []);

  async function enregistrer() {
    setErreur('');
    setSucces('');
    setEnregistrement(true);
    try {
      if (mode === 'nexai') {
        await retraitApi.update({
          mode: 'nexai',
          compteReversement:
            typeRetrait === 'crypto'
              ? { type: 'crypto', cryptoType, cryptoAddress }
              : { type: 'mobile_money', operateur, numero },
        });
      } else {
        // Le lien est réellement testé côté serveur (HTTPS, DNS, anti-SSRF).
        await retraitApi.update({
          mode: 'lien_personnel',
          personalPaymentLink: lien,
          personalPaymentProvider: prestataire,
        });
      }
      setSucces('Votre méthode de retrait a été enregistrée.');
      const e = await retraitApi.get();
      setEtat(e);
    } catch (e) {
      setErreur(e instanceof ApiError ? e.message : 'Enregistrement impossible.');
    } finally {
      setEnregistrement(false);
    }
  }

  const stats = etat?.compteNexai.statistiques;
  const historique = etat?.compteNexai.historique ?? [];
  const fcfa = (n: number) => `${n.toLocaleString('fr-FR')} FCFA`;

  return (
    <DashboardShell>
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-1">Méthode de retrait</h1>
        <p className="text-sm text-[var(--muted)]">
          Choisissez comment vous recevez l&apos;argent de vos ventes.
        </p>
      </div>

      {erreur && (
        <div className="mb-6 rounded border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-300">
          {erreur}
        </div>
      )}
      {succes && (
        <div className="mb-6 rounded border border-emerald-500/40 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-300">
          {succes}
        </div>
      )}

      {chargement ? (
        <p className="text-sm text-[var(--muted)]">Chargement…</p>
      ) : (
        <>
          {/* Choix du mode */}
          <div className="mb-6 grid gap-4 md:grid-cols-2">
            <button
              type="button"
              onClick={() => etat?.compteNexai.disponible && setMode('nexai')}
              disabled={!etat?.compteNexai.disponible}
              className={`rounded-lg border p-5 text-left transition ${
                mode === 'nexai' ? 'border-[var(--blue)]' : 'border-[var(--line)]'
              } bg-[var(--panel)] disabled:opacity-50`}
            >
              <h3 className="mb-2 font-semibold">{etat?.compteNexai.label}</h3>
              <p className="text-sm leading-relaxed text-[var(--muted)]">
                {etat?.compteNexai.description}
              </p>
              {!etat?.compteNexai.disponible && (
                <p className="mt-3 text-xs font-semibold text-[var(--muted)]">
                  Disponible à partir de l&apos;abonnement Créateur+.
                </p>
              )}
            </button>

            <button
              type="button"
              onClick={() => setMode('lien_personnel')}
              className={`rounded-lg border p-5 text-left transition ${
                mode === 'lien_personnel' ? 'border-[var(--blue)]' : 'border-[var(--line)]'
              } bg-[var(--panel)]`}
            >
              <h3 className="mb-2 font-semibold">{etat?.lienPersonnel.label}</h3>
              <p className="text-sm leading-relaxed text-[var(--muted)]">
                {etat?.lienPersonnel.description}
              </p>
            </button>
          </div>

          {/* Formulaire du mode choisi */}
          <div className="mb-8 rounded-lg border border-[var(--line)] bg-[var(--panel)] p-6">
            {mode === 'nexai' ? (
              <>
                <h3 className="mb-4 font-semibold">Comment souhaitez-vous être payé ?</h3>
                <div className="mb-4 flex gap-2">
                  {(['mobile_money', 'crypto'] as const).map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setTypeRetrait(t)}
                      className={`rounded border px-4 py-2 text-sm font-semibold ${
                        typeRetrait === t
                          ? 'border-[var(--blue)] text-[var(--blue-text)]'
                          : 'border-[var(--line)] text-[var(--muted)]'
                      }`}
                    >
                      {t === 'mobile_money' ? 'Mobile Money' : 'Crypto'}
                    </button>
                  ))}
                </div>

                {typeRetrait === 'mobile_money' ? (
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label className="mb-1.5 block text-xs uppercase tracking-wide text-[var(--muted)]">
                        Opérateur
                      </label>
                      <input
                        className="w-full rounded border border-[var(--line)] bg-[var(--bg)] px-3 py-2.5 text-sm"
                        value={operateur}
                        onChange={(e) => setOperateur(e.target.value)}
                        placeholder="Wave, Orange Money, MTN, Moov…"
                      />
                    </div>
                    <div>
                      <label className="mb-1.5 block text-xs uppercase tracking-wide text-[var(--muted)]">
                        Numéro
                      </label>
                      <input
                        className="w-full rounded border border-[var(--line)] bg-[var(--bg)] px-3 py-2.5 text-sm"
                        value={numero}
                        onChange={(e) => setNumero(e.target.value)}
                        placeholder="+229 …"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label className="mb-1.5 block text-xs uppercase tracking-wide text-[var(--muted)]">
                        Réseau
                      </label>
                      <select
                        className="w-full rounded border border-[var(--line)] bg-[var(--bg)] px-3 py-2.5 text-sm"
                        value={cryptoType}
                        onChange={(e) => setCryptoType(e.target.value as typeof cryptoType)}
                      >
                        <option value="usdt_bep20">USDT (BEP-20)</option>
                        <option value="btc">Bitcoin</option>
                      </select>
                    </div>
                    <div>
                      <label className="mb-1.5 block text-xs uppercase tracking-wide text-[var(--muted)]">
                        Adresse
                      </label>
                      <input
                        className="w-full rounded border border-[var(--line)] bg-[var(--bg)] px-3 py-2.5 text-sm font-mono"
                        value={cryptoAddress}
                        onChange={(e) => setCryptoAddress(e.target.value)}
                        placeholder="0x…"
                      />
                    </div>
                    <p className="text-xs text-amber-400 sm:col-span-2">
                      Vérifiez le réseau : une adresse envoyée sur le mauvais réseau est perdue.
                    </p>
                  </div>
                )}
              </>
            ) : (
              <>
                <h3 className="mb-4 font-semibold">Votre lien de paiement</h3>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label className="mb-1.5 block text-xs uppercase tracking-wide text-[var(--muted)]">
                      Prestataire
                    </label>
                    <select
                      className="w-full rounded border border-[var(--line)] bg-[var(--bg)] px-3 py-2.5 text-sm"
                      value={prestataire}
                      onChange={(e) => setPrestataire(e.target.value as typeof prestataire)}
                    >
                      <option value="chariow">Chariow</option>
                      <option value="maketou">Maketou</option>
                      <option value="stripe">Stripe</option>
                      <option value="autre">Autre</option>
                    </select>
                  </div>
                  <div>
                    <label className="mb-1.5 block text-xs uppercase tracking-wide text-[var(--muted)]">
                      Adresse du lien
                    </label>
                    <input
                      className="w-full rounded border border-[var(--line)] bg-[var(--bg)] px-3 py-2.5 text-sm"
                      value={lien}
                      onChange={(e) => setLien(e.target.value)}
                      placeholder="https://…"
                    />
                  </div>
                </div>
                <p className="mt-3 text-xs text-[var(--muted)]">
                  Le lien est vérifié avant enregistrement : il doit être en HTTPS et répondre
                  réellement, sans quoi vos visiteurs ne pourraient pas payer.
                </p>
              </>
            )}

            <button
              type="button"
              onClick={enregistrer}
              disabled={enregistrement}
              className="mt-5 rounded bg-[var(--blue)] px-5 py-2.5 text-sm font-bold uppercase tracking-wide text-[#0E1118] disabled:opacity-60"
            >
              {enregistrement ? 'Enregistrement…' : 'Enregistrer'}
            </button>
          </div>

          {/* Statistiques du Compte NexAI */}
          {mode === 'nexai' && stats && (
            <>
              <section className="mb-8">
                <h2 className="mb-3 text-lg font-semibold">Vos paiements</h2>
                <div className="grid gap-4 sm:grid-cols-3">
                  <div className="rounded-lg border border-[var(--line)] bg-[var(--panel)] p-5">
                    <p className="text-xl font-bold">{fcfa(stats.encaisseFcfa)}</p>
                    <p className="text-xs uppercase tracking-wide text-[var(--muted)]">Encaissé</p>
                  </div>
                  <div className="rounded-lg border border-[var(--line)] bg-[var(--panel)] p-5">
                    <p className="text-xl font-bold">{fcfa(stats.reverseFcfa)}</p>
                    <p className="text-xs uppercase tracking-wide text-[var(--muted)]">Déjà reversé</p>
                  </div>
                  <div className="rounded-lg border border-emerald-500/40 bg-[var(--panel)] p-5">
                    <p className="text-xl font-bold text-emerald-400">{fcfa(stats.enAttenteFcfa)}</p>
                    <p className="text-xs uppercase tracking-wide text-[var(--muted)]">En attente</p>
                  </div>
                </div>
                <p className="mt-3 text-sm text-[var(--muted)]">
                  Vos gains vous sont reversés tous les 3 jours.
                </p>
              </section>

              <section>
                <h2 className="mb-3 text-lg font-semibold">Historique</h2>
                <div className="overflow-x-auto rounded-lg border border-[var(--line)] bg-[var(--panel)]">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-[var(--line)] text-left text-xs uppercase tracking-wide text-[var(--muted)]">
                        <th className="px-4 py-3">Date</th>
                        <th className="px-4 py-3">Opération</th>
                        <th className="px-4 py-3">Référence</th>
                        <th className="px-4 py-3 text-right">Montant</th>
                      </tr>
                    </thead>
                    <tbody>
                      {historique.length === 0 ? (
                        <tr>
                          <td colSpan={4} className="px-4 py-8 text-center text-[var(--muted)]">
                            Aucun mouvement pour l&apos;instant.
                          </td>
                        </tr>
                      ) : (
                        historique.map((h) => (
                          <tr key={h.id} className="border-b border-[var(--line)] last:border-0">
                            <td className="px-4 py-3 text-[var(--muted)]">
                              {new Date(h.date).toLocaleDateString('fr-FR')}
                            </td>
                            <td className="px-4 py-3">
                              {h.type === 'encaissement_visiteur' ? 'Vente encaissée' : 'Reversement'}
                            </td>
                            <td className="px-4 py-3 font-mono text-xs text-[var(--muted)]">
                              {h.reference ?? '—'}
                            </td>
                            <td
                              className={`px-4 py-3 text-right font-semibold ${
                                h.type === 'encaissement_visiteur' ? 'text-emerald-400' : ''
                              }`}
                            >
                              {fcfa(h.amountFcfa)}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </section>
            </>
          )}
        </>
      )}
    </DashboardShell>
  );
}
